// Lea LI
// Exercise 1.3.4
// Input zero or non-zero value to test how the Boolean results are implemented

#include <stdio.h>


int main()
{
    int married;
    printf("Enter an integer: ");
    scanf("%i", &married);
    printf(married ? "married\n" : "not married\n"); // conditional operator is mostly used in one line choice constructs
    //Boolean values declared false are assigned the value of 0, and true values are assigned to non-zero
    return 0;
}
