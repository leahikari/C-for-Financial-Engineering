// Lea LI
// Exercise 1.3.6
// Difference between arithmetic and logical right shift - signed and unsigned binary number

#include <stdio.h>

int main()
{
    int i;
    printf("Input an integer: ");
    scanf("%d", &i);
    printf("%d shift by 2 bits: %d\n", i, i >> 2);
    // shifting right by 2 bits on an unsigned binary number has the same effect of dividing it by 4
    // determine arithmetic or logical shift by signs
    if ((i < 0) & ((i >> 2) < 0))
    {
        printf("arithmetic shift\n");// arithematic shift preserve the sign
    }
    else
    {
        printf("logical shift\n");// logical shift does not preserve a number's sign bit
    }

    return 0;
}
