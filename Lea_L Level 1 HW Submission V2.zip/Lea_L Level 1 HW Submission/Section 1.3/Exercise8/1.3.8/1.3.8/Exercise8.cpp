// Lea LI
// Exercise 1.3.8
// Demonstrate assignment operators results

#include <stdio.h>

int main()
{
    int x=2;
    int y;
    int z;
    
    x*=3+2;
    printf("x=%d\n", x);//x=10
    
    x*=y=z=4;
    printf("x=%d\n", x);//x=40 since 10 was assigned to 10 in previous step
    
    x=y==z;
    printf("x=%d\n", x);//x is 1 (True) since 4 is assigned to both y and z in previous step
    return 0;
}
