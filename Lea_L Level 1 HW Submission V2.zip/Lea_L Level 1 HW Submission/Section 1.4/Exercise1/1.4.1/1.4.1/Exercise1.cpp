// Lea LI
// Exercise 1.4.1
// Purpose: Caculate the amount of characters, the amount of words and the amount of newlines that have been typed using a while loop

#include <stdio.h>

int main()
{
    int count_char = 0; // number of the characters
    int count_line = 1; // default line number initiate to 1
    int count_words = 0; // number of words

    char cur_char;  // current character
    char pre_char = ' '; // previous character

    printf("Input the text and press CTRL + D to stop: \n");
    // reading of characters from the keyboard can be stopped when the shutdown-code ^D (CTRL + D) is entered
    while ((cur_char=getchar())!=EOF)
    {
        ++count_char;  // increment the number of characters and \n new line is counted as a character as well
        if (cur_char == '\n') //check if start a newline
            ++count_line;    // increment the number of lines
        
        if ((cur_char != ' ' && pre_char == ' ')||(cur_char != ' ' && pre_char == '\n')||(cur_char != ' ' && pre_char == '\t'))
            // any whitespace preceded by non-whitespace should count as a word. Whitespace can be space, tab, or newline.
            ++count_words;  // increment the number of words
        pre_char = cur_char;
    }
    printf("\nnumber of lines = %d\nnumber of characters = %d\nnumber of words = %d\n", count_line, count_char, count_words);

    return 0;

}



