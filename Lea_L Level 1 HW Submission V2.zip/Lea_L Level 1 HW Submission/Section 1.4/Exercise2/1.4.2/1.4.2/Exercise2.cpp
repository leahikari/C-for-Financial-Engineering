// Lea LI
// Exercise 1.4.2
// Purpose: Caculate the amount of characters, the amount of words and the amount of newlines that have been typed using do-while loop

#include <stdio.h>

int main()
{
    int count_char = 0; // number of the characters
    int count_line = 1; // default line number initiate to 1
    int count_words = 0; // number of words
    
    char cur_char;  // current character
    char pre_char = ' '; // previous character
    
    printf("Input the text and press CTRL + D to stop: \n");
    // reading of characters from the keyboard can be stopped when the shutdown-code ^D (CTRL + D) is entered
    
    do
    {
        cur_char = getchar();
        if (cur_char != EOF)
        {
            ++count_char;  // increase the number of characters since user typed
            if (cur_char == '\n') // check if start a newline
                ++count_line;     // increment the number of lines
            
            if ((cur_char != ' ' && pre_char == ' ')||(cur_char != ' ' && pre_char == '\n')||(cur_char != ' ' && pre_char == '\t'))
                ++count_words;   //if previous char is not a space/a new line/a tab, and next one is a space, count as a word
            pre_char = cur_char; // update previous typed character to new typed character
        }
        
    }
    while (cur_char!= EOF);
    printf("\nnumber of lines = %d\nnumber of characters = %d\nnumber of words = %d\n", count_line, count_char, count_words);
    return 0;
}
    
