// Lea LI
// Exercise 1.4.4
// Temperature conversion between Fahrenheit and Celsius degree

#include <stdio.h>

int main()
{
    float c = 0; // Celsius degree
    float fmin = 0;//Set temperature conversion minimum range for Fahrenheit degree
    float fmax = 300;//Set temperature conversion maximum range for Fahrenheit degree
    float f = fmin;// Initialise Fahrenheit degree to minimum
    float step = 20;// Increment in Fahrenheit between two consecutive conversion results
    printf("   Fahrenheit\t  Celsius\n");//Column header
    while (f <= fmax) //While loop stops when f exceeds maximum degree
    {
        c = (5.0 / 9.0)*(f - 32.0);
        printf("%10.1f\t%10.1f\n", f, c);
        f = f + step;
    }
    return 0;
}



