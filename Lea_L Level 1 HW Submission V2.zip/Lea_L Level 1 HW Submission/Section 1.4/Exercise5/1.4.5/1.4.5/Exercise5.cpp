// Lea LI
// Exercise 1.4.5
// Temperature conversion between Celsius degree and Fahrenheit
// Consecutive conversion using for loop

#include <stdio.h>

int main()
{
    float f = 0; //Initialise Fahrenheit degree
    float cmin = 0; //Set temperature conversion minimum range in Celsius
    float cmax = 19; //Set temperature conversion maximum range in Celsius
    float cel = cmin; //Initialise Celsius
    float step = 1; //Increment in Celsius
    printf("   Celsius\t  Fahrenheit\n"); //Column header
    for (cel=0; cel<=cmax; cel+=step) // Conversion stops when celsius exceeds maximum range
    {
        f = (9.0 / 5.0)*cel + 32;
        printf("%10.1f\t,%10.1f\n", cel, f);
    }
    return 0;
}

