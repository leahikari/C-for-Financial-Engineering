// Lea LI
// Exercise 1.5.1
// Purpose: Calls a function minus() to return the difference of 2 numbers

#include <stdio.h>

double minus(double a, double b)
{
    return a - b;
}

int main()
{
    double x;
    double y;
    printf("Please enter two numbers (split by space): \n");
    scanf("%lf %lf",&x,&y);
    printf("%f minus %f is %f\n", x, y, minus(x,y));
    return 0;
}
