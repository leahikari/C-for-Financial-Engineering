// Lea LI
// Exercise 1.5.2
// Purpose: Print factorials of an integer using recursive function

#include <stdio.h>

long long factorial(unsigned int a)// to prevent negative integer from input
{
    if (a>1)
    {
        long long r = a * (a-1);
        return r * factorial(a-2);// recursive functiojn calls itself till multiplied to 1
    }
    else
    {
        return 1;
    }
}

int main()
{
    printf("Please type a positive integer:\n"); //factorial is only defined for non-negative integer
    int number = 0;
    scanf("%d",&number);
    if (number >= 0)
    {
        printf("The factorial of %d is: %lld\n", number, factorial(number));//print the factorial of the interger typed
    }
    else
    {
        printf("Factorials are nor defined for negative integers\n");// message for negative input
    }
    return 0;
}

