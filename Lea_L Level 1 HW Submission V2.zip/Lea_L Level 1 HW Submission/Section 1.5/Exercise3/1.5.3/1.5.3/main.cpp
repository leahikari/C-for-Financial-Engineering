// Lea LI
// Exercise 1.5.3
// Purpose: Main function call print() from Print.cpp

#include <stdio.h>
#include "Print.hpp"// declare the header file where contains the print function

void print(double a);


int main()
{
    double i;//declare the variable i
    printf("Enter a number for calculation\n");
    scanf("%lf",&i);
    print(i);// call print function to print the result

    return 0;
}
