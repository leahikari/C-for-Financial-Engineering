// Lea LI
// Exercise 1.5.3
// Define the print function

#include <stdio.h>

void print(double i)
{
    printf("%f multiplied by 2 is %f\n",i, 2*i);
}

