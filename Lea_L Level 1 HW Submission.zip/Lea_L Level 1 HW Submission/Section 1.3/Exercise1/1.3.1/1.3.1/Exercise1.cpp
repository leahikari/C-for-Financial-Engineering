// Lea LI
// Exercise 1.3.1

#include <stdio.h>

int main()
{
    printf("My first C-program\n");
    printf("is a fact!\n");
    printf("Good, isn't it?\n");
    return 0;
}
