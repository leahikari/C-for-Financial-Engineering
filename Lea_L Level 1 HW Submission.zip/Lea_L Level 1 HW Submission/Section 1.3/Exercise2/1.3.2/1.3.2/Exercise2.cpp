//Lea LI
//Exercise 1.3.2
//Calculate the surface of right triangle given input of base and height

#include <stdio.h>

int main()
{
    double base, height, surface;
    printf("Enter base and height of the right triangle (split by space): ");
    scanf("%lf %lf", &base, &height);
    
    surface = 0.5 * base * height;
    printf("The surface of the right triangle is: %lf\n", surface);
    return 0;
}
