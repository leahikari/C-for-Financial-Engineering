// Lea LI
// Exercise 1.3.4
// Input zero or non-zero value to test how the Boolean results are implemented

#include <stdio.h>


int main()
{
    unsigned int married;
    printf("Enter an integer: ");
    scanf("%i", &married);
    char check;
    check = (married == 0) ? 'F' : 'T';
    printf("Variable married is %c\n", check);
    
    return 0;
}
