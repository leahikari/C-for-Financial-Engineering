// Lea LI
// Exercise 1.3.5
// Show the difference between ++i and i++

#include <stdio.h>

int main()
{
    int i = 0;
    int j = 0;
    int k;
    printf("Input a integer as initial value of i:");
    scanf("%d", &i);
    int temp = i;
    
    j = i++; // return i, then increment i
    printf("Postfix increment i++ = %d, i = %d\n", j, i);
    
    k = ++temp; // increment i, then return i
    printf("Prefix increment ++i = %d, i = %d\n", k, temp);

    return 0;
}

