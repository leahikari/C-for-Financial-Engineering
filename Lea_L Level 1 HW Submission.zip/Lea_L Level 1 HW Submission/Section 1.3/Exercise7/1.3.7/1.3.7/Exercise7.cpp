// Lea LI
// Exercise 1.3.7
// Muliply an integer by 2^n using bitwise left shift

#include <stdio.h>

int main()
{
    int i;// number to be multiplied
    int n;// n is the power of factor 2
    int result;
    printf("Type an integer to be mulitplied by 2^n and the power n (split by space): ");
    scanf("%d %d", &i, &n);
    result = i << n; // logical shift to left by n digits
    printf("%d * (2^%d) = %d\n", i, n, result);
    //Shifting left by n bits on a signed or unsigned binary number has the effect of multiplying it by 2^n

    return 0;
}


