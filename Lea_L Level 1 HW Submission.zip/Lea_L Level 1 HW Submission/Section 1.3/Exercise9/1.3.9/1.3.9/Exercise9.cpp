// Lea LI
// Exercise 1.3.9
// Conditional expressions

#include <stdio.h>
int main()
{
    int x=1;
    int y=1;
    int z=1;
    x+=y+=x;//till here y=2 and x=3
    
    printf("%d\n", (x<y)?y:x); //3 - False so return x
    printf("%d\n", (x<y)?x++:y++); //2 - False so return y++ and y increament by 1
    printf("%d\n", x); // 3
    printf("%d\n", y); // 3
    
    return 0;
}
