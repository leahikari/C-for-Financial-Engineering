// Lea LI
// Exercise 1.4.3
// Purpose: Caculate the amount of characters, the amount of words and the amount of newlines that have been typed using switch case statement

#include <stdio.h>

int main()
{
    int count_char = 0; // number of the characters
    int count_line = 1; // default line number initiate to 1
    int count_words = 0; // number of words
    
    char cur_char;  // current character
    char pre_char = ' '; // previous characterchar c;
    
    printf("Input the text and press CTRL + D to stop: \n");
    // reading of characters from the keyboard can be stopped when the shutdown-code ^D (CTRL + D) is entered
    
    while ((cur_char = getchar())!= EOF)
    {
        ++count_char;
        switch (cur_char) //switch case on current character
        {
                
            case ' ':     // no increase in number of the lines and words, exit the switch to evaluate next char
                break;
            case '\n':             // check if current character is '\n'
                ++count_line;       // increase the number of line - no break, we need to further check previous character to count words
            default :
                switch (pre_char) // check if user type a new word
                {
                    // previous char is space or \n and curent char is not then we can count as a new word
                    case ' ':
                        ++count_words;
                        break; // already count new word, exit the sub-switch
                    case '\n':
                        ++count_words;
                        break;
                    default: // no new word was typed
                        break;
                }
                break;
        }
        pre_char = cur_char; // update previous typed character to new typed character
    }
    printf("\nnumber of lines = %d\nnumber of characters = %d\nnumber of words = %d\n", count_line, count_char, count_words);
    return 0;
}



