// Lea LI
// Exercise 1.4.6
// Purpose: Caculate the amount of times a certain number has been typed using switch case

#include <stdio.h>
int main()

{
    int count_0 = 0;
    int count_1 = 0;
    int count_2 = 0;
    int count_3 = 0;
    int count_4 = 0; // initialising variables counting amount of times 0-4 have been typed
    int count_other = 0;
    char cur_char;    // declare current chatacter typed

    printf("Input any number or character and stop with ^D (EOF):\n");

    while ((cur_char = getchar()) != EOF) // check if current character is EOF
    {
        switch (cur_char)  // swtich-case on current character typed
        {
        case '0':
            ++count_0;    // typed character is '0', increase the number of times of zero typed
            break;        // jump out the switch loop to check next character

        case '1':
            ++count_1;
            break;
        
        case '2':
            ++count_2;
            break;

        case '3':
            ++count_3;
            break;

        case '4':
            ++count_4;
            break;

        default:         // if typed character is other character including \n (new line) and \r (space)
            ++count_other;
            break;
        }
    }
    // print the amount of times a certain number or other character has been typed
    printf("Number zero appears %d times\n", count_0);
    printf("Number one appears %d times\n", count_1);
    printf("Number two appears %d times\n", count_2);
    printf("Number three appears %d times\n", count_3);
    printf("Number four appears %d times\n", count_4);
    printf("Other characters appears %d times\n", count_other);
    
    return 0;

}



