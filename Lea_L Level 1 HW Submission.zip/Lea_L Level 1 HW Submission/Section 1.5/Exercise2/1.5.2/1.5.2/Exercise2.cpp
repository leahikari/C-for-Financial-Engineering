// Lea LI
// Exercise 1.5.2
// Purpose: Print factorials of an integer using recursive function

#include <stdio.h>

long int factorial(long int a)
{
    if (a>1)
    {
        long int r = a * (a-1);
        return r * factorial(a-2);
    }
    else
    {
        return 1;
    }
}

int main()
{
    printf("Please type a positive integer:\n"); //factorial is only defined for non-negative integer
    long int number = 0;
    scanf("%ld",&number);
    if (number >= 0)
    {
        printf("The factorial of %ld is: %ld\n", number, factorial(number));
    }
    else
    {
        printf("Factorials are nor defined for negative integers\n");
    }
    return 0;
}

