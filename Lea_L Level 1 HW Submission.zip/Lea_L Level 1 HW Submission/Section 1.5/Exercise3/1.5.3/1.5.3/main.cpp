// Lea LI
// Exercise 1.5.3
//Main function call print() from Print.c

#include <stdio.h>
#include "Print.hpp"

void print(double a);


int main()
{
    double i;//declare the variable i
    printf("Enter a number for calculation\n");
    scanf("%lf",&i);
    print(i);

    return 0;
}
