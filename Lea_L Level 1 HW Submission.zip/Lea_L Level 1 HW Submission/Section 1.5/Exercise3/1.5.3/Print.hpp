//  Print.hpp
//  1.5.3


#ifndef Print_hpp
#define Print_hpp

#include <stdio.h>
void print(double a); // declare the function print
#endif /* Print_hpp */
