// Lea LI
// Exercise 1.5.4
// Purpose: A recursive function printnumber() to print the number digit by digit

#include <stdio.h>
void printnumber(int num);//declare the function

int main()
{
    int number; // declare the number you want display
    printf("Enter the number you want to display digit by digit: \n");
    scanf("%d", &number);
    printf("The function printnumber gives: "); // call printnumber function
    printnumber(number);
    
    return 0;

}

void printnumber(int a)
{
    if (a < 0)// check if the number is negative
    {
        putchar('-'); // print the negative sign
        a = (-1)*a; // transfer to a positive number
        printnumber(a);
    }
    
    else if ( a / 10 == 0) // if it comes to the last digit
    {
        putchar(a % 10+'0');
    }
    else
    {
        printnumber (a / 10);// start from printing the number in most significant digit
        putchar (a % 10+'0');
    }
}


