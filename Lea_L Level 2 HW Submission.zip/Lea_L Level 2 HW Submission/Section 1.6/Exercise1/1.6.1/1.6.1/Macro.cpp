// Lea LI
// Exercise 1.6.1
// Purpose: Predefine macros to print variables

#include <stdio.h>
#include "Defs.hpp"

int main()
{
    int a, b; // declare two variables as arguments for running macros
    printf("Please enter two integers a and b (split by space):\n");
    scanf("%d %d", &a, &b); // get input from user

    printf("Macro PRINT1 gives: ");
    PRINT1(a); // call Macro PRINT1
    
    printf("Macro PRINT2 gives: ");
    PRINT2(a,b); // call Macro PRINT2

    return 0;
}
