// Lea LI
// Exercise 1.6.1
// Header file predefines macros for printing variables


#ifndef DEFS_H // check if constant DEFS_H is not defined
#define DEFS_H // then define constant DEFS_H to prevent multiple inclusion

#include <stdio.h> // declare the source file for printf that we will use to create macro
#define PRINT1(a) (printf("%d\n",a)) // define functions that print variables
#define PRINT2(a,b) (printf("%d %d\n",a,b))

#endif // DEFS_H

