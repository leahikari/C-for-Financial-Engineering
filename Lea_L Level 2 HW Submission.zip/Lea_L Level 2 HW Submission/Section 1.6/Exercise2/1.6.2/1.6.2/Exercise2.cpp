// Lea LI
// Exercise 1.6.2
// Purpose: Calculate the Max number using predefined macros in header file

#include <stdio.h>
#include "Defs.hpp" // declare the header file including macros to use

int main()
{
    int x, y, z; // declare three variables x, y, z

    printf("Please enter three integers x, y and z (split by space):\n");
    scanf("%d %d %d", &x, &y, &z);// get input of three integers from user
    printf("The maximum value of %d and %d is %d.\n", x,y,MAX2(x, y));// Use MAX2 to print the maximum value of x and y
    printf("The maximum value of %d,%d and %d is %d.\n", x,y,z,MAX3(x, y, z)); // MAX3 results came from calling macro MAX2
    
    return 0;
}
