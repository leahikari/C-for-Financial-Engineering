// Lea LI
// Exercise 1.6.2
// Header file predefines macros to return the maximum


#ifndef DEFS_H // check if constant DEFS_H is not defined
#define DEFS_H // then define constant DEFS_H to prevent multiple inclusion

#define MAX2(x,y) ((x > y)? x : y) // use conditional operator to return maximum of x and y
#define MAX3(x,y,z) MAX2(MAX2(x,y),z) // use of the macro MAX2 to return maximum value of x, y and z

#endif // DEFS_H
