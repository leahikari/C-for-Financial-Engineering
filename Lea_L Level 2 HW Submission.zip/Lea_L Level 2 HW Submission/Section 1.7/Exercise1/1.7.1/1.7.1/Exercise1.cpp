// Lea LI
// Exercise 1.7.1
// Purpose: Create a Swap function to exchange input value by using pointers as arguments


#include <stdio.h>
void Swap(int* i, int* j);// declare the swap function

void Swap(int* i, int* j)// use pointers as arguments so that their original value will be changed as well
{
    int temp = (*i);// retain contents of address i in a temporary variable
    (*i) = (*j); // contents of address i is changed to contents of address j
    (*j) = temp; // contents of address j is changed to value of var temp i.e. contents of address i
}

int main()
{
    int i,j;// declare the variables
    printf("Please enter two integers i and j (split by space):\n");
    scanf("%d %d", &i, &j);// get input from user
    Swap(&i, &j);// call swap function, arguments passed to the function are the addresses of variables
    
    printf("After swaped their value:\n");
    printf("%d %d\n",i, j);// print the swaped value of i and j
    return 0;
}
