// Lea LI
// Exercise 1.7.2
// Purpose: Create function Length() that determines the length of a string,which have the same effect with the built-in function strlen()

// Calculate the length of a string
#include <stdio.h>
#define MAXLINE 30 // String lenght declaration
int Length(char str[]);// declare the function Length

int main()
{
    char string[MAXLINE+1]; // Line of maxium 30 chars + \0
    int c; // The input character
    int i=0; // The counter
    // Print intro text
    printf("Type up to %d chars. Exit with ^D\n", MAXLINE);// press Ctrl+D to when input stops in Xcode
    // Get the characters
    while ((c=getchar())!=EOF && i<MAXLINE)
    {
    // Append entered character to string
    string[i++]=(char)c;
    }
    string[i]='\0'; // String must be closed with \0
    printf("String length is %d\n", Length(string));
    return 0;
}

// Implement of the Length() function
int Length(char str[])
{
    int len = 0; // Initialise a variable len to store the length of a string
    while (str[len] != '\0')
    // we stop to increment the length till we encounter the ‘\0’ character since a string is always ended up with ‘\0’ in C
    {
        len++;// // current character is in the string so increment the variable len
    }
    return len;
}
