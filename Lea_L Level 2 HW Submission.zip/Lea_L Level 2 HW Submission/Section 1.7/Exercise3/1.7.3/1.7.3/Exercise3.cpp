// Lea LI
// Exercise 1.7.3
// Purpose: Predict what will be printed on the screen

#include <stdio.h>
#define PRD(a) printf("%d", (a) ) // Print decimal
#define NL printf("\n"); // Print new line

int a[]={0, 1, 2, 3, 4}; // Create and initialse array
int main()
{
    int i;
    int* p;
    for (i=0; i<=4; i++) PRD(a[i]); // 01234
    // Print each element of array a by order
    NL;
    for (p=&a[0]; p<=&a[4]; p++) PRD(*p);// 01234
    // p points to the array a (equivalent to the address of first element of array a),print each element with address index incrementing
    NL;
    NL; // Print blank line
    for (p=&a[0], i=0; i<=4; i++) PRD(p[i]); // 01234
    // p points to the array a (equivalent to the address of first element of array a),print each element of array a in order
    NL;
    for (p=a, i=0; p+i<=a+4; p++, i++) PRD(*(p+i)); // 024
    // p points to the array a and to print *(p+i) is to print p[i]
    // Each time for loop increment both address index(p++) and array index(i++) till we reach the last elelemt of array
    // a+4 is the content of address that is 4 address index later than the first element,i.e the last element of array a
    NL;
    NL; // Print blank line
    for (p=a+4; p>=a; p--) PRD(*p); // 43210
    // p points to the last element of array a
    // Each time for loop print element of array strating from the last element and decrement address index(p--)
    NL;
    for (p=a+4, i=0; i<=4; i++) PRD(p[-i]); // 43210
    // p points to the last element of array
    // p[-i] refers to the address i before the starting point so we print the elements of array a inversely
    NL;
    NL; // Print blank line
    for (p=a+4; p>=a; p--) PRD(a[p-a]); // 43210
    // p points to the last element of array a[4]=4
    // a is equivalent to the address of a[0]=0, so we start print from a[4-0]=a[4] with p decrement in address index
    NL;
    return 0;
}
