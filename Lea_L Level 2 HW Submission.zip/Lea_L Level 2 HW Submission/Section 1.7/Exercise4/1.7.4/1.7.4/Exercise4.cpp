// Lea LI
// Exercise 1.7.4
// Purpose: Create a function DayName() that prints the day in words of a given number

#include <stdio.h>

void DayName(int num_day);// Declare the Dayname function
void DayName(int num_day)
{
    char day[7][10]= {"Monday", "Tuesday", "Wednesday","Thursday", "Friday", "Saturday", "Sunday"};
    // nitialize a 2D array that stores the day in words
    if (num_day >= 1 && num_day <= 7) // check if given number in the range of 1-7
    {
        printf("Day %d is %s\n\n", num_day, day[num_day - 1]);// Print the result of index num_day -1 since array index begins from 0
    }
    else
    {
        printf("Input Error.\n"); // Print error message if input number is out of the 1-7
    }
}

int main()
{
    int day_number = 0; // Declare and initialise the variable num_day to store the day number
    printf("Please enter a day number (within a week, range from 1 to 7):\n");
    scanf("%d", &day_number);
    DayName(day_number); // Call the function DayName
    return 0;
}
