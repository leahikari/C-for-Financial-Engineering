// Lea LI
// Exercise 1.8.1
// Purpose: Print the contents of a struct called Article

#include <stdio.h> // Decalre the library where contains printf

void Print(); // Declare the function Print

struct Article // Declare the structure Article and specifies its members
{
    long int article_number;
    int quantity;
    char description[20];
};

void Print(Article* article_1) // Define the Print function to print the contents of structure Article
{
    printf("Article number: %ld\n", article_1->article_number);
    printf("Quantity      : %d\n", article_1->quantity);
    printf("Description   : %s\n", article_1->description);
}

int main()
{
    Article article = {20005678, 10, "Test_Article"}; // Initialize structure's content
    Print(&article); // Call by address, use pointers passing structures to function Print
    return 0;
}




