// Lea LI
// Exercise 1.9.1
// Purpose: Reads characters from the keyboard and shows them on screen

#include <stdio.h> // Declare the library where includes printf

int main()
{
    printf("Please type some characters and press 'Enter' to display\n");
    char c; //Declare character c
    while ((c=getchar())!=1) //Check if the typed character is ^A
    {
        if (c!= '\n')   //if the character is not enter
        {
           
            putchar(c); // Output to screen till Enter is pressed
        }
        else
        {
            printf("\n");// Output next line of contents, enter will not end the program
        }
    }
    printf("CTRL + A is a correct ending.\n");  // Exit while loop if ^A is entered
    return 0;//

}
