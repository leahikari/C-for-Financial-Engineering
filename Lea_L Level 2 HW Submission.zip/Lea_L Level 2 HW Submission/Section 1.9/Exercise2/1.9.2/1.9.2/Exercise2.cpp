// Lea LI
// Exercise 1.9.2
// Purpose: Read characters from the keyboard and let the output written to a file

#include <stdio.h>

int main()
{
    FILE* txt_file;  // Declare a file variable
    char filename[] ="Input.txt"; // Declare and initialise a string to store the file name
    
    printf("Please enter the name file in format filename.txt \n");
    scanf("%s", filename); // Get input of file name from user
    printf("The file name is %s\n",filename);
    printf("Type some text you want to save in the %s and press Ctrl+A to end\n", filename);
    
    txt_file = fopen(filename, "w"); // Create the file that stores further input, oepn for write
    
    char c; // Declare variable that stores input
    
    while ((c=getchar())!=1) //Check if the typed character is ^A
    {
        fputc(c, txt_file);  // Write to the file
    }
    
    fclose(txt_file);// Close the file
    printf("Your text successfully saved into file %s\n\n", filename); // remind user the file is s
    return 0; // return 0 to end program
    
}
