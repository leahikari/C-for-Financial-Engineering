// Point.cpp
// Lea LI
// Level 3 - Exercise 2.2.1
// Implementation file for Points in two dimensions - x and y.
// Created at 2023/07/19

#include "Point.hpp"    // Include header file that contains declaration of class Point
#include <sstream>      // Standard library header providing string stream classes
#include <iostream>     // Standard library header for input and output streams
using namespace std;

// Default constructor initialization
Point::Point() : m_x(0), m_y(0) // Colon syntax
{

}

// Constructor Initialize using newX and newY, m_x = newX, m_y = newY
Point::Point(double newX, double newY) : m_x(newX), m_y(newY) // Colon syntax
{

}

// Destructor
Point::~Point()
{
    std::cout << "Bye~ my point..." << endl;
}

// Selectors
// Return the x value
double Point::GetX() const
{
    return m_x;
}

// Return the y value
double Point::GetY() const
{
    return m_y;
}

// Modifiers
// Set the x value
void Point::SetX(double newX)
{
    m_x = newX;
}

// Set the y value
void Point::SetY(double newY)
{
    m_y = newY;
}

// Returns string description of a point in format Point(x,y) by using stringstream
std::string Point::ToString()
{
    std::stringstream ss;                        // Create a stringstream object ss
    ss << "Point(" << m_x << ", " << m_y << ")"; // Set the content of ss (description of Point)
    return ss.str();                             // Gets the string object’s content
}



