// Point_Test.cpp
// Lea LI
// Level 3 - Exercise 2.2.1
// Simple test file for using class Point
// Created at 2023/07/19

#include "Point.hpp"    // Include header file that contains declaration of class Point
#include <iostream>     // Standard library header for input and output streams
using namespace std;

int main()
{
    double x, y; // Declaration of 2 variables to store x and y coordinates
    cout << "Please enter x coordinate:" << endl;
    cin >> x; // Get input of x coordinate from user

    cout << "Please enter y coordinate:" << endl;
    cin >> y; // Get input of y coordinate from user

    Point p1; // Create a point using default constructor (takes no arguments)
    
    p1.SetX(x); // Set the x coordinate entered by the user
    p1.SetY(y); // Set the y coordinate entered by the user

    // Print the description of the point using ToString() function
    cout << "The point is: " << p1.ToString() << endl;
    // Print the point coordinates using the get function
    cout << "The x-coordinate is: " << p1.GetX() << endl;
    cout << "The y-coordinate is: " << p1.GetY() << endl;

    return 0;// End of program
}
