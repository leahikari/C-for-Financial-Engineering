// Point.hpp
// Lea LI
// Level 3 - Exercise 2.2.2
// Header file for Points in two dimensions, x and y. Distance functions' declaration added to Point class

#ifndef Point_HPP
#define Point_HPP // Prevent multiple inclusion of header file

#include <iostream>   // Include standard input and output streams library

class Point

{
    
private:
    // Private members
    double m_x; // X coordinate data member
    double m_y; // Y coordinate data member

public:
    // Constrcutor and destructor
    Point();                           // Default constructor, takes no arguments
    Point(double newX, double newY);   // Constructor with x coordinate and y coordinate
    ~Point();                          // Destructor

    // Selectors
    // Set as const member functions so that state of object won't be changed
    double GetX() const;               // Get x-coordinate value
    double GetY() const;               // Get y-coordinate value

    // Modifiers
    void SetX(double new_X);           // Set x-coordinate value
    void SetY(double new_Y);           // Set y-coordinate value
    
    std::string ToString();                // Return string description of point
    double DistanceOrigin();         // Calculate the distance to the origin (0, 0)
    double Distance(Point p);        // Calculate the distance between two points
    
};

#endif // end of header Point_HPP

