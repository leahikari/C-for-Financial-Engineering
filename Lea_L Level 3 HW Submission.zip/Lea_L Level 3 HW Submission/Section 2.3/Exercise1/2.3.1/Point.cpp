// Point.cpp
// Lea LI
// Level 3 - Exercise 2.3.1
// Implementation file for Points in two dimensions - x and y. Distance functions' implementation added in source file
// Add a copy constructor that displays some text and another constrcutor that accepts x and y coordinates as arguments
// Created at 2023/07/19

#include "Point.hpp"    // Include header file that contains declaration of class Point
#include <sstream>      // Standard library header providing string stream classes
#include <iostream>     // Standard library header for input and output streams
#include <cmath>        // Contains a set of mathematical operations as part of implementation of distance function
using namespace std;

// Default constructor initialization
Point::Point() : m_x(0), m_y(0) // Colon syntax
{
    std::cout << "Default constructor is called" << endl;
}

// Constructor to create point from user input of x and y coordinates
Point::Point(double newX, double newY) : m_x(newX), m_y(newY) // Colon syntax
{
    std::cout << "Constrcutor taking x and y coordinate value is called " << endl;
}

// Copy constructor
Point::Point(const Point& p) : m_x(p.m_x), m_y(p.m_y) // Colon syntax
{
    cout << "Copy constructor is called" << endl;
}

// Destructor
Point::~Point()
{
    std::cout << "Call the destructor : Point destroyed."<< endl;
}

// Selectors
// Return the x value
double Point::GetX() const
{
    return m_x;
}

// Return the y value
double Point::GetY() const
{
    return m_y;
}

// Modifiers
// Set the x value
void Point::SetX(double newX)
{
    m_x = newX;
}

// Set the y value
void Point::SetY(double newY)
{
    m_y = newY;
}

// Returns string description of a point in format Point(x,y) by using stringstream
std::string Point::ToString()
{
    std::stringstream ss;                        // Create a stringstream object ss
    ss << "Point(" << m_x << ", " << m_y << ")"; // Set the content of ss (description of Point)
    return ss.str();                             // Gets the string object’s content
}

// Calculate distance to the origin (0, 0)
double Point::DistanceOrigin()
{
    return std::sqrt(m_x*m_x + m_y*m_y); // The Pythagoras algorithm
}

// Calculate distance to point p
double Point::Distance(Point p) // Takes Point object p as argument
{
    // Data members m_x and m_y are another point's x and y coordinates
    return std::sqrt(pow((p.m_x-m_x), 2) + pow((p.m_y-m_y), 2));
}



