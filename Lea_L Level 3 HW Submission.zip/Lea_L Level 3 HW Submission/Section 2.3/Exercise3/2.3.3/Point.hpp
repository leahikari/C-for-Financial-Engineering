// Point.hpp
// Lea LI
// Level 3 - Exercise 2.3.3
// Header file for Points in two dimensions, x and y
// Add extra constructors and observe how they get called in program
// let Distance() function pass the input point “by reference” so that no copy is made
// Using C++ function overloading: reset setters and getters to X() and Y(), rename DistanceOrigin() to Distance()

#ifndef Point_HPP
#define Point_HPP // Prevent multiple inclusion of header file

#include <iostream>   // Include standard input and output streams library

class Point

{
    
private:
    // Private members
    double m_x; // X coordinate data member
    double m_y; // Y coordinate data member

public:
    // Constrcutor and destructor
    Point();                           // Default constructor, takes no arguments
    Point(double newX, double newY);   // Constructor with x coordinate and y coordinate
    Point(const Point& p);             // Copy Constructor takes object of class Point as argument
    ~Point();                          // Destructor

    // Selectors
    // Set as const member functions so that state of object won't be changed
    double X() const;               // Get x-coordinate value
    double Y() const;               // Get y-coordinate value

    // Modifiers
    // Using function overloading to reset modifier member functions
    // Same name as selector member functions but return type and aruguments is different
    // Feasible as long as the combination of name and argument types is different
    void X(double new_X);           // Set x-coordinate value
    void Y(double new_Y);           // Set y-coordinate value
    
    std::string ToString();                // Return string description of point
    double Distance();               // Calculate the distance to the origin (0, 0),
    double Distance(const Point& p); // calculate the distance between two points
    // The input point of above function will be called by const reference
    
    
};

#endif // End of header Point_HPP


