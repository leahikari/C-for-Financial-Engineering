// Point_Test.cpp
// Lea LI
// Level 3 - Exercise 2.3.3
// Simple test file for using class Point, print distance between points, let Distance() pass argument by ref
// Observe how the constructors and destructor are called
// Test C++ function overloading
// Created at 2023/07/19

#include "Point.hpp"    // Include header file that contains declaration of class Point
#include <iostream>     // Standard library header for input and output streams
using namespace std;

int main()
{
    double x1, y1; // Declaration of 2 variables to store x and y coordinates of first point
    cout << "Please enter x coordinate for first point p1:" << endl;
    cin >> x1; // Get input of x coordinate from user

    cout << "Please enter y coordinate for first point p1:" << endl;
    cin >> y1; // Get input of y coordinate from user

    Point p1; // Create the first point using default constructor (takes no arguments)
    // Default constructor is called
    
    p1.X(x1); // Set the x coordinate entered by the user
    p1.Y(y1); // Set the y coordinate entered by the user
    
    double x2, y2; // Declaration of 2 variables to store x and y coordinates of second point
    cout << "Please enter x coordinate for second point p2:" << endl;
    cin >> x2; // Get input of x coordinate from user

    cout << "Please enter y coordinate for second point p2:" << endl;
    cin >> y2; // Get input of y coordinate from user

    Point p2(x2,y2); // Create the second point using another constructor
    // Constructor taking x and y coordinate value is is called
    
    // p2.SetX(x2);
    // p2.SetY(y2); we do not need set function to set x and y coordinates for p2
    

    // Print the description of two points using ToString() function
    // Print x,y coordinates: using overloaded function X() and Y() instaed of getters
    cout << "The first point p1 is: " << p1.ToString() << endl;
    cout << "The x-coordinate of p1 is: " << p1.X() << endl;
    cout << "The y-coordinate of p1 is: " << p1.Y() << endl;
    cout << "The second point p2 is: " << p2.ToString() << endl;
    cout << "The x-coordinate of p2 is: " << p2.X() << endl;
    cout << "The y-coordinate of p2 is: " << p2.Y() << endl;
    
    // Print distance from origin
    cout << "Distance from origin to p1 is: " << p1.Distance() << endl;
    cout << "Distance from origin to p2 is: " << p2.Distance() << endl;

    // Print distance between p1 and p2
    cout << "Distance between p1 and p2 is: " << p1.Distance(p2) << endl;
    // Using call by reference no copy constructor is called
    
    return 0;// Scope for p1 and p2 ends, their destructor is called
    
    // Observations:
    // We can overload the function by its name and arguments and to get rid of all the get and set prefixes
    // Contructor and destructor are both called 2 times, no copy constructor is called since Distance(const Point& p) is using call by reference
}
