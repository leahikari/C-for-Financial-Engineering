// Point_test_const.cpp
// Lea LI
// Level 3 - Exercise 2.3.4
// Simple test file for using class Point
// Test whether we will get compiler error if we change a const object
// Created at 2023/07/19

#include "Point.hpp"    // Include header file that contains declaration of class Point
#include <iostream>     // Standard library header for input and output streams
using namespace std;

    
int main()
{
    const Point cp(1.5, 3.9); // Create a const point object
    // cout << cp.X() << endl;   // Compiler error is we don't set X() as constant member function since compiler don't know if cp.X() would modify cp
    cout << "The const point cp is: " << cp.ToString() << endl;
    cout << "The x-coordinate of point cp: " << cp.X() << endl;
    //cp.X(0.3);  // Change x-coordinate leads to compiler error as well since cp is const object
    
    return 0;
}

