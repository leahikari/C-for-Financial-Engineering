// Line_Test.cpp
// Lea LI
// Level 3 - Exercise 2.3.5
// Simple test file for using class Line
// Created at 2023/07/20

#include "Line.hpp"   // Header file for line class
#include "Point.hpp"  // Header file for point class
#include <iostream>   // Include standard input and output streams library
using namespace std;
    
int main()
{
    // Initialize point objects p1 and p2
    Point p1(1, 1);
    Point p2(3, 4);
    
    // Initialize l1 with input p1 and p2
    Line l1(p1, p2); // Constrcutor taking two point objects is called
    cout << "Print the line l1: " << l1.ToString() << endl; // Print the description of l1 with ToString()
    cout << "The length of l1 is " << l1.Length()<< endl;   // Print the length of l1 - distance between p1 and p2
    
    // Create a new line l2
    Line l2;       // Default constructor is called and line_1 is initialized with start/end point(0,0)
    cout << "Print the line l2: " << l2.ToString() << endl; // Print l2 to check
    
    // Reset l2 using overloaded getters
    l2.startP(p1);
    l2.endP(p2);
    cout << "Print the line l2 using getters: " << l2.ToString() << endl; // Print the description of l2 with ToString()
    cout << "The length of l2 is : " << l2.Length()<< endl; // Print the length of l2 - distance between p1 and p2
    
    // Create a new line with different start and end point
    Point p3;
    p3 = l1.startP(); // Using overloaded getter to assign l1's startpoint
    p3.X(2);          // Modify the x-coodinate of p3
    Point p4;
    p4 = l1.endP();   // Using overloaded getter to assign l1's endpoint
    p4.Y(10);         // Modify the y-coodinate of p4
    
    Line l3(p3, p4);  // l3 with modified startpoint and endpoint
    cout << "Print the line l3 : " << l3.ToString() << endl;     // Print the description of l3 with ToString()
    cout << "The length of l3 is : " << l3.Length() << endl;  // Print the length of l3 - distance between p3 and p4
    
    return 0;
    
    // Observation:
    // We've got equal number of times when constructor and destructor called of Line class
    // We've also checked that function overlodaing worked well in C++
}
