// Circle_Test.cpp
// Lea LI
// Level 3 - Exercise 2.3.6
// Simple test program using Circle class with reference to Point class
// Created at 2023/07/20

#include "Circle.hpp"   // Header file for Circle class
#include "Point.hpp"    // Header file for Point class
#include <iostream>     // Include standard input and output streams library

using namespace std;

int main()
{
    double radius; // Initialize a variable to store radius
    double x,y;    // Initialize variables to store centre point coordinates

    // Get input of radius from user
    cout << "Please enter the radius:";
    cin >> radius;

    // Get input of x and y coordinates for centre point from user
    cout << "Please enter x coordinate for centre point:";
    cin >> x;
    cout << "Please enter y coordinate for centre point:";
    cin >> y;
    
    // Create a point p1 to store centre point coordinates
    Point p1(x, y);

    // Create a circle with input radius and p1 as centre point
    Circle c1 (p1, radius); // Constrcutor taking two arguments is called

    // Print description of the circle c1
    cout << c1.ToString();
    
    // Print the diameter
    cout << "Circle diameter : " << c1.Diameter() << endl;
    // Print the area
    cout << "Circle area : " << c1.Area() << endl;
    // Print the circumference
    cout << "Circle circumference : " << c1.Circumference() << endl;
    
    // Now modify the circle using p2 with radius r2
    Point p2(0,0);
    double r2 = 4;
    
    // Reset the circle using overloaded getters
    c1.CentrePoint(p2);
    c1.Radius(r2);
    cout << "New " << c1.ToString() << endl;
    // Print the diameter
    cout << "Circle diameter : " << c1.Diameter() << endl;
    // Print the area
    cout << "Circle area : " << c1.Area() << endl;
    // Print the circumference
    cout << "Circle circumference : " << c1.Circumference() << endl;
    return 0;
}
