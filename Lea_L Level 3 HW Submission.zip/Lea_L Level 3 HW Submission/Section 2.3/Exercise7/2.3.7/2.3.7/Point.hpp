// Point.hpp
// Lea LI
// Level 3 - Exercise 2.3.7
// Header file for Points in two dimensions, x and y
// Using normal inline function for the getters and default inline for the setters

#ifndef Point_HPP
#define Point_HPP  // Prevent multiple inclusion of header file

#include <iostream> // Include standard input and output streams library

class Point

{
    
private:
    // Private members
    double m_x; // X coordinate data member
    double m_y; // Y coordinate data member

public:
    // Constrcutor and destructor
    Point();                           // Default constructor, takes no arguments
    Point(double newX, double newY);   // Constructor with x coordinate and y coordinate
    Point(const Point& p);             // Copy Constructor takes object of class Point as argument
    
    ~Point();                          // Destructor

    // Selectors
    // Set as const member functions since they don't change the point object
    double X() const;               // Get x-coordinate value
    double Y() const;               // Get y-coordinate value

    // Modifiers
    void X(double new_X) { m_x = new_X; }   // Default inline function to set the x value
    void Y(double new_Y) { m_y = new_Y; }   // Default inline function to set the y value
    
    
    // Set as const member functions since they don't change the point object
    std::string ToString() const;          // Return string description of point
    double Distance() const;               // Calculate the distance to the origin (0, 0),
    double Distance(const Point& p) const; // Calculate the distance between two points

    
};

// Implementation of the normal inline function for the getter functions

inline double Point::X() const { return m_x; } // Normal inline function for x getter
inline double Point::Y() const { return m_y; } // Normal inline function for y getter

#endif // End of header Point_HPP


