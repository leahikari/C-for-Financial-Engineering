// Point_Test.cpp
// Lea LI
// Level 3 - Exercise 2.3.7
// Simple test file for using class Point
// Testing new Point header with inline functions
// Normal inline for the getters and default inline for the setters
// Created at 2023/07/20

#include "Point.hpp"    // Include header file that contains declaration of class Point
#include <iostream>     // Standard library header for input and output streams
using namespace std;

int main()
{
    // Initialize two variables to store x and y coordinates
    double x, y;

    // Get input of coordinates from user for the point
    cout << "Please enter x coordinate for the point: ";
    cin >> x;
    cout << "Please enter y coordinate for the point: ";
    cin >> y;

    // Create a point
    Point p1(x, y);

    // Return description of the point
    cout << p1.ToString() << endl;

    // Reset the x and y using inline setters
    p1.X(9);
    p1.Y(10);

    //Display the output using inline getters
    cout << "p1.x is: " << p1.X() << endl;
    cout << "p1.y is: " << p1.Y() << endl;

    return 0;
}

