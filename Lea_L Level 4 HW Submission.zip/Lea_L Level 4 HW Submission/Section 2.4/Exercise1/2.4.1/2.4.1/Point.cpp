// Point.cpp
// Lea LI
// Level 4 - Exercise 2.4.1
// Implementation file for Class Point with operator overloading
// Modified at: 2023/07/24 Implementation of several overloaded operators

#include "Point.hpp"    // Include header file that contains declaration of class Point
#include <sstream>      // Standard library header providing string stream classes
#include <iostream>     // Standard library header for input and output streams
#include <cmath>        // Contains a set of mathematical operations as part of implementation of distance function
using namespace std;

// Default constructor initialization
Point::Point() : m_x(0), m_y(0) // Colon syntax
{
    
}

// Constructor to create point from user input of x and y coordinates
Point::Point(double newX, double newY) : m_x(newX), m_y(newY) // Colon syntax
{
    
}

// Copy constructor
Point::Point(const Point& p) : m_x(p.m_x), m_y(p.m_y) // Colon syntax
{
    
}

// Destructor
Point::~Point()
{

}

// Selectors
// Return the x value
double Point::X() const
{
    return m_x;
}

// Return the y value
double Point::Y() const
{
    return m_y;
}

// Modifiers
// Set the x value
void Point::X(double newX)
{
    m_x = newX;
}

// Set the y value
void Point::Y(double newY)
{
    m_y = newY;
}

// Returns string description of a point in format Point(x,y) by using stringstream
std::string Point::ToString() const
{
    std::stringstream ss;                        // Create a stringstream object ss
    ss << "Point(" << m_x << ", " << m_y << ")"; // Set the content of ss (description of Point)
    return ss.str();                             // Gets the string object’s content
}

// Calculate distance to the origin (0, 0)
double Point::Distance() const
{
    return std::sqrt(m_x*m_x + m_y*m_y); // The Pythagoras algorithm
}

// Calculate distance to point p
double Point::Distance(const Point& p) const  // Use call by reference when passing objects to distacne function
{
    // Orginial object p will be passed to the function, set as const argument so that input object won't be changed
    return sqrt(pow((p.m_x-m_x), 2) + pow((p.m_y-m_y), 2));
}

// Negate the coordinates
Point Point::operator - () const
{
    return Point(-m_x, -m_y); // The additive inverse of the current point coordinates
}

// Scale the coordinates
Point Point::operator * (double factor) const
{
    return Point(factor*m_x, factor*m_y);  // Scale the x and y coordinates
}

// Add coordinates
Point Point::operator + (const Point& p) const
{
    return Point(m_x+p.m_x, m_y+p.m_y);    // Anonymous object
}

// Equally compare operator
bool Point::operator == (const Point& p) const
{
    return (m_x == p.m_x && m_y == p.m_y); // Check if both coordinates are equal
}

// Assignment operator
Point& Point::operator = (const Point& source) // Using reference to prevent unnecessary copy
{
    if (this == &source) // Avoid assigning to itself
        return *this;    // Return current point, no need to assign

    m_x = source.m_x;
    m_y = source.m_y;   // Assign new point's coordinates to current point object

    return *this;     
}

// Scale the coordinates & assign
Point& Point::operator*= (double factor)
{
    m_x = m_x * factor;
    m_y = m_y * factor;
    return *this;    // Return scaled point
}

