// TestProgram.cpp
// Lea LI
// Level 4 - Exercise 2.4.1
// Simple test program for overloaded operators on Point class
// Created at 2023/07/24

#include "Point.hpp"    // Header file for Point class
#include "Line.hpp"     // Header file for Line class
#include "Circle.hpp"   // Header file for Circle class
#include <iostream>     // Include standard input and output streams library
using namespace std;


int main()
{
    double x,y;    // Initialize variables to store point coordinates

    // Get input of x and y coordinates for centre point from user
    cout << "Please enter x coordinate for point p1:";
    cin >> x;
    cout << "Please enter y coordinate for point p1:";
    cin >> y;
    
    // Create a point object
    Point p1(x, y);
    
    // Print description of p1
    cout << "p1 is: " << p1.ToString() << endl;

    // Test unary operator - () that negates p1 coordinates
    Point p2 = - p1;
    cout << "p1.operator - () gives: " << endl;
    cout << p2.ToString() << endl; // Print result after negated

    // Test operator * (factor) that scales the point's coordinates
    Point p3 = p1 * 2.0;
    cout << "p1.operator * (2.0) gives: " << endl;
    cout << p3.ToString() << endl; // Print result after scaled

    // Test operator + (Point & p) that add coordinates
    Point p4 = p1 + p3; // Create p4 that adds coordinates of p1 and scaled p3
    cout << "p3 is: " << p3.ToString() << endl;
    cout << "p1.operator + (p3) gives: " << endl;
    cout << p4.ToString() << endl; // Print result after added by p3 coordinates

    // Test bool operator == (Point & p) that compares if coordinates of two points are equal
    cout << "p1.operator == (p1) gives: " << endl;
    cout << (p1 == p1) << endl; // Print (p1 == p1) result
    cout << "p1.operator == (p2) gives: " << endl;
    cout << (p1 == p2) << endl; // Print (p1 == p2) result

    // Test assignment operator
    cout << "p1 original coordinates are: " << p1.ToString() << endl;
    cout << "p2 original coordinates are: " << p2.ToString() << endl;
    p1 = p2; // Assign p2 to p1
    cout << "p1.operator = (p2) gives:" << p1.ToString() << endl;
    
    // Test scale& assign operator
    cout << "Test scale& assign operator " << endl;
    cout << "p1 original coordinates are: " << p1.ToString() << endl;
    p1 *= 2.0; // Scale p1's coordinate 2 times
    cout << "p1.operator *= (2.0) gives: " << endl;
    cout << p1.ToString() << endl;

    //Test chained assignment
    cout << "Test chained assignment" << endl;
    cout << "p1 original coordinates are: " << p1.ToString() << endl;
    cout << "p2 original coordinates are: " << p2.ToString() << endl;
    cout << "p1 = p2*=2.0 gives" << endl;
    p1 = p2 *= 2.0;
    cout << "p1 becomes "<< p1.ToString() << " and p2 becomes "<< p2.ToString() << endl;


    // Test assignment operator for Line class
    Line l1(p1, p3);
    Line l2(p3, p4); // Create two line objects l1 and l2
    cout << "l1 : "<< l1.ToString() << endl;
    cout << "l2 : "<< l2.ToString() << endl;
    l1 = l2; // Assign l2 to l1
    cout << "Test assignment operator for Line class l1=l2 gives: " << endl;
    cout << "l1 becomes: "<< l1.ToString() << endl;


    //Test assignment operator for Line class
    Circle c1(p1, 2);
    Circle c2(p3, 3); // Create two circle objects c1 and c2
    cout << "c1 : "<< c1.ToString() << endl;
    cout << "c2 : "<< c2.ToString() << endl;
    c1 = c2; // Assign c2 to c1
    cout << "Test assignment operator for Circle class c1=c2 gives: " << endl;
    cout << "c1 becomes: "<< c1.ToString() << endl;

    return 0;
}
