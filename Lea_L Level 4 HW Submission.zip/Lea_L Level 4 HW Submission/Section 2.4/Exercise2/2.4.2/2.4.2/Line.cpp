// Line.cpp
// Lea LI
// Level 4 - Exercise 2.4.2
// Implementation file for Class Line
// Modified at: 2023/07/24 Implementation of assignment operator to Line class
// Modified at: 2023/07/25 Implementation of Ostream << Operator


#include "Line.hpp"   // Header file for line class
#include "Point.hpp"  // Header file for point class
#include <iostream>   // Include standard input and output streams library
#include <sstream>    // Standard library header providing string stream classes
#include <cmath>      // Standard library header providing Contains a set of mathematical operations
using namespace std;

// Default constructor initializes both points to (0,0)
Line::Line() : startPoint(0,0), endPoint(0,0) // Colon syntax
{
    //std::cout << "Default constructor is called" << std::endl;
}

// Constructor assigning new startPoint and new endPoint
Line::Line(const Point& newStartPt, const Point& newEndPt)
{
    startPoint = newStartPt;
    endPoint = newEndPt;
    //std::cout << "Constructor taking two Points is called" << std::endl;
}

// Copy constructor
Line::Line(const Line& l)
{
    startPoint = l.startPoint;
    endPoint = l.endPoint;
    //std::cout << "Copy constructor is called" << std::endl;
    
}

// Destructor
Line::~Line()
{
    std::cout << "Bye~ my line." << std::endl;
}


// Selectors
// Return the start-point
Point Line::startP() const
{
    return startPoint;
}

// Return the end-point
Point Line::endP() const
{
    return endPoint;
}


// Modifiers
// Set the start-point
void Line::startP(const Point& newStartPt)
{
    startPoint = newStartPt;
}

// Set the end-point
void Line::endP(const Point& newEndPt)
{
    endPoint = newEndPt;
}

// Return the description of the line in using stringstream
std::string Line::ToString() const
{
    std::stringstream ss; // Create a stringstream object ss
    ss << "Line starts at " << startPoint.ToString() << " and ends at " << endPoint.ToString();
    return ss.str();      // Return line description

}

// Return the length of a line
double Line::Length() const
{
    return startPoint.Distance(endPoint); // Delegation of Distance function declared in header
}

// Assignment operator
Line& Line::operator =  (const Line& c)  // Using reference to prevent unnecessary copy
{
    if (this == &c)   // Avoid assigning to itself
    {
        return *this; // Return current Line object
    }
    startPoint = c.startPoint;
    endPoint = c.endPoint; // Assign new line's start/end points to current Line object

    return *this;
}

// Send to ostream
ostream& operator << (ostream& os, const Line& l)
{
    os << l.ToString(); // Get the string of Line description and send to the os argument
    return os; // Return os by reference
}
