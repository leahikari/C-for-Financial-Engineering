// TestProgram.cpp
// Lea LI
// Level 4 - Exercise 2.4.2
// Simple test program for Ostream << Operator
// Created at 2023/07/24

#include "Point.hpp"    // Header file for Point class
#include "Line.hpp"     // Header file for Line class
#include "Circle.hpp"   // Header file for Circle class
#include <iostream>     // Include standard input and output streams library
using namespace std;


int main()
{
    double x,y;    // Initialize variables to store point coordinates

    // Get input of x and y coordinates for centre point from user
    cout << "Please enter x coordinate for centre point:";
    cin >> x;
    cout << "Please enter y coordinate for centre point:";
    cin >> y;
    
    // Create a point object
    Point p1(x, y);
    Point p2 = p1 * 2.0; // Create p2 using scale operator
    Line l1(p1,p2);      // Create line l1 using p1 and p2
    Circle c1(p1,2.0);   // Create circle c1 using p1 and radius 2
    
    // Now we can test ostream operator << for all class
    cout << " Print point p1 using << : " << p1 << endl;
    cout << " Print line l1 using << : " << l1 << endl;
    cout << " Print circle c1 using << : " << c1 << endl;

    return 0;
}
