// TestProgram.cpp
// Lea LI
// Level 4 - Exercise 2.4.3
// Simple test program for constructors as implicit & conversion operator
// Created at 2023/07/25

#include "Point.hpp"    // Header file for Point class
#include <iostream>     // Include standard input and output streams library
using namespace std;


int main()
{
    
/*
    Point p(1.0, 1.0);
    if (p==1.0) cout<<"Equal!"<<endl;
    else cout<<"Not equal"<<endl;
 */
 
    // Above piece of code would compile and run if we didn't decalre constructor as explicit, and will return Equal!
    // This is because the 1.0 in the if statement is implicitly converted to a Point object (1.0,1.0) by constrcutor that is used as implicit conversion operator
    // If we declare constrcutor as explicit it will give compiler error
    
    Point p(1.0, 1.0);
    if (p==(Point)1.0) cout<<"Equal!"<<endl; // Explicitly convert double 1.0 to a point object (1.0,1.0)
    else cout<<"Not equal"<<endl;
    // In this case to compile the program we can only explicitly use constructor conversion
    // Now the program would compile and will return Equal!


    return 0;
}
