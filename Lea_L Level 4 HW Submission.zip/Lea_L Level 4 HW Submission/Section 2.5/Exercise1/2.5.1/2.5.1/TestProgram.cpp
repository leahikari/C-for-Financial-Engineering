// TestProgram.cpp
// Lea LI
// Level 4 - Exercise 2.5.1
// Simple test program : create Point objects and array of points on the heap with new and delete
// Created at 2023/07/25

#include "Point.hpp"    // Header file for Point class
#include <iostream>     // Include standard input and output streams library
using namespace std;


int main()
{
    // Create points objects on the heap
    Point* p1 = new Point;      // With default constructor
    Point* p2 = new Point(2,4); // With constructor
    Point* p3 = new Point(*p2); // With copy constructor
    
    // Call the Distance() function on the pointers
    cout << "Distance between p1 and p2 : " << p1->Distance(*p2) << endl;
    // Send the Point pointers to cout
    cout << "p1: " << *p1 << " p2: "<< *p2 <<" p3: "<< *p3 << endl;
    
    // Deallocating memory created on the heap: destructor get called
    delete p1;
    delete p2;
    delete p3;
    
    // Create int variable length to store array size
    int length;
    cout << "Please enter the length of array :";
    cin >> length;
    
    //Point points_array[length]; // Compiler error in C++ standard
    
    // Create an array of points on the heap using new
    Point* point_array = new Point[length]; // Only default constructor is called
    
    for (int i = 0; i < length; i++)
    {
        cout << point_array[i] << endl;
    }
    delete[] point_array; // Delete the array after use
    
    // We can observe that the number of times when default constructor get called is equal to the size of array
    return 0;
}
