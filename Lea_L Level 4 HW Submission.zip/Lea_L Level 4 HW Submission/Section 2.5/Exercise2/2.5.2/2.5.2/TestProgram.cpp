// TestProgram.cpp
// Lea LI
// Level 4 - Exercise 2.5.2
// Simple test program : Creating Array of Pointers
// Created at 2023/07/25

#include "Point.hpp"    // Header file for Point class
#include <iostream>     // Include standard input and output streams library
using namespace std;

int main()
{
    int array_size = 3;  // Initialize an int variable to store the array size
    
    // Create an array of Point pointers with 3 elements on the heap
    Point** points_arr = new Point*[array_size];
    
    for (int i = 0; i < array_size; i++)
    {
        // Create for each element a point on the heap
        points_arr[i] = new Point(i+1, i+2); // Using constructor other than default constructor
    }
    // Iterate the array the print each point in the array
    for (int i = 0; i < array_size; i++)
    {
        cout << *points_arr[i] << endl;
    }
    
    // Iterate the array again and delete each point in the array
    for (int i = 0; i < array_size; i++)
    {
        delete points_arr[i];
    }
    // Delete the array itself
    delete[] points_arr; // Do not forget the brackets

    return 0;
}
