// TestProgram.cpp
// Lea LI
// Level 4 - Exercise 2.5.3
// Simple test program for array clas
// Created at 2023/07/25

#include "Point.hpp"    // Header file for Point class
#include "Array.hpp"    // Header file for Array class
#include <iostream>     // Include standard input and output streams library
using namespace std;


int main()
{
    // Test different constrcutors to initialize array
    Array array1;           // Defualt constructor gets called
    Array array2(3);        // Initialize an array of length 3
    
    // At first test Size()
    // Print each element in array1 using [] operator
    // Check if default constructor allocates 10 elements in an array
    cout << "The size of default array1 is: " << array1.Size() << endl;
    for (int i = 0; i < array1.Size(); i++)
    {
            cout << array1[i] << endl;
    }
        
    // Create some Point objects
    Point p1;            // Default constructor initializes p1 to (0,0)
    Point p2(3,4);
    Point p3 = p2 * 2.0; // Using scale operator defined in header file
        
    // Add Point objects to array2 using setter
    array2.SetElement(0, p1);
    array2.SetElement(1, p2);
    array2.SetElement(2, p3);
        
    Array array3 = array2;  // Assign array2 to array3
    
    // Check if assignment operator functions well
    cout << "The size of array3 is: " << array3.Size() << endl;
    // Get elmement of array3 to
    for (int i = 0; i < array3.Size() ; i++)
    {
        cout << array3.GetElement(i) << endl;
    }
    
    // Test if GetElement() returns the first element when out of array bounds
    cout << array3.GetElement(array3.Size()+2) << endl;
    
    // Test [] operator that writes elements in array1
    for (int i = 0; i < array1.Size(); i++)
    {
        array1[i] = p2; // Writes elements
        cout << array1[i] << endl; // Reads elements
    }
    
    // Test if copy constrcutor functions well
    Array array_copy(array2);

    // Output each element in array_copy to check
    for (int i = 0; i < array_copy.Size(); i++)
    {
        cout << array_copy[i] << endl;
    }
    
    const Array array4(1); // Create a const Array that allocates one element in the array, default constructor gets called
    //array4[0] = p2;      // I cannot assign since as const[] is read only and array4 is const
    cout << array4[0] << endl;
    
    return 0;


}
    
    
   
