// Array.cpp
// Lea LI
// Level 4 - Exercise 2.6.1
// Implementation file for array Class

#include "Array.hpp"  // Header file for Array class
#include "Point.hpp"  // Header file for point class
using namespace std;
using namespace LeaLI;
using namespace Container;

// Default constructor allocates 10 elements in an array
// The new operator allocates a contiguous block of memory large enough to hold <size> number of points
// For each point object on the array, the default constructor gets called
// Since default constructor of Point class initialises object to (0,0), we will get an array of 10 Points (0,0)
Array::Array(): m_data(new CAD::Point[10]), size(10) // Colon syntax
{

}

// Constructor with a size argument
// We will get an array of <newSize> number of Points (0,0)
Array::Array(int newSize)
{
    m_data = new CAD::Point[newSize];  // Create a　dynamic array that allocates number of elements specified by newSize input
    size = newSize;               // Assign new_size to private member size
}

// Cpy constructor
Array::Array(const Array& newArray)
{
    m_data = new CAD::Point[newArray.size]; // Create a dynamic array with same size as newArray

    // Using for loop to copy each element separately
    for (int i = 0;i < newArray.size; i++)
    {
        m_data[i] = newArray.m_data[i]; // Assign element by element
    }
    size = newArray.size; // Assign the size of newArray to current array size
    cout << "Copy constructor is called." << endl;
}

// Destructor
Array::~Array()
{
    
    delete[] m_data; // Delete the internal C array

}

// Assignment operator
// The assignment operator is called when the object that is destined to be the copy already exists
// We have to clear old data before copying the data members
Array& Array::operator = (const Array& newArray)
{
    if (this == &newArray) // Avoid assign to itself
    {
        return *this; // Return current array object
    }

    delete[] m_data;// Delete the old C array and allocate new memory before copying elements
    
    // Create a new dynamic array with the same size of newArray
    m_data = new CAD::Point[newArray.size];
    // Using for loop to assign each element separately
    for (int i = 0;i < newArray.size; i++)
    {
        m_data[i] = newArray.m_data[i];
    }

    return *this; // Return assigned object
}


// Returns the size of the array
const int& Array::Size() const
{
    return size;
}

// Set index-th element with Point p
void Array::SetElement(int index, const CAD::Point& p)
{
    if (index >= 0 && index < size) // Check if ndex is in the bound of m_data
    {
        m_data[index] = p; // Assign p to element at index <index>, we have already defined assignment operator for Point clas
    }

}

// Get an indexed element by reference
const CAD::Point& Array::GetElement(int index) const
{
    if (index >= 0 && index < size) // Check if ndex is in the bound of m_data
    {
        return m_data[index];  // Return the element by reference at index <index>
    }
    else
    {
        return m_data[0];  // Return the first element when the index is out of bounds
    }
}

// [] operator used for both readingand writing points
CAD::Point& Array::operator [] (int index)
{
    if (index >= 0 && index < size) // Check if ndex is in the bound of m_data
    {
        return m_data[index]; // Return the element by reference at index <index>
    }
    else
    {
        return m_data[0]; // Return the first element when the index is out of bounds
    }
}

// [] overloaded operator avoiding change of object state, read only
const CAD::Point& Array::operator [] (int index) const
{
    if (index >= 0 && index < size) // Check if ndex is in the bound of m_data
    {
        return m_data[index]; // Return the element by reference at index <index>
    }
    else
    {
        return m_data[0];  // Return the first element when the index is out of bounds
    }
}
