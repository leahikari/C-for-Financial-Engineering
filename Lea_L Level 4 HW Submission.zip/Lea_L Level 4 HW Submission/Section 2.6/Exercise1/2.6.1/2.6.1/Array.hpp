// Array.hpp
// Lea LI
// Level 4 - Exercise 2.6.1
// Header file for array class
// Put array class into namespace LeaLI::Container

#ifndef Array_HPP
#define Array_HPP    // Prevent multiple inclusion of header file
#include "Point.hpp" // Include header file of point class

namespace LeaLI
{
    namespace Container
    {
        class Array
        {
            
        private:
            // Declare private members
            CAD::Point* m_data; // A Dynamic C array of Point objects
            int size;      // Declare a variable to store array size

        public:
            
            // Constrcutor and destructor
            Array();                               // Default constructor
            Array(int newSize);                    // Constructor with a size argument
            Array(const Array& newArray);          // Copy constructor
            ~Array();                              // Destructor
            
            // Assignment operator
            Array& operator = (const Array& newArray);
            
            // Getter and setter
            const int& Size() const;                           // Return size of the array
            void SetElement(int index, const CAD::Point& p);   // Set an indexed element in the array with Point p
            const CAD::Point& GetElement(int index)const;      // Get an indexed element by reference
            CAD::Point& operator [] (int index);               // [] operator used for both readingand writing points
            const CAD::Point& operator [] (int index) const;   // [] overloaded operator avoiding change of object state, read only
        };
    }
}

#endif // End of header Array_HPP
