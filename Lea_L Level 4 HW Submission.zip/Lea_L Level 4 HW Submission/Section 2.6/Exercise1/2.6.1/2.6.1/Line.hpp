// Line.hpp
// Lea LI
// Level 4 - Exercise 2.6.1
// Header file for Line with two points - start and end (two Point objects as data members)
// Add assignment operator to Line class
// Using Friends declarations for << operator and move in the class definition
// Put Line class into namespace LeaLI::CAD

#ifndef Line_HPP
#define Line_HPP      // Prevent multiple inclusion of header file
#include "Point.hpp"  // Header file for Point class
#include <iostream>   // Include standard input and output streams library

namespace LeaLI
{
    namespace CAD
    {
        class Line

        {
            // Declare private members
        private:
            Point startPoint; //start-point type Point
            Point endPoint;   //end-point type Point

        public:
            // Constructors and destructor
            Line();                                               // Default constructor, takes no arguments
            Line(const Point& newStartP, const Point& newEndP);   // Constructor with start-point and end-point
            Line(const Line& line);                               // Copy constructor
            ~Line();                                              // Destructor

            // Selectors
            // Set as const member functions since they don't change the state of Line object
            // To prevent changing original value I will not use reference for getters here
            Point startP() const;                                 // Access the start-point
            Point endP() const;                                   // Access the end-point

            
            // Modifiers
            // Using overloaded setters and const arguments
            // Call by reference so that no copy of object will be made
            void startP(const Point& newStartP);                  // Set the start-point
            void endP(const Point& newEndP);                      // Set the end-point
            
            // Set as const member functions since they don't change the state of Line object
            std::string ToString() const;                         // Return string description of point
            double Length() const;                                // Returns the length of the line
            
            // Declare assignment operator for Line object
            Line& operator =  (const Line& c);
            
            friend std::ostream& operator << (std::ostream& os, const Line& l);// Send to ostream.
        };
    }
}

#endif // End of header Line_HPP


