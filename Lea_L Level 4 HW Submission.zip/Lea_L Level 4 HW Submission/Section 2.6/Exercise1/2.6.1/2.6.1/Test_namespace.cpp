// Test_namespace.cpp
// Lea LI
// Level 4 - Exercise 2.6.1
// Simple test file for using namespace

#include <iostream>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Array.hpp"

#include <iostream> // Include standard input and output streams library
using namespace std;

int main()
{
    //Test full namespace for Point class
    cout<<"Test full namespace for Point class "<<endl;
    LeaLI::CAD::Point p1(3,4); // Create point object
    cout << p1 << endl; // Print description

    // Use declaration for class Line
    cout << "Test using declaration for Line class " << endl;
    using namespace LeaLI::CAD;
    Line l1(p1, Point()); // Create line object with startpoint p1 and endpoint Point()
    cout << l1.ToString() << endl;
    
    cout << "Test using declaration for Container" << endl;
    // Test declaration for a complete namespace Containers
    using namespace LeaLI::Container;
    
    // Create a default Array object
    Array arr;             // Default constructor get called and allocates 10 elements
    arr.SetElement(9, p1); // Set last element using p1
    cout <<"Last element is "<< arr.GetElement(9) << endl;


    // Ceating a shorter alias for circle
    cout << "Using a shorter alias for circle " << endl;
    namespace cad = LeaLI::CAD;

    cad::Circle c1(p1, 4); // Create a circle with centerpoint is p1, radius is 4
    cout << c1 << endl;

    return 0;
}
