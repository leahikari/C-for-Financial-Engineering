// Circle.cpp
// Lea LI
// Level 5 - Exercise 3.4.1
// Implementation file for Class Circle
// Modified at: 2023/07/24  Implementation of assignment operator to Circle class
// Modified at: 2023/07/25  Implementation of Ostream << Operator
// Modified at: 2023/07/27  Apply colon syntax for Circle class constructors

#include "Circle.hpp"   // Header file for Circle class
#include "Point.hpp"    // Header file for Point class
#include <iostream>     // Include standard input and output streams library
#include <sstream>      // Standard library header providing string stream classes
#define _USE_MATH_DEFINES
#include <cmath>        // Standard library header providing a set of mathematical operations

using namespace std;
using namespace LeaLI;
using namespace CAD;


// Default constructor initializes Centre point to (0,0) and Radius to 0
Circle::Circle() : centrePoint(0,0), m_radius(0) // Colon syntax
{

}

// Constructor taking new Center Point and new Radius
Circle::Circle(const Point& newCentrePt, const double& newRadius) : centrePoint(newCentrePt), m_radius(newRadius)
{
    
}

// Copy constructor
Circle::Circle(const Circle& c) : centrePoint(c.centrePoint), m_radius(c.m_radius)
{
    
}

// Destructor
Circle::~Circle()
{
    std::cout << "Destructor is called : Bye~ my circle" << std::endl;
}

// Selectors
// Return the centre point
Point Circle::CentrePoint() const
{
    return centrePoint;

}

// Return the radius
double Circle::Radius()const
{
    return m_radius;
}

// Modifiers
// Set the centre point
void Circle::CentrePoint(const Point& newCentrePt)
{
    centrePoint = newCentrePt;
}

// Set the radius
void Circle::Radius(const double& newRadius)
{
    m_radius = newRadius;
}


// Return diameter of the circle
double Circle::Diameter() const
{
    return 2 * m_radius;                // Diameter of a circle : 2 * radius
}

// Return area of the circle
double Circle::Area() const
{
    return M_PI * std::pow(m_radius, 2); // Area of a circle: PI * (radius^2)
}

// Return circumference of the circle
double Circle::Circumference() const
{
    return M_PI * m_radius * 2;          // Circumference of a circle : 2* PI * radius
}

// Return the description of the circle
std::string Circle::ToString() const
{
    std::stringstream ss;   // Create a stringstream object ss
    ss << "Circle centrepoint is : " << centrePoint.ToString() << " and circle radius is : " << m_radius << std::endl;
    return ss.str();        // Return description of this circle

}

// Assignment operator
Circle& Circle::operator = (const Circle& cir) // Using reference to prevent unnecessary copy
{
    cout << "Assignment operator of Circle class gets called "<< endl;
    if (this == &cir) // Avoid assigning to itself
        return *this; // Return current circle object, no need to assign

    centrePoint = cir.centrePoint;
    m_radius = cir.m_radius; // Assign new circle's centre pt and radius to current circle object

    return *this;
}

// Send to ostream
ostream& operator << (ostream& os, const Circle& c)
{
    os << c.ToString() ; // Get the string of Circle description and send to the os argument
    return os; // Return os by reference
}

