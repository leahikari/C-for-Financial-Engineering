// TestProgram.cpp
// Lea LI
// Level 5 - Exercise 3.4.1
// Simple test program on colon syntax efficiency

#include <iostream>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Array.hpp"

#include <iostream> // Include standard input and output streams library
using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration

int main()
{

   Line l;

/*  Before using colon syntax for constructors in Line class, the number of point constructor, destructor and assignment calls are:
    4 times constructors (2 times default constructors, 2 times constructor taking 2 double arguments)
    4 times destructors
    2 times assignment operator

    After using colon syntax for constructors in Line class, the number of point constructor, destructor and assignment calls are:
    2 times constructors with 2 double arguments
    2 times point destructors
    0 time assignment operator
    
    We can observe that there's a significant increase in performance (the number of point constructor, destructor and assignment calls
    is less than before) after using colon syntax, because objects will be initialized upon creation.
*/
    //Circle c;// Constructor and destructor were both only called once

    return 0;
}
