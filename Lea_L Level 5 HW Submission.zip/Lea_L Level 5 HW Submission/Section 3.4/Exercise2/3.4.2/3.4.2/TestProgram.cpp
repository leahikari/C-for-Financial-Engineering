// TestProgram.cpp
// Lea LI
// Level 5 - Exercise 3.4.2
// Simple test program for class Inheritance
// Point, Line and Circle are all derived from Shape class

#include "Point.hpp"    // Header file for Point class
#include "Line.hpp"     // Header file for Line class
#include "Circle.hpp"   // Header file for Circle class
#include "Shape.hpp"    // Header file for Shape class
#include <iostream>     // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration

int main()
{
    // Test inheritance
    
    Shape s; // Create shape
    Point p(10, 20); // Create point
    Line l(Point(1,2), Point(3, 4)); // Create line
    
    cout << s.ToString() << endl; // Print shape
    cout << p.ToString() << endl; // Print point
    cout << l.ToString() << endl; // Print line
    
    // This is called overriding functions
    // In each class we have defined a ToString() member function
    // For derived objects its overridden function is called, so that it will return appropriate description for each object
    
    cout << "Shape ID: "<< s.ID() << endl; // ID of the shape.
    cout << "Point ID: "<< p.ID() << endl; // ID of the point. Does this work?
    cout << "Line ID: " << l.ID() << endl; // ID of the line. Does this work?
    
    // They both work since point and circle class inherited the public member function ID() of the Shape base class
   
    Shape* sp; // Create pointer to a shape variable.
    sp = &p; // Point in a shape variable. Possible?
    
    // It's possible for a base class pointer to point to a derived class object, but not vice versa
    // Because the derived class guarantees that it contains the same functionality as the base class

    cout << sp->ToString() << endl; // What is printed?
    // Only The shape ID is printed
    // sp is a pointer to base class with derived point object assigned
    // Through this pointer we can only call the member functions that are declared in the base class i.e. ToString() of Shape class
    // Derived member functions not accessible any more
    
    // Create and copy Point p to new point.
    Point p2;
    p2 = p;
    cout << p2 << ", " << p2.ID() << endl; // Is the ID copied if you do not call the base class assignment in point?
    // If we don't call the base class assignment, the ID will not be copied
    // Since we already created an overriden assignment operator for point, it will not call the base class assignment operator
    
    return 0;
}
