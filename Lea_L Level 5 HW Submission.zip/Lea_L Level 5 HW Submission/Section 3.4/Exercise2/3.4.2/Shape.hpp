// Shape.hpp
// Lea LI
// Level 5 - Exercise 3.4.2
// Header file for Shape class

#ifndef Shape_HPP
#define Shape_HPP     // Prevent multiple inclusion of header file
#include <iostream>   // Include standard input and output streams library
using namespace std;

namespace LeaLI
{
    namespace CAD
    {
        class Shape
        {
        private:
            // Declare private member
            int m_id;    // Declare a variable to store the ID number

        public:
            // Constrcutor and destructor
            Shape();                      // Default constructor
            Shape(int newID);             // Constructor takes an int argument
            Shape(const Shape& source);   // Copy constructor
            
            Shape& operator = (const Shape& source); // Assignment operator
            ~Shape();                                // Destructor

            // Accessing functions
            const int ID() const;          // Retrieve the id of the shape

            string ToString() const; // Returns the id as a string
        };
    }
}
#endif // Shape_HPP

