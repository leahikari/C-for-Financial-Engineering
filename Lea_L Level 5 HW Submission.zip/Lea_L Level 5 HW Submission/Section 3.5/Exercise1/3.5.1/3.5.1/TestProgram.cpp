// TestProgram.cpp
// Lea LI
// Level 5 - Exercise 3.5.1
// Point, Line and Circle are all derived from Shape class
// Simple test program for Polymorphic ToString() Function


#include "Point.hpp"    // Header file for Point class
#include "Line.hpp"     // Header file for Line class
#include "Circle.hpp"   // Header file for Circle class
#include "Shape.hpp"    // Header file for Shape class
#include <iostream>     // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration

int main()
{


    Shape s; // Create shape
    Point p(10, 20); // Create point
    Circle c(p,1.0); // Create circle
    Line l; // Create default Line

    Shape* sp; // Create pointer to a shape variable.
    sp = &p;
    cout << sp->ToString() << endl;
    // Above line of code will print description of point p instead of shape ID
    // ToString() function of Point was called
    // As we declared ToString() as virtual in base class, the function will be overriden in derived class
    sp = &c;
    cout << sp->ToString() << endl;
    sp = &l;
    cout << sp->ToString() << endl;
    // Poymorphic ToString() works well for other derived classes
    
    return 0;
}
