// TestProgram.cpp
// Lea LI
// Level 5 - Exercise 3.5.2
// Point, Line and Circle are all derived from Shape class
// Simple test program for calling Base Class Functionality


#include "Point.hpp"    // Header file for Point class
#include "Line.hpp"     // Header file for Line class
#include "Circle.hpp"   // Header file for Circle class
#include "Shape.hpp"    // Header file for Shape class
#include <iostream>     // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration

int main()
{


    Shape s; // Create shape
    Point p(10, 20); // Create point
    Circle c(p,1.0); // Create circle
    Line l; // Create default Line

    Shape* sp; // Create pointer to a shape variable.
    sp = &p;
    cout << sp->ToString() << endl;
    // Above line of code will print description of point p and the shape ID since we incorporated the shape ID in it
    // ToString() function of Point was called (overriden)
    sp = &l;
    cout << sp->ToString() << endl;
    // ToString() function of Line was called (overriden)
    sp = &c;
    cout << sp->ToString() << endl;
    // ToString() function of Circle was called (overriden)
    // Calling base class functionality works well for other derived classes
    
    return 0;
}
