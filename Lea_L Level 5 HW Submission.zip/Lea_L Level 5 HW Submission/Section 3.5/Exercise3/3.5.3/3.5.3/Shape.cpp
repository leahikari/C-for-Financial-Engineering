// Shape.cpp
// Lea LI
// Level 5 - Exercise 3.5.3
// Implementation file for Shape Class


#include "Shape.hpp"   // Header file for Shape class
#include <stdlib.h>    // Standard library header providing rand() that generates random numbers
#include <sstream>     // Standard library header providing string stream classes
using namespace std;
using namespace LeaLI;
using namespace CAD;


// Default constructor initializes m_id using a random number
// The rand() function is used in C++ to generate random numbers in the range [0, RAND_MAX)
Shape::Shape() : m_id(rand()) //Colon syntax
{
    //cout << "New Shape created using default constructor with ID: " << m_id << endl;
    
}
// Constructor with an int argument
Shape::Shape(int newID) :m_id(newID) //Colon syntax
{
    //cout << "New Shape created with ID: " << m_id << endl;
}


// Copy constructor
Shape::Shape(const Shape& source) : m_id(source.m_id) //Colon syntax
{
    //cout << "Copy constructor gets called " << endl;
}

// Destructor
Shape::~Shape()
{
    cout << "Bye~ my shape." << endl;
}

// Retrieve the id of the shape
// Using const specifier so that id is read only
const int Shape::ID() const
{
    return m_id;
}

// Rreturn the id as string
string Shape::ToString() const
{
    stringstream ss;
    ss << "Shape ID: " << m_id;

    return ss.str();
}

// Assignment operator
Shape& Shape::operator = (const Shape& source)
{
    if (this == &source)  // Avoid assigning to itself
        return *this;

    m_id = source.m_id;
    
    return *this; //return current assigned object
}
