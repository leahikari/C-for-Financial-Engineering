// TestProgram.cpp
// Lea LI
// Level 5 - Exercise 3.5.3
// Point, Line and Circle are all derived from Shape class
// Simple test program for virtual destructors


#include "Point.hpp"    // Header file for Point class
#include "Line.hpp"     // Header file for Line class
#include "Circle.hpp"   // Header file for Circle class
#include "Shape.hpp"    // Header file for Shape class
#include <iostream>     // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration

int main()
{
    Shape* shapes[3];  // Create pointers of base class and assign them to different derived objects
    shapes[0] = new Shape;
    shapes[1] = new Point;
    shapes[2] = new Line;
    for (int i = 0; i != 3; i++) delete shapes[i];  // Free memory, destructors get called
    
    // By executing above piece of code we can observe that only destrucor of Shape base class gets called
    // The appropriate destructor of each class will not be called unless we declare it as virtual in base class
    // ......
    // After declare virtual destructor
    // Both base and derived destructor of each class is now called properly
    // Derived class destructor gets called first after which the destructor for the base part is called

    return 0;
}
