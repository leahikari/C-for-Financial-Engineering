// Circle.hpp
// Lea LI
// Level 5 - Exercise 3.5.4
// Header file for Circle class : a circle is defined by a center point and a radius
// Add assignment operator to Circle class
// Add Ostream << Operator
// Put circle class into namespace LeaLI::CAD
// Apply colon syntax for Circle class constructors
// Let Circle class inherit from Shape
// Incorporate the ID from Shape base class in Circle ToString()
// Declare overriden function Draw() in Circle class

#ifndef Circle_HPP
#define Circle_HPP     // Prevent multiple inclusion of header file
#include "Point.hpp"   // Header file for Point class
#include "Shape.hpp"   // Header file for Shape class
#include <iostream>    // Include standard input and output streams library

namespace LeaLI
{
    namespace CAD
    {
        class Circle: public Shape // Derived from Shape class

        {
            // Declare private members
        private:
            Point centrePoint;  // Centre Point
            double m_radius;    // Radius of the circle

        public:
            // Constructors and destructor
            Circle();                                                     // Default constructor, takes no arguments
            Circle(const Point& newCentrePt, const double& newRadius);    // Constructor with centre point and radius
            Circle(const Circle& c);                                      // Copy constructor
            ~Circle();                                                    // Destructor


            // Selectors
            // Set as const member functions since they don't change the state of Circle object
            Point CentrePoint() const;                                    // Access the centre point
            double Radius() const;                                        // Access the radius


            // Modifiers
            // Using overloaded setters and const arguments
            void CentrePoint(const Point& newCentrePt) ;                   // Set the centre point
            void Radius(const double& newRadius) ;                         // Set the radius

            // Set as const member functions since they don't change the state of Circle object
            double Diameter() const;                                       // Return diameter of the circle
            double Area() const;                                           // Return area of the circle
            double Circumference() const;                                  // Return circumference of the circle
            std::string ToString() const;                                  // Return description of the circle
            
            void Draw();                                // Simulates drawing by printing some text

            // Assignment operator for Circle object
            Circle& operator = (const Circle& cir);
            
        };

    }
}

std::ostream& operator << (std::ostream& os, const LeaLI::CAD::Circle& c); // Send to ostream

#endif // End of header Circle_HPP


