// Point.hpp
// Lea LI
// Level 5 - Exercise 3.5.4
// Header file for Points in two dimensions, x and y
// Add a few operators to the Point class
// Add Ostream << Operator
// Put point class into namespace LeaLI::CAD
// Apply colon syntax for Point class constructors
// Let Point class inherit from Shape
// Incorporate the ID from Shape base class in Point ToString()
// Declare overriden function Draw() in Point class


#ifndef Point_HPP
#define Point_HPP     // Prevent multiple inclusion of header file
#include "Shape.hpp"  // Header file for Shape class
#include <iostream>   // Include standard input and output streams library
using namespace std;

namespace LeaLI
{
    namespace CAD
    {
        class Point: public Shape // Derived from Shape class

        {
            
        private:
            // Private members
            double m_x; // X coordinate data member
            double m_y; // Y coordinate data member

        public:
            // Constrcutor and destructor
            Point();                           // Default constructor, takes no arguments
            Point(double newX, double newY);   // Constructor with x coordinate and y coordinate
            Point(const Point& p);             // Copy Constructor
            explicit Point(double xyval);             //  explicit constructor with one double value argument
            
            ~Point();                          // Destructor

            // Selectors
            // Set as const member functions since they don't change the current object
            double X() const;               // Get x-coordinate value
            double Y() const;               // Get y-coordinate value

            // Modifiers
            // Using function overloading to rename modifier member functions
            // Same name as selector member functions but return type is different
            void X(double new_X);           // Set x-coordinate value
            void Y(double new_Y);           // Set y-coordinate value
            
            // Set as const member functions since they don't change the current object
            std::string ToString() const;                // Return string description of point
            double Distance() const;                     // Calculate the distance to the origin (0, 0),
            double Distance(const Point& p) const;       // calculate the distance between two points
            // The input point of above function will be called by const reference
            
            void Draw();                                // Simulates drawing by printing some text
            
            // Member operator overloading
            // The object called by const functions cannot be modified
            Point operator - () const;               // Negate the coordinates
            Point operator * (double factor) const;  // Scale the coordinates
            Point operator + (const Point& p) const; // Add coordinates
            bool operator == (const Point& p) const; // Equally compare operator
            Point& operator = (const Point& source); // Assignment operator for Point object
            Point& operator *= (double factor); // Scale the coordinates & assign
        };

    }
}

// Ostream << operator
ostream& operator << (ostream& os, const LeaLI::CAD::Point& pt);

#endif // End of header Point_HPP


