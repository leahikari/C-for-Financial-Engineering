// TestProgram.cpp
// Lea LI
// Level 5 - Exercise 3.5.4
// Point, Line and Circle are all derived from Shape class
// Simple test program on pure virtual member function Draw()


#include "Point.hpp"    // Header file for Point class
#include "Line.hpp"     // Header file for Line class
#include "Circle.hpp"   // Header file for Circle class
#include "Shape.hpp"    // Header file for Shape class
#include <iostream>     // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration

int main()
{
    //Shape s; // Doesn't work since shape class including at least one PVMF is regarded as an abstract base class
    // It is not possible to create an instance of an ABC.

    Shape* shapes[5]; // Create some pointers to Shape base class and assign them to different derived objects.
    shapes[0] = new Point;
    shapes[1] = new Line;
    shapes[2] = new Point(1.0, 2.5);
    shapes[3] = new Circle;
    shapes[4] = new Line(Point(1.0, 2.5), Point(3,4));
    for (int i = 0; i != 5; i++) shapes[i]->Draw();  // Call the polymorphic Draw() functions of each derived classes
    for (int i = 0; i != 5; i++) delete shapes[i];   // Delete all the objects

    return 0;
}
