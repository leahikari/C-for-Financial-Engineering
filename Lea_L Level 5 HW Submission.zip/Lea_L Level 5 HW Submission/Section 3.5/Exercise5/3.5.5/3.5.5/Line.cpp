// Line.cpp
// Lea LI
// Level 5 - Exercise 3.5.5
// Implementation file for Class Line
// Modified at: 2023/07/24   Implementation of assignment operator to Line class
// Modified at: 2023/07/25   Using friends declarations for << operator to set as global function
// Modified at: 2023/07/27   Apply colon syntax for Line class constructors
// Modified at: 2023/07/28   Modify Line class as a derived class of Shape base class
// Modified at: 2023/07/28   Incorporate the ID from Shape base class in Line ToString()
// Modified at: 2023/07/28   Override Draw() function in Line class



#include "Line.hpp"   // Header file for line class
#include "Point.hpp"  // Header file for point class
#include "Shape.hpp"  // Header file for Shape class
#include <iostream>   // Include standard input and output streams library
#include <sstream>    // Standard library header providing string stream classes
#include <cmath>      // Standard library header providing Contains a set of mathematical operations
using namespace std;
using namespace LeaLI;
using namespace CAD;

// Default constructor initializes both points to (0,0)
Line::Line() : Shape(), startPoint(0,0), endPoint(0,0) // Colon syntax
{
    //cout << "Default constructor is called" << endl;
}

// Constructor assigning new startPoint and new endPoint
Line::Line(const Point& newStartPt, const Point& newEndPt) : Shape(), startPoint(newStartPt),endPoint(newEndPt) // Colon syntax
{
    //cout << "Constructor taking two Points as arguments is called" << endl;
}

// Copy constructor, we need to call a constructor of the base class that copies the base data members in the current Line object
Line::Line(const Line& l) : Shape(l), startPoint(l.startPoint),endPoint(l.endPoint) // Colon syntax
{
    //cout << "Copy constructor is called" << endl;
    
}

// Destructor
Line::~Line()
{
    //cout << "Bye~my line " << endl;
}


// Selectors
// Return the start-point
Point Line::startP() const
{
    return startPoint;
}

// Return the end-point
Point Line::endP() const
{
    return endPoint;
}


// Modifiers
// Set the start-point
void Line::startP(const Point& newStartPt)
{
    startPoint = newStartPt;
}

// Set the end-point
void Line::endP(const Point& newEndPt)
{
    endPoint = newEndPt;
}

// Return the description of the line in using stringstream
string Line::ToString() const
{
    std::string s = Shape::ToString();   //Incorporate the ID from Shape in Line ToString()
    stringstream ss;                     // Create a stringstream object ss
    ss << "Line starts at " << startPoint.ToString() << " and ends at " << endPoint.ToString() << " (Line " <<s <<")";
    return ss.str();      // Return line description

}

// Return the length of a line
double Line::Length() const
{
    return startPoint.Distance(endPoint); // Delegation of Distance function declared in header
}

// Implement Draw() in derived Line class
void Line::Draw()    //Simulates drawing by printing some text
{
    cout << "Draw a line " << endl;
    
}

// Assignment operator
Line& Line::operator =  (const Line& c)  // Using reference to prevent unnecessary copy
{
    //cout << "Assignment operator of Line class gets called "<< endl;
    if (this == &c) return *this; // Avoid assigning to itself
    Shape::operator= (c);    // Call the assignment operator of the Shape base class
    startPoint = c.startPoint;
    endPoint = c.endPoint; // Assign new line's start/end points to current Line object

    return *this;
}

// Send to ostream
ostream& operator << (ostream& os, const Line& l)
{
    os << l.ToString();
    return os; // Return os by reference
}

