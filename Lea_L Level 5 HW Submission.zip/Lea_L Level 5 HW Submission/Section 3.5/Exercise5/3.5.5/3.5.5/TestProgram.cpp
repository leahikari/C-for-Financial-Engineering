// TestProgram.cpp
// Lea LI
// Level 5 - Exercise 3.5.5
// Point, Line and Circle are all derived from Shape class
// Simple test program on Template Method Pattern


#include "Point.hpp"    // Header file for Point class
#include "Line.hpp"     // Header file for Line class
#include "Circle.hpp"   // Header file for Circle class
#include "Shape.hpp"    // Header file for Shape class
#include <iostream>     // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration

int main()
{

    Shape* shapes[5]; // Create some pointers to Shape base class and assign them to different derived objects.
    shapes[0] = new Point;
    shapes[1] = new Line;
    shapes[2] = new Point(1.0, 2.5);
    shapes[3] = new Circle;
    shapes[4] = new Line(Point(1.0, 2.5), Point(3,4));
    for (int i = 0; i != 5; i++) shapes[i]->Print();  // Call Print() function implemented in Shape base class
    for (int i = 0; i != 5; i++) delete shapes[i];    // Delete all the objects
    
    /* We can observe that above piece of code prints description of each derived object even we don't have the Print() function in derived class.
     Since we incorporated ToString() in the implementation of Print() in base class, it does all the functionality common to all derived classes and
     the different part is delegated to a polymorphic function (ToString()) for each derived class (Template Method Pattern). */
    
    return 0;
}
