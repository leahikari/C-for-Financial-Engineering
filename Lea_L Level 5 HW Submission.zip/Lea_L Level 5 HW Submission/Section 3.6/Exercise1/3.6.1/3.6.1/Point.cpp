// Point.cpp
// Lea LI
// Level 5 - Exercise 3.6.1
// Implementation file for Class Point with operator overloading
// Modified at: 2023/07/24  Implementation of several overloaded operators
// Modified at: 2023/07/25  Implementation of Ostream << Operator
// Modified at: 2023/07/25  Implementation of constructors as implicit & conversion operator
// Modified at: 2023/07/27  Apply colon syntax for Point class constructors
// Modified at: 2023/07/28  Modify Point class as a derived class of Shape base class
// Modified at: 2023/07/28  Incorporate the ID from Shape base class in Point ToString()
// Modified at: 2023/07/28   Override Draw() function in Point class


#include "Point.hpp"    // Header file for Point class
#include "Shape.hpp"    // Header file for Shape class
#include <sstream>      // Standard library header providing string stream classes
#include <iostream>     // Standard library header for input and output streams
#include <cmath>        // Contains a set of mathematical operations as part of implementation of distance function
using namespace std;
using namespace LeaLI;
using namespace CAD;

// Default constructor initialization
Point::Point() : Shape(), m_x(0), m_y(0) // Colon syntax
{
    //cout<<"Default constructor is called "<< endl;
}

// Constructor to create point from user input of x and y coordinates
Point::Point(double newX, double newY) : Shape(), m_x(newX), m_y(newY) // Colon syntax
{
    //cout<<"Constructor taking 2 double arguments is called "<< endl;
}

// Copy constructor, we need to call a constructor of the base class that copies the base data members in the current object
Point::Point(const Point& p) : Shape(p), m_x(p.m_x), m_y(p.m_y) // Colon syntax
{
    //cout<<"Copy constructor is called "<< endl;
    
}

// Point::Point(double val) : m_x(val), m_y(val) {}

// Explicit constructor implementation
// Takes a single double argument that sets both the x and y coordinate value
Point::Point(double xyval) : Shape(), m_x(xyval), m_y(xyval) {}

// Destructor
Point::~Point()
{
    //cout<<"Bye~my point "<< endl;

}



// Selectors
// Return the x value
double Point::X() const
{
    return m_x;
}

// Return the y value
double Point::Y() const
{
    return m_y;
}

// Modifiers
// Set the x value
void Point::X(double newX)
{
    m_x = newX;
}

// Set the y value
void Point::Y(double newY)
{
    m_y = newY;
}

// Returns string description of a point in format Point(x,y) by using stringstream
std::string Point::ToString() const
{
    std::string s = Shape::ToString();            //Incorporate the ID from Shape in Point ToString()
    std::stringstream ss;
    ss << "Point(" << m_x << ", " << m_y << ")" << " (Point " << s <<")";
    // Append the shape description string to the point description
    return ss.str();                             // Gets the string object’s content
}

// Calculate distance to the origin (0, 0)
double Point::Distance() const
{
    return std::sqrt(m_x*m_x + m_y*m_y); // The Pythagoras algorithm
}

// Calculate distance to point p
double Point::Distance(const Point& p) const  // Use call by reference when passing objects to distacne function
{
    // Orginial object p will be passed to the function, set as const argument so that input object won't be changed
    return sqrt(pow((p.m_x-m_x), 2) + pow((p.m_y-m_y), 2));
}

// Implement Draw() in derived Point class
void Point::Draw()    //Simulates drawing by printing some text
{
    cout << "Draw a point" << endl;
    
}

// Negate the coordinates
Point Point::operator - () const
{
    return Point(-m_x, -m_y); // The additive inverse of the current point coordinates
}

// Scale the coordinates
Point Point::operator * (double factor) const
{
    return Point(factor*m_x, factor*m_y);  // Scale the x and y coordinates
}

// Add coordinates
Point Point::operator + (const Point& p) const
{
    return Point(m_x+p.m_x, m_y+p.m_y);    // Anonymous object
}

// Equally compare operator
bool Point::operator == (const Point& p) const
{
    return (m_x == p.m_x && m_y == p.m_y); // Check if both coordinates are equal
}

// Assignment operator
Point& Point::operator = (const Point& source) // Using reference to prevent unnecessary copy
{
    if (this == &source) // Avoid assigning to itself
        return *this;    // Return current point, no need to assign
    
    Shape::operator =(source); // Call the assignment operator of the Shape base class

    m_x = source.m_x;
    m_y = source.m_y;   // Assign new point's coordinates to current point object

    return *this;     
}

// Scale the coordinates & assign
Point& Point::operator*= (double factor)
{
    m_x = m_x * factor;
    m_y = m_y * factor;
    return *this;    // Return scaled point
}

// Send to ostream
ostream& operator << (ostream& os, const Point& p)
{
    os << p.ToString() ; // Get the string of Point description and send to the os argument
    return os; // Return os by reference
}
