// TestProgram.cpp
// Lea LI
// Level 5 - Exercise 3.6.1
// Point, Line and Circle are all derived from Shape class
// Simple test program on exception handling when array size is out of bounds


#include "Point.hpp"    // Header file for Point class
#include "Array.hpp"    // Header file for Shape class
#include <iostream>     // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration
using namespace LeaLI::Container;

int main()
{
    Array array1(3); // Initialize an Array object of size 4
    
    // Using [] operator to write element
    for (int i = 0; i < array1.Size() ; i++)
    {
        array1[i] = Point(i+1,i+2);
    
    }
    // Try access array1[100]
    try
    {
        array1.GetElement(100);
    }
    catch(int err)
    {
        if (err == -1)
            cout << "Index error when getting element" << endl;
    }
    catch(...)
    {
        cout << "An unhandled exception has occurred" << endl;
    }
    
    try
    {
        array1.SetElement(2,Point(10, 2));      // Should be fine
        //array1.SetElement(99,Point(1, 2));      // Throw an error
        array1.SetElement(-10,Point(0, 0));     // Throw an error
    }
    catch(int err)
    {
        if (err == -1)
            cout << "Index error when setting element" << endl;
    }
    catch(...)
    {
        cout << "An unhandled exception has occurred" << endl;
    }
    
    try
    {
        array1[48] = Point(0, 0);    // Throw an error
    }
    catch(int err)
    {
        if (err == -1)
            cout << "Index error when using [] access element" << endl;
    }
    catch(...)
    {
        cout << "An unhandled exception has occurred" << endl;
    }

    return 0;
}



