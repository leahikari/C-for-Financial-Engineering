// TestProgram.cpp
// Lea LI
// Level 5 - Exercise 3.6.2
// Point, Line and Circle are all derived from Shape class
// Simple test program on exception hierarchy

#include "Point.hpp"         // Header file for Point class
#include "Array.hpp"         // Header file for Shape class
#include "ArrayException.hpp"// Header file for ArrayException class
#include <iostream>          // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration
using namespace LeaLI::Container;

int main()
{
    Array array1(3); // Initialize an Array object of size 3
    
    // Using [] operator to write element
    for (int i = 0; i < array1.Size() ; i++)
    {
        array1[i] = Point(i+1,i+2);
    
    }
    // Try access array1[100]
    try
    {
        array1.GetElement(100); // GetElement() will throw an error
    }
    catch(ArrayException& exc)
    {
        cout << exc.GetMessage() << endl;
    }
    catch(...)
    {
        cout << "An unhandled exception has occurred" << endl;
    }
    
    try
    {
        array1.SetElement(-99,Point(1, 2)); // Try to assign Point(1,2) to -99th element in array1
        
    }
    catch(ArrayException& exc)
    {
        cout << exc.GetMessage() << endl;  // SetElement() will throw an error and Getmessage() will print erroneous index
    }
    catch(...)
    {
        cout << "An unhandled exception has occurred" << endl;
    }
    
    try
    {
        array1[48] = Point(1, 2); // Try to assign Point(1,2) to 48th element in array1
        
    }
    catch(ArrayException& exc)
    {
        cout << exc.GetMessage() << endl;  // [] operator will throw an error and Getmessage() will print erroneous index
    }
    catch(...)
    {
        cout << "An unhandled exception has occurred" << endl;
    }

    return 0;
}



