// TestProgram.cpp
// Lea LI
// Level 6 - Exercise 4.2a.1
// Simple test program for templated Array class
// Test on Array<Point> points(size)

#include "Point.hpp"         // Header file for Point class
#include "Array.hpp"         // Header file for templated Array class
#include "ArrayException.hpp"// Header file for ArrayException class
#include <iostream>          // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration
using namespace LeaLI::Container;

int main()
{
    cout << "Test Array<Point>" << endl;
    Array<Point> points(3);  // Instantiate an Array type Point of size 3 using Array<Point>
    // Test Size() function
    cout << "Size of Array<Point> points: " << points.Size() << endl;
    // Using [] operator to write element
    for (int i = 0; i < points.Size() ; i++)
    {
        points[i] = Point(i+1,i+2);
    
    }
    // Test GetElement()
    cout << "The 2nd element of points: " << points.GetElement(1) << endl;
    // Test SetElement()
    points.SetElement(1, Point(0,0));
    cout << "The 2nd element of points: " << points.GetElement(1) << endl;
    
    // Test copy constructor
    Array<Point> points2(points);
    for (int i = 0; i < points2.Size() ; i++)
    {
        cout << points2[i]<< endl;
    
    }
    // Test assigment operator, should output the same result
    Array<Point> points3 = points2;
    for (int i = 0; i < points3.Size() ; i++)
    {
        cout << points3[i]<< endl;
    
    }
    // Test exception handling when array out of bounds
    try
    {
        points.GetElement(100); // GetElement() will throw an error
    }
    catch(ArrayException& exc)
    {
        cout << exc.GetMessage() << endl;
    }
    catch(...)
    {
        cout << "An unhandled exception has occurred" << endl;
    }
    
    return 0;
}


