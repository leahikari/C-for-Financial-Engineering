// Array.cpp
// Lea LI
// Level 6 - Exercise 4.2b.1
// Implementation file for templated Array Class
// Every function(incl. constructor, destructor and operators) must be declared as a template of type T and will become member of Array<T>
// Add static variables and functions for Array

#ifndef Array_CPP
#define Array_CPP

#include "Array.hpp"  // Header file for Array class
#include "OutOfBoundsException.hpp"

using namespace std;
using namespace LeaLI;
using namespace Container;

// Default constructor allocates 10 elements in an array of Type T

template <typename T>
int Array<T>::defaultSize = 10; // Set default size to 10

template <typename T>
Array<T>::Array(): m_data(new T[defaultSize]), size(defaultSize) // Colon syntax
{

}

// Constructor with a size argument
// We will get an array of <newSize> number of Type T
template <typename T>
Array<T>::Array(int newSize)
{
    m_data = new T[newSize];      // Create a　dynamic array
    size = newSize;               // Assign new_size to private member size
}

// Copy constructor
template <typename T>
Array<T>::Array(const Array<T>& newArray)
{
    m_data = new T[newArray.size]; // Create a dynamic array with same size as newArray

    // Using for loop to copy each element separately
    for (int i = 0;i < newArray.size; i++)
    {
        m_data[i] = newArray.m_data[i]; // Assign element by element
    }
    size = newArray.size; // Assign the size of newArray to current array size
}

// Destructor
template <typename T>
Array<T>::~Array()
{
    
    delete[] m_data; // Delete the internal C array

}

// Assignment operator
// The assignment operator is called when the object that is destined to be the copy already exists
// We have to clear old data before copying the data members
template <typename T>
Array<T>& Array<T>::operator = (const Array<T>& newArray) // Array<T> becomes a type of instance to assign
{
    if (this == &newArray) // Avoid assign to itself
    {
        return *this; // Return current array object
    }

    delete[] m_data;// Delete the old C array and allocate new memory before copying elements
    
    // Create a new dynamic array with the same size of newArray
    m_data = new T[newArray.size];
    // Using for loop to assign each element separately
    for (int i = 0;i < newArray.size; i++)
    {
        m_data[i] = newArray.m_data[i];
    }

    return *this; // Return assigned object
}


// Returns the size of the array
template <typename T>
const int& Array<T>::Size() const
{
    return size;
}

// Returns the default array size
template <typename T>
const int Array<T>::DefaultSize()
{
    return defaultSize;
}

// Sets the default array size
template <typename T>
void Array<T>::DefaultSize( int newSize)
{
    defaultSize = newSize;
}

// Set index-th element with Point p
template <typename T>
void Array<T>::SetElement(int index, const T& p)
{
    if (index >= 0 && index < size) // Check if ndex is in the bound of m_data
    {
        m_data[index] = p; // Assign p to element at index <index>, we have already defined assignment operator for Point clas
    }
    else // Throw OutOfBoundsException object if out of array bounds
    {
        throw  OutOfBoundsException(index);
    }
}

// Get an indexed element by reference
template <typename T>
const T& Array<T>::GetElement(int index) const
{
    if (index >= 0 && index < size) // Check if index is in the bound of m_data
    {
        return m_data[index];  // Return the element by reference at index <index>
    }
    else // Throw OutOfBoundsException object if out of array bounds
    {
        throw  OutOfBoundsException(index);
    }
}

// [] operator used for both readingand writing points
template <typename T>
T& Array<T>::operator [] (int index)
{
    if (index >= 0 && index < size) // Check if ndex is in the bound of m_data
    {
        return m_data[index]; // Return the element by reference at index <index>
    }
    else // Throw OutOfBoundsException object if out of array bounds
    {
        throw  OutOfBoundsException(index);
    }
}

// [] overloaded operator avoiding change of object state, read only
template <typename T>
const T& Array<T>::operator [] (int index) const
{
    if (index >= 0 && index < size) // Check if ndex is in the bound of m_data
    {
        return m_data[index]; // Return the element by reference at index <index>
    }
    else // Throw OutOfBoundsException object if out of array bounds
    {
        throw  OutOfBoundsException(index);
    }
}

#endif  // Array_CPP
