// TestProgram.cpp
// Lea LI
// Level 6 - Exercise 4.2b.1
// Simple test program on Static Variables and Functions

#include "Point.hpp"         // Header file for Point class
#include "Array.hpp"         // Header file for templated Array class
#include "ArrayException.hpp"// Header file for ArrayException class
#include <iostream>          // Include standard input and output streams library

using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration
using namespace LeaLI::Container;

int main()
{
    // Create respectively two arrays of int and an array of double
    Array<int> intArray1;
    Array<int> intArray2;
    Array<double> doubleArray;

    // Get their default array size
    cout << intArray1.DefaultSize() << endl;   //10
    cout << intArray2.DefaultSize() << endl;   //10
    cout << doubleArray.DefaultSize() << endl; //10

    // Set intArray1 default size to 15
    intArray1.DefaultSize(15);
    // Function void Array<T>::DefaultSize(int newSize) gets called
    // Through above code Array<int> default size changed to 15

    // Get again their default array size
    cout << intArray1.DefaultSize() << endl;   //15
    cout << intArray2.DefaultSize() << endl;   //15
    cout << doubleArray.DefaultSize() << endl; //10
    // intArray1 and intArray2 are both instance of class Array<int>
    // When we change the static data member defaultSize to 15
    // All instances of Array<int> defaultSize will change to 15
    // Array<double> class is different from Array<int>, so the default size keep unchanged
    // In templated class, static member data is created for each type and shared among instance of each type
    
    return 0;

}

