// Array.hpp
// Lea LI
// Level 6 - Exercise 4.2b.2
// Header file for templated Array class containing Ts
// Add static variables and functions for Array

#ifndef Array_HPP
#define Array_HPP    // Prevent multiple inclusion of header file
#include "Point.hpp" // Include header file of point class

namespace LeaLI
{
    namespace Container
    {
        template <typename T>
        class Array
        {
            
        private:
            // Declare private members
            T* m_data;     // A Dynamic C array of T* objects
            int size;      // Declare a variable to store array size
            static int defaultSize; // Static data member for array default size

        public:
            // Constrcutors and destructor
            Array();                               // Default constructor
            Array(int newSize);                    // Constructor with a size argument
            Array(const Array<T>& newArray);       // Copy constructor
            ~Array();                              // Destructor
            
            // Assignment operator
            Array<T>& operator = (const Array<T>& newArray);
            
            // Getter and setter
            const int& Size() const;                           // Return size of the array
            
            // Static functions to get and set default size
            const static int DefaultSize()  ;         // Returns the default array size
            static void DefaultSize(int newSize) ;     // Set the default array size
            
            void SetElement(int index, const T& p);   // Set an indexed element in the array with Point p
            const T& GetElement(int index)const;      // Get an indexed element by reference
            T& operator [] (int index);               // [] operator used for both readingand writing points
            const T& operator [] (int index) const;   // [] overloaded operator avoiding change of object state, read only
        };
    }
}

#ifndef Array_CPP // Must be the same name as in source file #define
#include "Array.cpp"
#endif// End of Array_CPP
// After inserted above codes we can JUST keep including the header file for template classes instead of the source file(Array.cpp)
// By doing so we can solve the template compilation problem i.e the compiler could figure out template type

#endif // End of header Array_HPP
