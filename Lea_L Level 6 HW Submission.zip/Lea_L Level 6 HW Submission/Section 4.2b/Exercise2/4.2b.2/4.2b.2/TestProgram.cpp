// TestProgram.cpp
// Lea LI
// Level 6 - Exercise 4.2b.2
// Simple test program on templated Numeric Array (generic inheritance from Array)

#include "Point.hpp"         // Header file for Point class
#include "Array.hpp"         // Header file for templated Array class
#include "NumericArray.hpp"  // Header file for templated NumericArray class
#include "ArrayException.hpp"// Header file for ArrayException class
#include <iostream>          // Include standard input and output streams library


using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration
using namespace LeaLI::Container;

int main()
{
    cout << "Test NumericArray<int> " << endl;
    
    // Test default constructor
    cout << "Test default constructor  "  << endl;
    NumericArray<int> arr0; // Declare an instance of NumbericArray<int> called arr0
    cout << "Default object arr0 of NumericArray<int> has size " << arr0.Size() << endl;
    // Inheritance of member function Size(), default constructor and member data from Array class
    
    NumericArray<int> arr1(4);   // Initialize an NumericArray<int> arr1 of size 4
    // Constrcutor taking an int size argument gets called
    cout << "Pring each element of arr0  "  << endl;
    for (int i=0; i < arr1.Size(); i++)
    {
        arr1[i] = (i+1) * (i+2); // Using [] operator to set each element
        cout << arr1[i] << endl; // Using [] operator to read and print
    }
    
    // Test copy constructor
    cout << "Test copy constructor " << endl;
    NumericArray<int> arr2(arr1);           // Copy arr1 to arr2
    // Check array size and test inheritance of GetElement()
    cout << "arr2 of NumericArray<int> has size " << arr2.Size() <<" using copy construcotor."<< endl;
    for (int i=0; i < arr2.Size(); i++)
    {
        cout << arr2.GetElement(i) << endl; // Print each element using GetElement()
    }
    // Test default size
    cout << "arr2's default size is: " << arr2.DefaultSize()<< endl;
    cout << "arr3 = arr1 + arr2 " << endl << "arr4 = arr2 * 2 "<< endl;

    NumericArray<int> arr3 = arr1 + arr2;  // Test operator+ and assignment operator =
    NumericArray<int> arr4 = arr2 * 2;     // Test operator*
    // We print each element of four NumericArray<int> by index
    cout << "Print each element of arr1, arr2, arr3 and arr4's by index order:  "<< endl;
    for (int i=0; i < arr3.Size(); i++)
    {
        cout << "At index "<< i << endl;
        cout <<arr1[i] <<"|" << arr2[i] <<"|"<< arr3[i]<< "|" << arr4[i] << endl;
    }
    
    // Test fot product of two NumericArray<int> instances
    cout << "Dot product of arr1 and arr2: " << arr1.DotProduct(arr2) << endl;
    
    // Test operator+ when expection occurs in size inequality
    // Initialize two NumericArray<int> instances arr5 and arr6 of size 6
    NumericArray<int> arr6(6);
    NumericArray<int> arr7(6);
    try
    {
        arr7 = arr1 + arr6; // Operate addition of arr1 and arr6 which have unequal array size and assign to arr7
    }
    catch (ArrayException& exc)
    {
        cout << exc.GetMessage() << endl; // Print eerror message
    }
    
    // Test dot product when expection occurs in size inequality
    int sum; // Initialize an int to store result of dot product
    try
    {
        sum = arr1.DotProduct(arr6); // Operate dot product of arr1 and arr6 which have unequal array size and assign to sum
    }
    catch (ArrayException& exc)
    {
        cout << exc.GetMessage() << endl; // Print error message
    }
    
    cout << "------------------" << endl;
    cout << "Test creating a numeric array with Point objects" << endl;
    // Create a new NumericArray<Point> object point_arr1 of size 3
    NumericArray<Point> point_arr1(3);
    for (int i=0; i < point_arr1.Size(); i++)
    {
        point_arr1[i] = Point(i,i);
        cout << point_arr1[i] <<endl; // Using [] to print each element(<< defined in Point class)
    }
    
    // Test operator* on NumericArray<Point>
    cout << "Test NumericArray<Point>  * operator: " << endl;
    NumericArray<Point> point_arr2 = point_arr1 * 2; // Scale element of point_arr1 by 2
    for (int i = 0;i < point_arr2.Size(); i++)
    {
        cout << point_arr2[i] <<endl; // Using [] to print each element(<< defined in Point class)
    }
    
    // Test operator+ and assignment operator =
    cout << "Test NumericArray<Point> operator+ and assignment operator: " << endl;
    NumericArray<Point> point_arr3 = point_arr1 + point_arr2;
    cout << "Print each element of point_arr1, point_arr2 and point_arr3 by index order:  "<< endl;
    for (int i=0; i < point_arr3.Size(); i++)
    {
        cout << "At index "<< i << endl;
        cout <<point_arr1[i] << "|"<< point_arr2[i] << "|"<< point_arr3[i] << endl;
    }
    // Test operator+ when expection occurs in size inequality
    // Initialize two NumericArray<Point> instances point_arr4 and point_arr5 of size 2
    NumericArray<Point> point_arr4(2);
    NumericArray<Point> point_arr5(2);
    try
    {
        point_arr5 = point_arr1 + point_arr4; // Operate addition of point_arr1 and point_arr4 which have unequal array size and assign to point_arr5
    }
    catch (ArrayException& exc)    // catch size different exception
    {
        cout << exc.GetMessage() << endl; // error message
    }
    
    /* Try to calculate the dot product of 2 NumericArray<Point> instances
    int sum2;
    try
    {
        sum2 = apoint_arr1.DotProduct(point_arr3);
    }
    catch (ArrayException& exc)
    {
        cout << exc.GetMessage() << endl;
    }
    */
    
    // DotProduct() is not working for the point since we don't have operator* for point
    // i.e. Point::operator * (const Point& p) const doesn't exist
    return 0;
}

