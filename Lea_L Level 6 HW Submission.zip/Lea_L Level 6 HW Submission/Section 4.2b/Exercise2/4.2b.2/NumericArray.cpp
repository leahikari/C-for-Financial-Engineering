// NumericArray.cpp
// Lea LI
// Level 6 - Exercise 4.2b.2
// Source file for templated NumericArray class derived from Array

#ifndef NumericArray_CPP
#define NumericArray_CPP

#include "NumericArray.hpp"          // Header file for templated NumericArray class
#include "UnequalSizeException.hpp"  // Include header for exception handling

using namespace std;
using namespace LeaLI;
using namespace Container;

// Default constructor
template <typename T>
NumericArray<T>::NumericArray(): Array<T>() // No private member data of NumericArray needs to be initialised
{

}

// Constructor with an int size argument
template <typename T>
NumericArray<T>::NumericArray(int size_array) : Array<T>(size_array)
{
    
}

// Copy constructor
template <typename T>
NumericArray<T>::NumericArray(const NumericArray<T>& source): Array<T>(source)
{

}

// Destructor
template <typename T>
NumericArray<T>::~NumericArray()
{
    //cout << "Bye~my NumericArray." << endl;
}

// Assignment operator
template <typename T>
NumericArray<T>& NumericArray<T>::operator = (const NumericArray<T>& newArray)// assignment operator
{
    if (this == &newArray)         // Avoid assigning to itself
    {
        return *this;
    }
    else
    {
        Array<T>::operator = (newArray); // Call base class assignment operator
        return *this;                    // Return assigned object
    }
}

// Operator * scaling elements by a double factor
template <typename T>
NumericArray<T> NumericArray<T>::operator* (double factor) const
{
    NumericArray<T> temp(*this);  // Create an instance temp to store new scaled NumericArray<T>
    
    for (int i=0; i < (this->Size()); i++)
    {
        temp[i] = (*this)[i] * factor;
    }
    return temp; // Return the sclaed new NumericArray<T>
}

// Operator + adding elements
// Add exception handlig when size of two arrays are different
template <typename T>
NumericArray<T> NumericArray<T>::operator + (const NumericArray<T>& num_array) const
{
    if ((*this).Size() != num_array.Size())    // Check if two arrays have the same size
    {
        throw UnequalSizeException((*this).Size(), num_array.Size());  // Throw an UnequalSizeException in case different size
    }
    else
    {
        NumericArray<T> temp(*this); // Create an instance temp to store new NumericArray<T>

        for (int i = 0;i < temp.Size();i++)
        {
            temp[i] = temp[i] + num_array[i];  // Using for loop to iterate and add each element of two numeric arrays
        }
        return temp;
    }
}

// Calculate the dot product of two arrays
template <typename T>
T NumericArray<T>::DotProduct(const NumericArray<T>& num_array) const
{
    if ((*this).Size() != num_array.Size())   // Check if two arrays have the same size before
    {
        throw UnequalSizeException((*this).Size(), num_array.Size());  // Throw an UnequalSizeException in case different size
    }
    else
    {
        T dotProduct;  // Declare an instance of T dotProduct to store the dot product
        for (int i = 0;i < (*this).Size(); i++)
        {
            dotProduct += (*this)[i] * num_array[i]; // Using for loop to iterate each element of two arrays and calculate their dot product

        }
        return dotProduct;
        
    }
}

#endif // !NUMERICARRAY_CPP
