// NumericArray.hpp
// Lea LI
// Level 6 - Exercise 4.2b.3
// Header file for templated NumericArray class derived from Array

#ifndef NumericArray_HPP
#define NumericArray_HPP

#include "Array.hpp"   // Header file for templated Array class
#include <iostream>    // Include standard input and output streams library
using namespace std;

namespace LeaLI
{
    namespace Container
    {
        template <typename T>
        class NumericArray : public Array<T> // Inheritance of Array
        {
        private:
       

        public:
            // Constrcutors and destructor
            NumericArray();                              // Default constructor
            NumericArray(int size_array);         // Constructor with an int argument stipulating array size
            NumericArray(const NumericArray<T>& source); // Copy constructor
            virtual ~NumericArray();                     // Destructor
            
            
            // Numeric functionalities
            // const set as postfix of function cannot change any of current instance's data
            NumericArray<T>& operator = (const NumericArray<T>& newArray);  // Assignment operator pass by reference
            NumericArray<T> operator * (double factor) const; // Scale the elements of the numeric array by a double factor
            NumericArray<T> operator + (const NumericArray<T>& num_array) const; // Add the elements of two numeric arrays
            // Throw an exception in case no same size

            T DotProduct(const NumericArray<T>& num_array) const;  // Calculate the dot product
        };
    }
}

#ifndef NumericArray_CPP
#include "NumericArray.cpp"
#endif // End of NumericArray_CPP

#endif // End of NumericArray_HPP

