// OutOfBoundsException.hpp
// Lea LI
// Level 6 - Exercise 4.2b.3
// Header file for OutOfBoundsException class (with implementation for simplicity)
// OutOfBoundsException class is derived from ArrayException base class

#ifndef OutOfBoundsException_HPP
#define OutOfBoundsException_HPP
#include "ArrayException.hpp"   // Include header file for base class
#include <sstream>              // Standard library header providing string stream classes


namespace LeaLI
{
    namespace Container
    {
        class OutOfBoundsException : public ArrayException // Inheritance of ArrayException
        {
            
        private:
            
            int err; // Store erroneous index

        public :
            // Default constructor with default error index -1
            OutOfBoundsException() :err(-1) // Colon syntax
            {

            }

            // Constructor with an int argument
            OutOfBoundsException(int new_err) :err(new_err) // Colon syntax
            {

            }

            // Copy constructor
            OutOfBoundsException(const OutOfBoundsException& new_exc) :err(new_exc.err) // Colon syntax
            {

            }

            // Ddestructor
            ~OutOfBoundsException()
            {

            }

            // Override GetMessage() function
            std::string GetMessage() const
            {
                std::stringstream ss; // Declare a stringstream object
                ss << "Error index " << err << " is out of bounds. ";
                return ss.str(); // Return error message
            }

        };
        
    }
}
#endif // End of if statement for OutOfBoundsException_HPP
