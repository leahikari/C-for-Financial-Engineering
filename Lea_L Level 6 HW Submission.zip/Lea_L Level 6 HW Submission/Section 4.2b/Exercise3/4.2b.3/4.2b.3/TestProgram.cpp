// TestProgram.cpp
// Lea LI
// Level 6 - Exercise 4.2b.3
// Simple test program on derived PointArray class functionality

#include "Point.hpp"         // Header file for Point class
#include "Array.hpp"         // Header file for templated Array class
#include "PointArray.hpp"    // Header file for templated PointArray class
#include "ArrayException.hpp"// Header file for ArrayException class
#include <iostream>          // Include standard input and output streams library


using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration
using namespace LeaLI::Container;

int main()
{
    // Test default constructor
    PointArray PointArray;   // Create an default instance of PointArray
    cout << "Test default constructor of PointArray" << endl;
    cout << "The size of default PointArray is : " << PointArray.Size()<< endl;
    
    // Test [] operator to write elements
    PointArray[0] = Point(1,2);
    PointArray[1] = Point(3,4);
    
    // Test SetElement() to set elements
    PointArray[2] = Point(5,6);
    PointArray[3] = Point(7,8);
    
    // Test GetElement() to get elements
    cout << "The first four elements of PointArray are: " << endl;
    for (int i=0; i < 4 ; i++)
    {
        cout << PointArray.GetElement(i) << endl;
    }
    
    // Test assignment operator
    cout << "Let PointArray2 = PointArray" << endl;
    cout << "Print each element of PointArray2 : " << endl;
    class PointArray PointArray2 = PointArray;  // Declare PointArray
    for (int i=0; i < PointArray2.Size(); i++)
    {
        cout << PointArray2[i] << endl;
    }
    
    // Test exception handling
    cout << "Let's test PointArray2.GetElement(99): " << endl;
    try
    {
        cout << PointArray2.GetElement(99) << endl; // GetElement() will throw an error

    }
    catch (ArrayException& exc)
    {
        cout << exc.GetMessage() << endl; // Print error message
    }
    
    // Test PointArray Length()
    cout << "Test PointArray Length()" << endl;
    cout << "The calculated length of PointArray is " << PointArray.Length() << endl;

    return 0;
}
