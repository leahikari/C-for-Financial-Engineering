// PointArray.cpp
// Lea LI
// Level 6 - Exercise 4.2b.3
// Source file for PointArray class derived from Array

#ifndef PointArray_CPP
#define PointArray_CPP
#include "PointArray.hpp" // Header file for PointArray class
#include "Point.hpp"      // Header file for Point class

using namespace std;
using namespace LeaLI;
using namespace Container;

// Default constructor
PointArray::PointArray() : Array<Point>() // No private member data of PointArray needs to be initialised
{
    
}

// Constructor with an int size argument
PointArray::PointArray(int size) :Array<Point>(size)
{
    
}
// Copy constructor
PointArray::PointArray(const PointArray& source) : Array<Point>(source)
{
    
}

// Destructor
PointArray::~PointArray()
{
    
}

// Assignment operator
PointArray& PointArray::operator = (const PointArray& source) 
{
    if (this == &source)   // Avoid assigning to itself
    {
        return *this;  
    }

    Array<Point>::operator =(source); // Call base class assignment operator
    return *this;                     // Return assigned PointArray
}

// Implementation of length function
// Returns the total length between the points in the array

double PointArray::Length() const
{
    double sum = 0;  //declare a double value for calculated length result
    if ((*this).Size() == 1) // Return 0 if we only have one single point
    {
        return 0;
    }
    else
    {
        for (int i = 0; i != (*this).Size()-1; i++)
        {
            sum = sum + (*this)[i].Distance((*this)[i + 1]);  // Add each length between consecutive indexed points
        }
        return sum;
    }
}


    
#endif    // PointArray_CPP
