// PointArray.hpp
// Lea LI
// Level 6 - Exercise 4.2b.3
// Header file for PointArray class derived from Array

#ifndef PointArray_HPP
#define PointArray_HPP

#include "Array.hpp"   // Header file for templated Array class
#include "Point.hpp"   // Header file for templated Point class
#include <iostream>    // Include standard input and output streams library
using namespace std;
using namespace LeaLI::CAD; // Namespace LeaLI::CAD declaration

namespace LeaLI
{
    namespace Container
    {
        class PointArray : public Array<Point>  // Array<T> argument is fixed to Point type (concrete inheritance)
        {
        private:
            // No private member data
        public:
            // Constructors and destructor
            
            PointArray();                          // Default constructor
            PointArray(const int size);            // Constructor takes an int size argument
            PointArray(const PointArray& source);  // Copy constructor
            virtual ~PointArray();                 // Destructor
            
            // Assignment operator
            PointArray& operator = (const PointArray& source);
            double Length() const;  // Returns the total length between the points in the array
        };
    }
}

#endif // End of PointArray_HPP
