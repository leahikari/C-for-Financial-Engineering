// Stack.Cpp
// Lea LI
// Level 6 - Exercise 4.2b.4
// Implementation file for templated Stack class
// Use Array as data member (Composition)

#ifndef Stack_CPP
#define Stack_CPP
#include "Stack.hpp"   // Header file for templated Stack class
#include "OutOfBoundsException.hpp"

using namespace std;
using namespace LeaLI;
using namespace Container;

// Default constructor
template<typename T>
Stack<T>::Stack() : m_current(0), array()
{

}

// Constructor with an int size argument
template<typename T>
Stack<T>::Stack(int newSize) :m_current(0), array(newSize) 
{

}

// Copy constructor
template<typename T>
Stack<T>::Stack(const Stack<T>& source) :m_current(source.m_current), array(source.array)
{

}

// Destructor
template<typename T>
Stack<T>::~Stack()
{

}

// Assignment operator
template<typename T>
Stack<T>& Stack<T>::operator = (const Stack<T>& source)
{
    if (this == &source)    // Avoid assign to itself
    {
        return (*this);     // Return current object
    }
    else
    {
        m_current==(source.m_current);
        array=(source.array);         // Assign member data
        return (*this);               // Return assigned object Stack<T>
    }
}


// Push() function
// Store the element at the current position and increment afterwards
template<typename T>
void Stack<T>::Push(const T& element)
{
    
    if (m_current >= (*this).array.Size())     // Check if current array reaches its bound
    {
        throw OutOfBoundsException(m_current); // Impossible to push afterwards, throw an exception
    }
    else
    {
        array[m_current] = element;   // Store the element at the current position
        m_current += 1;               // Then increment the current position
        
    }
}

// Pop() function
// Return the element at decremented position
template<typename T>
T& Stack<T>::Pop()
{
    if (m_current  == 0 )                       // Check if current array reaches its upper bound
    {
        throw OutOfBoundsException(m_current ); // Impossible to pop forward, throw an exception
    }
    else
    {
        m_current -=  1;             // Decrement the current position
        return array[m_current];     // Return element at decremented position
    
    }

}


#endif  // Stack_CPP
