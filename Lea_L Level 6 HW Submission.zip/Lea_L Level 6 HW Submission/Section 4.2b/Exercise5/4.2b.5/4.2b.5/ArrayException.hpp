// ArrayException.hpp
// Lea LI
// Level 6 - Exercise 4.2b.5
// Header file for ArrayException base class (with implementation for simplicity)

#ifndef ArrayException_HPP
#define ArrayException_HPP
#include <string>

namespace LeaLI
{
    namespace Container
    {
        class ArrayException
        {

        private:

        public:

            // Default construcotr
            ArrayException()
            {

            }

            // Copy construcotr
            ArrayException(const ArrayException& a)
            {

            }

            // Declare virtual destructor
            virtual ~ArrayException()
            {

            }

            // Abstract GetMessage() function
            virtual std::string GetMessage() const = 0;
            
        };
    }
}

#endif // End of if statement ArrayException_HPP
