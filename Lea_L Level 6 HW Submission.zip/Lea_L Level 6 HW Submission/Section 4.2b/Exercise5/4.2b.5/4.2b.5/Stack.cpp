// Stack.Cpp
// Lea LI
// Level 6 - Exercise 4.2b.5
// Implementation file for templated Stack class
// Use Array as data member (Composition)

#ifndef Stack_CPP
#define Stack_CPP
#include "Stack.hpp"              // Header file for templated Stack class
#include "StackFullException.hpp" // Header file for StackFullException class
#include "StackEmptyException.hpp" //Header file for StackEmptyException class
#include "OutOfBoundsException.hpp"
#include <iostream>

using namespace std;
using namespace LeaLI;
using namespace Container;

// Default constructor
template<typename T>
Stack<T>::Stack() : m_current(0), array()
{

}

// Constructor with an int size argument
template<typename T>
Stack<T>::Stack(int newSize) :m_current(0), array(newSize) 
{

}

// Copy constructor
template<typename T>
Stack<T>::Stack(const Stack<T>& source) :m_current(source.m_current), array(source.array)
{

}

// Destructor
template<typename T>
Stack<T>::~Stack()
{

}

// Assignment operator
template<typename T>
Stack<T>& Stack<T>::operator = (const Stack<T>& source)
{
    if (this == &source)    // Avoid assign to itself
    {
        return (*this);     // Return current object
    }
    else
    {
        m_current==(source.m_current);
        array=(source.array);         // Assign member data
        return (*this);               // Return assigned object Stack<T>
    }
}


// Push() function
// Store the element at the current position and increment afterwards

template<typename T>
void Stack<T>::Push(const T& element)
{
    try
    {
        array[m_current] = element;  // Store the element at the current position
        m_current += 1;              // Then increment the current position
    }
    catch(const ArrayException& exc) // Catch array exception
    {
        throw StackFullException();  // Throw an stack full exception to client interface
    }
    
    catch (...)  // Default catch
    {
        cout << "An unhandled exception has occurred" << endl;
        
    }
}


// Pop() function
// Return the element at decremented position
template<typename T>
T& Stack<T>::Pop()
{
    try
    {
        m_current -=  1;             // Decrement the current position
        return array[m_current];     // Return element at decremented position
    }
    catch(const ArrayException& exc) // Catch array exception
    {
        m_current = 0;
        throw StackEmptyException(); // Throw an stack empty exception to client interface
    }
}

#endif  // Stack_CPP
