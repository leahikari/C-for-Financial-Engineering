// StackException.hpp
// Lea LI
// Level 6 - Exercise 4.2b.5
// Header file for StackException class (with implementation for simplicity)
// Translate an array exception to a stack exception

#ifndef StackException_HPP
#define StackException_HPP

#include <sstream>              // Standard library header providing string stream classes
namespace LeaLI
{
    namespace Container
    {
        class StackException
        {

        private:

        public:

            // Default construcotr
            StackException()
            {

            }

            // Copy construcotr
            StackException(const StackException& source)
            {

            }

            // Declare virtual destructor
            virtual ~StackException()
            {

            }

            // Abstract GetMessage() function
            virtual std::string GetMessage() const = 0;
            
        };
    }
}

#endif // End of StackException_HPP
