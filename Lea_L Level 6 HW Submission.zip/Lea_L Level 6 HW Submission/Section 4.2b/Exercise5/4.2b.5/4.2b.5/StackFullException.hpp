// StackFullException.hpp
// Lea LI
// Level 6 - Exercise 4.2b.5
// Header file for StackFullException class (with implementation for simplicity)
// StackFullException class is derived from StackException base class

#ifndef StackFullException_HPP
#define StackFullException_HPP

#include "StackException.hpp"   // Include header file for base class
#include <sstream>              // Standard library header providing string stream classes

namespace LeaLI
{
    namespace Container
    {
        class StackFullException : public StackException // Inheritance of StackException
        {
            
        private:
            // No Private members
           
            
        public :
            // Default constructor
            // Specifiying base class default constructor at first
            StackFullException() : StackException()
            {

            }
        
            // Copy constructor
            StackFullException(const StackFullException& new_exc) : StackException(new_exc)
            {

            }

            // Ddestructor
            ~StackFullException()
            {

            }

            // Override GetMessage() function
            std::string GetMessage() const
            {
                std::stringstream ss; // Declare a stringstream object
                ss << "The stack is full."<< endl;
                return ss.str(); // Return error message
            }

        };
        
    }
}
#endif // End of StackFullException_HPP
