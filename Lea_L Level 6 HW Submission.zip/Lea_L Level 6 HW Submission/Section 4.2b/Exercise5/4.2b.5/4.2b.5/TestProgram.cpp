// TestProgram.cpp
// Lea LI
// Level 6 - Exercise 4.2b.5
// Simple test program on Layering Exceptions
// The array exception must be translated to a stack exception

#include "Array.hpp"         // Header file for templated Array class
#include "Stack.hpp"         // Header file for templated Stack class
#include "StackException.hpp"// Header file for StackException class
#include "ArrayException.hpp"// Header file for ArrayException class
#include <iostream>          // Include standard input and output streams library

using namespace std;
using namespace LeaLI::Container;

int main()
{
    // Create respectively instances of Stack<int> and Stack<double>
    Stack<int> stack1; // Deafult constrcuctor of Stack<int> gets called
    Stack<double> stack3(3); // Set stack3 size to 3
    
    // Test when Push() out of bounds
    for (int i=0; i < 3 ; i++)
    {
        stack3.Push(i*2); // Store i*2 at current position i then increment
    }
    try
    {
        stack3.Push(3);
    }
    catch(StackException& exc)
    {
        cout << exc.GetMessage() << endl;
    }

    // stack1.m_current = 0
    // Push for stack1
    for (int i=0; i < 5 ; i++)
    {
        stack1.Push(i*2); // Store i*2 at current position i then increment
    }
    
    // Test copy constructor and pop for stack3
    cout << "Let's copy stack1 and pop" << endl;;
    Stack<int> stack2(stack1);
    for (int i=0; i < 10; i++)
    {
        try
        {
            cout << stack2.Pop() << endl;;
        }
        catch(StackException& exc)
        {
            cout << exc.GetMessage() << endl;
        }
        // We cannot pop() forward since we already reach index 0 after printed 5 integers
        // 5 error message will be printed
        catch (...)  // If not catch Default catch wioll be called
        {
            cout << "An unhandled exception has occurred" << endl;
        }
    }

    return 0;
}
