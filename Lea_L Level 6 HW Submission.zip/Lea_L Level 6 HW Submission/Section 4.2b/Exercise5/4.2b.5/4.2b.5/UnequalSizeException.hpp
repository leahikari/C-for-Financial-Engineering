// UnequalSizeException.hpp
// Lea LI
// Level 6 - Exercise 4.2b.5
// Header file for UnequalSizeException class (with implementation for simplicity)
// UnequalSizeException class is derived from ArrayException base class

#ifndef UnequalSizeException_HPP
#define UnequalSizeException_HPP

#include "ArrayException.hpp"   // Include header file for base class
#include <sstream>              // Standard library header providing string stream classes

namespace LeaLI
{
    namespace Container
    {
        class UnequalSizeException : public ArrayException // Inheritance of ArrayException
        {
            
        private:
            // Private members storing two array size
            int m_size1;
            int m_size2;
            
        public :
            // Default constructor
            // Specifiying base class default constructor at first
            UnequalSizeException() : ArrayException(),m_size1(0), m_size2(1) // Colon syntax
            {

            }
        
            // Constructor with two array size
            UnequalSizeException(const int& newSize1, const int& newSize2) : ArrayException(), m_size1(newSize1), m_size2(newSize2)
            {

            }

            // Copy constructor
            UnequalSizeException(const UnequalSizeException& new_exc) : ArrayException(new_exc), m_size1(new_exc.m_size1), m_size2(new_exc.m_size2)
            {

            }

            // Ddestructor
            ~UnequalSizeException()
            {

            }

            // Override GetMessage() function
            std::string GetMessage() const
            {
                std::stringstream ss; // Declare a stringstream object
                ss << "Size of two arrays are respectively " << m_size1 << " and " <<m_size2 << " don't match So we cannot perform the operation"<< endl;
                return ss.str(); // Return error message
            }

        };
        
    }
}

#endif // End of UnequalSizeException_HPP



