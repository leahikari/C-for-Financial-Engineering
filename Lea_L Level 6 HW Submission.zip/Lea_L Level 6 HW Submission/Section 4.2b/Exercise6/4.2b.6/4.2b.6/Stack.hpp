// Stack.hpp
// Lea LI
// Level 6 - Exercise 4.2b.6
// Header file for templated Stack class
// Use Array as data member (Composition)
// Add a value template argument to set the stack size (remove the constructor with size)


#ifndef Stack_HPP
#define Stack_HPP
#include "Array.hpp" // Include header file of Array class

namespace LeaLI
{
    namespace Container
    {
        template <typename T, int size>
        class Stack
        {
            
        private:
            // Declare private members for class Stack<T>
            int m_current;   // Current index
            Array<T> array;  // Array object will be used for data storage

        public:
            // Constrcutors and destructor
            Stack();                               // Default constructor
            Stack(const Stack<T,size>& source);    // Copy constructor
            virtual ~Stack();                      // Destructor
            
            // Assignment operator
            Stack<T,size>& operator = (const Stack<T,size>& source);
            
            void Push(const T& element);  // Store the element at the current position then increment
            T& Pop();  // Return the element at decremented position
            
        };
    }
}

#ifndef Stack_CPP // Must be the same name as in source file #define
#include "Stack.cpp"
#endif// End of Stack_CPP

#endif // Stack_HPP
