// TestProgram.cpp
// Lea LI
// Level 6 - Exercise 4.2b.6
// Simple test program on Value Template Arguments

#include "Array.hpp"         // Header file for templated Array class
#include "Stack.hpp"         // Header file for templated Stack class
#include "StackException.hpp"// Header file for StackException class
#include "ArrayException.hpp"// Header file for ArrayException class
#include <iostream>          // Include standard input and output streams library

using namespace std;
using namespace LeaLI::Container;

int main()
{
    // Create respectively instances of Stack<int,size> and Stack<double,size>
    Stack<int, 3> stack1;
    Stack<double, 3> stack2;
    
    // Test when Push() out of bounds
    for (int i=0; i < 3 ; i++)
    {
        stack1.Push(i*2); // Store i*2 at current position i then increment
        stack2.Push(i*2.5); // Store i*2 at current position i then increment
    }
    cout << "Try Push() out of bounds on stack1 and stack2" << endl;
    try
    {
        stack1.Push(3);
    }
    catch(StackException& exc)
    {
        cout << exc.GetMessage() << endl;
    }
    
    // Test for Stack<double,size>
    try
    {
        stack2.Push(4); // Stack is full, Throw an error
    }
    catch(StackException& exc)
    {
        cout << exc.GetMessage() << endl;
    }
    
    // Test copy constructor and pop for stack3
    cout << "Let's copy stack1 and pop" << endl;;
    Stack<int,3> stack3(stack1);
    for (int i=0; i < 5; i++)
    {
        try
        {
            cout << stack3.Pop() << endl;;
        }
        catch(StackException& exc)
        {
            cout << exc.GetMessage() << endl;
        }
        // We cannot pop() forward since we already reach index 0 after printed 3 integers
        // 2 error message will be printed
        catch (...)  // If not catch Default catch will be called
        {
            cout << "An unhandled exception has occurred" << endl;
        }
    }
    
    return 0;
}
