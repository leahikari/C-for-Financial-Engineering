// STL_Containers.cpp
// Lea LI
// Level 7 exercise1
// Program to practice with the different STL containers

#include <iostream>    // Include standard input and output streams library
#include <list>        // Include list containers
#include <iterator>    // Include STL iterators
#include <vector>      // Include vector containers
#include <map>         // Include map containers

using namespace std;
int main()
{
    cout << "Let's create a list of doubles l1 using push_back():" << endl;
    list <double> l1; // Create a list of doubles
    // Using for loop ietarte the list and assign some value
    for (int i = 0; i < 3; i++)
    {
        l1.push_back(i*i); // Add elements from the back
        
    }

    // Use front() and back() to access respectively the first element and the last element of l1
    cout << "The first element of the l1 is :" << l1.front() << endl;
    cout << "The last element of the l1 is :" << l1.back() << endl;
    
    // list supports forward and backward traversal
    // Then insert data from the front
    l1.push_front(1);
    l1.push_front(2);
    // Use front() to access the first element of l1
    cout << "The first element of the l1 after push_front() 2 elements:" << l1.front() << endl;
    
    // Now create an iterator for l1
    list<double>::iterator il;
    // Iterate and print each element
    for (il=l1.begin(); il != l1.end(); il++)
    {
        cout << *il << ","; // il acts as pointer
    }
    
    cout << endl;
    cout << "------------------------------------------" << endl;
    cout << "Now Let's create a vector of doubles vec1:" << endl;
    
    
    vector<double> vec1;        // Create a vector of doubles
    for (int i=0 ; i < 10; i++)
    {
        vec1.push_back(i*2);    // Vector does not support front insertion!
    }
    // Print elements using index operator
    cout << "The last element of vector vec1: " << vec1[9] << endl;
    cout << "The second last element of vector vec1: " << vec1[8] << endl;
    cout << "Size of vec1 : " << vec1.size() << endl;
    cout << "Max size of vec1 : " << vec1.max_size() << endl;
    cout << "Capacity of vec1 : " << vec1.capacity() << endl;
    // Let the vector grow the print size
    vec1.push_back(30);
    vec1.push_back(40);
    cout << "Size of vec1 after push_back() 2 elements: " << vec1.size() << endl;
    cout << "Capacity of vec1 after push_back() 2 elements: " << vec1.capacity() << endl;
    // Reverse the order and then print
    reverse(vec1.begin(),vec1.end());
    cout << "After reverse() the vec1 became: ";
    // Create an interator for vec1 in for loop
    for (vector<double>::iterator iv=vec1.begin(); iv!=vec1.end(); ++iv)
    {
        cout << *iv << ","; // iv acts as a pointer
    }
    vec1.clear(); // Clear vec1 from the vector container
    
    cout << endl;
    cout << "------------------------------------------" << endl;
    cout << "Now Let's create a map that maps strings to doubles:" << endl;
    

    map<string, double> m1;  // Create a map that maps strings to doubles
    // Using the square bracket operator to set different keys
    m1["key1"] = 100.2;
    m1["key2"] = 2.5;
    // Now output results
    cout << "Map key1 in m1 : " << m1["key1"] << endl;
    cout << "Map key2 in m1 : " << m1["key2"] << endl;

    m1.clear(); // Clear m1 from the map container
    
    return 0;
}
