// Sum.hpp
// Lea LI
// Level 7 exercise2
// Header file for template function Sum() that calculates the sum of a container with doubles
// Also a Sum() function that calculates the sum between two iterators
// For simplicity I include function implementations in hpp file

#ifndef Sum_HPP
#define Sum_HPP

#include <list>        // Include list containers
#include <vector>      // Include vector containers
#include <map>         // Include map containers

using namespace std;

// Template function sum() that calculates the sum of a container
// Sum() has a container argument and returns double
template <typename T>
double Sum(const T& container)
{
    double sum = 0;  // Initialise a double variable that temporarity stores the sum
    for (typename T::const_iterator it = container.begin(); it != container.end(); it++)
    {
        sum += *it; // Using iterator to iterate the container T and adds all values
    }
    return sum;
};

// Template function sum() that calculates the sum of container map<T1,T2>
// Sum() has a map argument and returns double
template <typename T1, typename T2>
double Sum(const map<T1, T2>  &m)
{

    double sum = 0;  // Initialise a double variable that temporarity stores the sum
    for (typename map<T1, T2>::const_iterator i = m.begin(); i != m.end(); i++)
    {
        sum += i->second; // Iterate the map and plus the element value to sum
        
    }
    return sum;
}


// Template function sum() that calculate the sum between two iterators
// Sum() uses the template argument for the iterator type and accepts two iterators
template<typename T>
double Sum(typename T::const_iterator start, typename T::const_iterator end)
{
    
    double sum = 0;  // Initialise a double variable that temporarity stores the sum
    for (typename T::const_iterator i = start; i != end; i++)
    {
        sum += *i;   // Sum between two iterators
    }
    return sum;

}

// Template function sum() that calculate the sum between two map iterators
template<typename T1, typename T2>
double Sum(typename map<T1, T2>::const_iterator& start, typename map<T1,T2>::const_iterator& end)
{
    double sum = 0;  // Initialise a double variable that temporarity stores the sum
    for (typename map<T1, T2>::const_iterator i = start; i != end; i++)
    {
        sum += i->second;
    }
    
    return sum;
}


#endif // End of Sum_HPP

