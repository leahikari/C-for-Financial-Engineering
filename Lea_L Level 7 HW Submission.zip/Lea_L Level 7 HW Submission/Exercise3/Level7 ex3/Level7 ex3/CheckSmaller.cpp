// CheckSmaller.cpp
// Lea LI
// Level 7 exercise3
// Source file for templated class CheckSmaller<T>
// Instance of CheckSmaller<T>() is a function object


#ifndef CheckSmaller_CPP
#define CheckSmaller_CPP

#include <iostream>          // Include standard input and output streams library
#include "CheckSmaller.hpp"  // Header file for templated class CheckSmaller<T>
#include <iostream> // Standard Input / Output Streams Library

// Default constructor
template<typename T>
CheckSmaller<T>::CheckSmaller(): threshold(0)
{
    
}

// Constructor with new threshold
template<typename T>
CheckSmaller<T>::CheckSmaller(const T newVal): threshold(newVal)
{

}

// Copy constructor
template<typename T>
CheckSmaller<T>::CheckSmaller(const CheckSmaller<T>& source):threshold(source.threshold)
{

}

// Destructor
template<typename T>
CheckSmaller<T>::~CheckSmaller()
{

}

//Assignment operator
template<typename T>
CheckSmaller<T>& CheckSmaller<T>::operator = (const CheckSmaller<T>& source)
{
    if (this == &source)
    {
        return (*this); // Avoid assigning to itself
    }
    
    threshold = source.threshold;  // Assign source threshold to current object
    return *this;
}

// Overloaded () operator
// Instance of CheckSmaller<T>() is a function object
template<typename T>
bool CheckSmaller<T>::operator () (const T& temp) const
{
    return temp < threshold;   // Check if the input is less than threshold
}



#endif //CheckSmaller_CPP
