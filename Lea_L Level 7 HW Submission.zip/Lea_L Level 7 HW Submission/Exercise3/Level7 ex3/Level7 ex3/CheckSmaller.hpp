// CheckSmaller.hpp
// Lea LI
// Level 7 exercise3
// Header file for templated class CheckSmaller<T>

#ifndef CheckSmaller_HPP
#define CheckSmaller_HPP // Avoid multiple inclusion of header file

template <typename T>
class CheckSmaller
{
private:

    T threshold; // Declare data member that stores the value to be checked
    
public:
    
    CheckSmaller();                            // Default constructor
    CheckSmaller(const T newVal);              // Constructor with new value
    CheckSmaller(const CheckSmaller& source);  // Copy constructor
    virtual~CheckSmaller();                    // Destructor
    
    // Assignment operator
    CheckSmaller& operator = (const CheckSmaller& source);
    
    // Overloaded () operator
    // Instance of CheckSmaller<T>() is a function object
    bool operator () (const  T& temp) const;



};

#ifndef CheckSmaller_CPP
#include "CheckSmaller.cpp"
#endif // CheckSmaller_CPP

#endif // End of CheckSmaller_HPP
