// STL_Algorithms.cpp
// Lea LI
// Level 7 exercise3
// Simple test program onSTL algorithm: count_if with different function arguments on different containers

#include <iostream>          // Include standard input and output streams library
#include <list>              // Include list containers
#include <vector>            // Include vector containers
#include <map>               // Include map containers
#include <algorithm>         // Include STL algorithms
#include "CheckSmaller.hpp"  // Header file for templated class CheckSmaller<T>
using namespace std;

// Declare a global function checking whether the input is less than 10
bool IsSmallerThan10(const double val)
{
    return val < 10;
}

int main()
{
    cout << "Create a list of doubles l1 and a vector of doubles vec1 :" << endl;
    list <double> l1; // Create a list of doubles
    // Using for loop ietarte the list and assign some value
    for (int i = 0; i < 6; i++)
    {
        l1.push_back(i*i); // Add elements from the back
        
    }
    
    cout << "Print l1" << endl;
    // Iterate and print each element
    for (list<double>::iterator il=l1.begin(); il != l1.end(); il++)
    {
        cout << *il << ","; // il acts as pointer
    }
    
    vector<double> vec1;        // Create a vector of doubles
    for (int i=0 ; i < 10; i++)
    {
        vec1.push_back(i*2);    // Vector does not support front insertion!
    }
    vec1.push_back(30);
    vec1.push_back(40);
    // Reverse the order and then print
    reverse(vec1.begin(),vec1.end());
    cout << endl;
    
    cout << "Print vec1" << endl;
    // Iterate and print each element
    for (vector<double>::iterator iv=vec1.begin(); iv!=vec1.end(); ++iv)
    {
        cout << *iv << ","; // iv acts as a pointer
    }
    
    cout << endl;
    cout << "Now let's use STL algorithm count_if with different function arguments on l1" << endl;
    // Call global function IsSmallerThan10() on l1
    cout << "With global checking function IsSmallerThan10: " << count_if(l1.begin(), l1.end(), IsSmallerThan10) << endl;
    cout << "With function object CheckSmaller<double>(10) : "<< count_if(l1.begin(), l1.end(), CheckSmaller<double>(10)) << endl;
    cout << "With function object CheckSmaller<double>(5) : "<< count_if(l1.begin(), l1.end(), CheckSmaller<double>(5)) << endl;
    
    cout << "------------------------------------------------" << endl;
    cout << "Now let's use STL algorithm count_if with different function arguments on vec1" << endl;
    // Call global function IsSmallerThan10() on vec1
    cout << "With global checking function IsSmallerThan10: " << count_if(vec1.begin(), vec1.end(), IsSmallerThan10) << endl;
    cout << "With function object CheckSmaller<double> CheckSmaller(10): "<< count_if(vec1.begin(), vec1.end(), CheckSmaller<double>(10)) << endl;
    cout << "With function object CheckSmaller<double> CheckSmaller(20): "<< count_if(vec1.begin(), vec1.end(), CheckSmaller<double>(20)) << endl;

    
    return 0;
}
