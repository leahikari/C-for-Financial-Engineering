// SmartPointers.cpp
// Lea LI
// Level 8 - Exercise 5.1.1
// Simple test program on array of shapes with smart pointers
// Using boost::shared_ptr<T> class which enables auto-deletion of objects


#include <iostream>    // Include standard input and output streams library
#include "Array.hpp"   // Header file for templated Array class
#include "Shape.hpp"   // Header file for Abstract Shape class
#include "Point.hpp"   // Header file for Point class
#include "Line.hpp"    // Header file for Line class
#include "Circle.hpp"  // Header file for Circle class
#include "boost/shared_ptr.hpp"  // Boost template class that stores dynamically allocated objects
#include "ArrayException.hpp"    // Header file for ArrayException class

using namespace std;
using namespace LeaLI::CAD;
using namespace LeaLI::Container;

// Typedef for a shared pointer to shape and
// a typedef for an array with shapes stored as shared pointers.
typedef boost::shared_ptr<Shape> ShapePtr;
typedef Array<ShapePtr> ShapeArray;



int main()
{
    // Initialize an Array with shared pointers for shapes and set array size to 3
    ShapeArray shape_array(3);
    {
        {
            // Assign shared pointers different shapes
            shape_array[0] = ShapePtr(new Point(3,4));
            shape_array[1] = ShapePtr(new Circle(Point(0,0),4));
            shape_array[2] = ShapePtr(new Line(Point(0,0),Point(1,1)));
            // Print each element of shape_array
            for (int i = 0; i < 3; i++)
            {
                cout<<" Print shape at index "<< i <<": ";
                shape_array[i]->Print();
            }
            // Print each reference count
            for (int i = 0; i < 3; i++)
            cout<<"Reference count for shape at index " << i << ": "<< shape_array[i].use_count() << endl;
        }
        
        cout<<"---------------------------------------"<< endl;
        cout<<"Now let's assign these shapes respectively to SharedPointers p1,p2 and p3 "<< endl;
        
        {
            ShapePtr p1 = shape_array[0];
            ShapePtr p2 = shape_array[1];
            ShapePtr p3 = shape_array[2];
            ShapePtr p4(shape_array[0]); // Let shape at index 0 be referenced again and print ref count
            // Print reference count for each shared pointer
            for (int i = 0; i < 3; i++)
            cout<<"Reference count of SharedPointer p" << i+1 << ": "<< shape_array[i].use_count() << endl;
        }
        
        // Print reference count when out of ref scope
        // We can observe that shared pointers automatically delete references when we do not reference shapes anymore
        for (int i = 0; i < 3; i++)
        cout<<"Reference count for shape at index " << i << " when out of scope: "<< shape_array[i].use_count() << endl;
        
    }
    return 0;
}


