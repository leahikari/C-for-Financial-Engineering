// Tuple_Person.cpp
// Lea LI
// Level 8 - Exercise 5.1.2
// Simple program using Tuple class
// Create a typedef for a Person tuple that contains a name, age and length and function print()


#include <boost/tuple/tuple.hpp>	// Header file for Tuple class
#include <boost/tuple/tuple_io.hpp> // Header file for I/O tuples
#include <string>     // Standard library header providing string classes
#include <iostream>   // Include standard input and output streams library
using namespace std;

// Declare a typedef for a Person consisting of name, age and length
typedef boost::tuple<string, int, double> Person;

// Create a function that prints the person tuple
void PrintPerson(const Person& person)
{
    cout << "Person details: " << endl;
    // Using get<T>() member function of tuple class to access data
    cout << "Name: " << person.get<0>() << ", Age: " << person.get<1>() << ", Length: " << person.get<2>() << endl;
    
}


int main()
{
    // Creating person instances p1, p2 and p3 using Tuple constructor
    // With arguments <string, int, double> that represents respectively name, age and length
    Person p1 = boost::make_tuple(string("Emma"), 27, 176);
    Person p2 = boost::make_tuple(string("John"), 28, 181);
    Person p3 = boost::make_tuple(string("Julie"), 26, 164);
    
    // Call funciton PrintPerson() to print person information
    PrintPerson(p1);
    PrintPerson(p2);
    PrintPerson(p3);
    
    // Increment the age of p1
    // As get<T>() calls by ref we can rewrite the value
    boost::tuples::get<1>(p1) += 5;
    cout << "Print person1 info after incremented the age by 5: " << endl;
    PrintPerson(p1);
    
    // Also try to change the name of p1 by using get<T>()
    boost::tuples::get<0>(p1) = string("Lea");
    cout << "Print person1 info after changing the name: " << endl;
    PrintPerson(p1);
    
    return 0;
 
}
