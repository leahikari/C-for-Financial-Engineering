// Shape.hpp
// Lea LI
// Level 8 - Exercise 5.1.3
// Header file for Shape class
// Declare ToString() function as virtual in header file
// Declare virtual constructor in base class
// Declare virtual member function Draw() in the Shape base class
// Add a Print() function to the Shape class

#ifndef Shape_HPP
#define Shape_HPP     // Prevent multiple inclusion of header file
#include <iostream>   // Include standard input and output streams library
using namespace std;

namespace LeaLI
{
    namespace CAD
    {
        class Shape
        {
        private:
            // Declare private member
            int m_id;    // Declare a variable to store the ID number

        public:
            // Constrcutor and destructor
            Shape();                      // Default constructor
            Shape(int newID);             // Constructor takes an int argument
            Shape(const Shape& source);   // Copy constructor
            
            Shape& operator = (const Shape& source); // Assignment operator
            virtual ~Shape();                                // Destructor

            // Accessing functions
            const int ID() const;          // Retrieve the id of the shape
            virtual string ToString() const; // Returns the id as a string
           
            // Pure virtual member function, do not need implementation in source file of Shape class
            virtual void Draw() const = 0;
            
            void Print() const;    // Print shape information to the cout object
            
        };
    }
}
#endif // Shape_HPP

