// ShapeVisitor.cpp
// Lea LI
// Level 8 - Exercise 5.1.3
// Implementation file for ShapeVisitor class, derived from template base boost::static_visitor<>
// Overloaded operator () changes the coordinates of a shape

#include "ShapeVisitor.hpp"

 namespace LeaLI
{
 namespace CAD
 {
 
 // Default constructor initialises both changes in x and y coordinates to 0
 ShapeVisitor::ShapeVisitor(): m_dx(0), m_dy(0)
 {
     
 };
 
 // Constructor taking 2 double arguments sets increments in x and y coordinates
 ShapeVisitor::ShapeVisitor(double dx, double dy):m_dx(dx), m_dy(dy)
 {
 };
 
 // Copy constructor
 ShapeVisitor::ShapeVisitor(const ShapeVisitor& v): m_dx(v.m_dx), m_dy(v.m_dy)
 {
 }
 
 // Destructor
 ShapeVisitor::~ShapeVisitor()
 {
     
 }
 
 // Assignment operator
 ShapeVisitor& ShapeVisitor::operator= (const ShapeVisitor& source)
 {
     if (this == &source)
         return *this;  // Avoid assigning to itself
     
     m_dx = source.m_dx;
     m_dy = source.m_dy;
     return *this;    // Return assigned ShapeVisitor
 }
 
 // Let overloaded operator() visit different shape types
 // Visit a point
 // Change referenced point coordinates by member data m_dx and m_dy
 void ShapeVisitor::operator() (Point& p) const
 {
     p.X(p.X() + m_dx);
     p.Y(p.Y() + m_dy);
 }
 
 // Visit a line
 // Change referenced Line's both start and end point coordinates by member data m_dx and m_dy
 // We can use ShapeVistor(Point& p) on Line start point and end point
 void ShapeVisitor::operator() (Line& l) const
 {
     // We can directly use overloaded operator+ defined in Point class to change the coordinates of line start and end point
     l.startP(l.startP() + Point(m_dx, m_dy));
     l.endP(l.endP() + Point(m_dx, m_dy));
 }
 
 // Visit a circle
 // Change circle center point coordinates by member data m_dx and m_dy
 // Radius is unchanged
 
 void ShapeVisitor::operator() (Circle& c) const
 {
    // Use overloaded operator+ defined in Point class to change the coordinates of CentrePoint
     c.CentrePoint(c.CentrePoint()+Point(m_dx, m_dy));
 }
 
 }
 
 }

 

