// ShapeVisitor.hpp
// Lea LI
// Level 8 - Exercise 5.1.3
// Header file for Visitor class, derived from template base boost::static_visitor<>
// Overloaded operator () changes the coordinates of a shape


#include <boost/variant/static_visitor.hpp> // Include header file for base template boost::static_visitor<T>
#include "Line.hpp"    // Header file for Line cl ass
#include "Point.hpp"   // Header file for Point class
#include "Circle.hpp"  // Header file for Circle class
#include "Shape.hpp"   // Header file for Shape class


#ifndef ShapeVisitor_HPP
#define ShapeVisitor_HPP // Prevent multiple inclusion of ShapeVisitor header

namespace LeaLI
{
    namespace CAD
    {
        class ShapeVisitor : public boost::static_visitor<> // Inheritance of static_visitor<>
        {
        private:
            
            double m_dx; // Change in x-coordinate
            double m_dy; // Change in y-coordinate
            
        public:
            
            // Constructors and destructor
            ShapeVisitor();                      // Default constructor
            ShapeVisitor(double dx, double dy);  // Constructor takes 2 double arguments
            ShapeVisitor(const ShapeVisitor& v); // Copy constructor
            
            // Destructor
            ~ShapeVisitor();
            
            // Assignment operator
            ShapeVisitor& operator = (const ShapeVisitor& source);
    
            // Let overloaded operator() visit different shape types
            void operator() (Point& p) const;  // Visit a point
            void operator() (Line& l) const;   // Visit a line
            void operator() (Circle& c) const; // Visit a circle
           
       };
    
    }

}


#endif // End of ShapeVisitor_HPP

