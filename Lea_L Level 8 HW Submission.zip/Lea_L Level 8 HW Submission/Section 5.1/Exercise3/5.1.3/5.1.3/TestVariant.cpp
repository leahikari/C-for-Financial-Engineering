// TestVariant.cpp
// Lea LI
// Level 8 - Exercise 5.1.3
// Simple program using boost::variant - class enables storing values of different types
// Create a typedef for a ShapeType variant that can contain a Point, Line or Circle


#include "Line.hpp"    // Header file for Line class
#include "Point.hpp"   // Header file for Point class
#include "Circle.hpp"  // Header file for Circle class
#include "Shape.hpp"   // Header file for Shape class
#include <iostream>    // Include standard input and output streams library
#include "ShapeVisitor.hpp"                 // Include header file for ShapeVisitor
#include <boost/variant.hpp>                // Include header file for boost::variant
#include <boost/variant/static_visitor.hpp> // Include template base class boost::static_visitor<T>

using namespace std;
using namespace LeaLI::CAD;

// Create a typedef for a ShapeType variant that can contain a Point, Line or Circle
typedef boost::variant<Point, Line, Circle> ShapeType;



// Function that requests user input on shape type
ShapeType ShapeChoice()
{
   
    ShapeType shape;   // Create a ShapeType variant named shape
    char shape_choice; // Declare a char variable that stores shape chosen by user
    
    cout << "Please chose a shape type and enter the corresponding letter : a(Point) b(Line) c(Circle) " << endl;
    cout <<" Your choice: ";
    cin >> shape_choice;
    
    switch (shape_choice)
    {
    // Using switch to handle different choices
    // Set default return as Point
    case 'a':
        shape = Point(); // Assign default point to shape
        cout << "You have chosen Point." << endl;
        break;

    case 'b':
        shape = Line(); // Assign default line to shape
        cout << "You have chosen Line." << endl;
        break;
            
    case 'c':
        shape = Circle(); // Assign default circle to shape
        cout << "You have chosen Circle." << endl;
        break;

    default:  // Default choice
        shape = Point();
        cout << "None of the shapes has been chosen. Return Point by default." << endl;
        break;
    }
    
    return shape;
}



int main()
{

    ShapeType test_variant = ShapeChoice(); // Assign the shape choice to test_variant
    
    // Print the variant
    cout << "Print the variant:" << endl;
    cout << test_variant << endl;

    try
    {
        // Try to assign the variant to a Line variable
        // Using the global boost : get<T>() function
        Line l = boost::get<Line>(test_variant);
    }
    catch (const boost::bad_get& err)// Catch error if not conatin a line
    {
        // Print error message
        cout << err.what() << endl;
        cout << "Your variant didn't contain a line" << endl;
    }
    
    cout << "-------------------------------------" << endl;
    cout << "Now let's test the visitor by shape type" << endl;
    
    // Create different ShapeType variants
    ShapeType p1 = Point(1,1);
    ShapeType l1 = Line(Point(0,0),Point(3,4));
    ShapeType c1 = Circle(Point(1,2),4);
    
    // Print variants before visiting
    cout << "Before visiting, variant p1 is: " << p1 << endl;
    cout << "Before visiting, variant l1 is: " << l1 << endl;
    cout << "Before visiting, variant c1 is: " << c1 << endl;
    
    // Create a shape visitor v
    ShapeVisitor v(-1.0, 2.0);
    
    // Letse boost::apply_visitor(visitor, variant) to move the different shapes
    boost::apply_visitor(v, p1);
    boost::apply_visitor(v, l1);
    boost::apply_visitor(v, c1);
    
    // Print variants after visiting
    cout << "After visiting, variant p1 is: " << p1 << endl;
    cout << "After visiting, variant l1 is: " << l1 << endl;
    cout << "After visiting, variant c1 is: " << c1 << endl;
    
    // We can observe that the visted results are correct
 
    return 0;
}

