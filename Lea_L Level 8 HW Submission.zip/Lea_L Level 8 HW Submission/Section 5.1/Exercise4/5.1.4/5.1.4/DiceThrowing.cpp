// DiceThrowing.cpp
// Lea_LI
// Level_8 Exercise 5.1.4
// Test program to simulate dice throwing with Random Number Generation
// 

#include "boost/random.hpp" // Header file for random number generation
#include <map>              // Header file for map class
#include <iostream>  // Include standard input and output streams library

using namespace std;

int main()
{
    // Throwing dice.
    // Mersenne Twister.
    boost::random::mt19937 myRng;

    // Set the seed.
    myRng.seed(static_cast<boost::uint32_t> (std::time(0)));

    // Uniform in range [1,6]
    boost::random::uniform_int_distribution<int> six(1, 6);
    
    // Now create a map that holds the frequency of each outcome
    map<int, long> statistics; // Structure to hold outcome + frequencies
    int outcome;               // Current outcome

    int num_trials; // Declare an int variable that stores the number of trials

    cout << "How many trials? ";
    cin >> num_trials;  // Get input from user and we can put 1000000

    // Simulate throwing dice
    for (int i = 0; i < num_trials; i++)
    {
        outcome = six(myRng);    // Generate random ints from range [1,6] using engine myRng conforming discrete uniform distribution
        statistics[outcome]+= 1; // Increment frequency of each outcome in map container statistics
    }
    
    // Print result
    for (int i = 1; i <= 6; i++)
    {
    
        cout << "Trial " << i << " has " << (double)statistics[i] / num_trials * 100 << "% outcomes" << endl;
    }
     
    statistics.clear(); // Clear map container
    
    return 0;
}
