// TestNormalDistribution.cpp
// Lea LI
// Level 8 Exercise 5.1.5
// Program on boost statistical functions
// Modification on DataSim's TestNormalDistribution.cpp at 2023/08/04
// Replaced normal distribution with exponential distribution
// Replaced gamma distribution with Poisson distributions


#include <boost/math/distributions/exponential.hpp> // Include header file for exponential distribution
#include <boost/math/distributions/poisson.hpp>     // Include header file for Poisson distribution
#include <boost/math/distributions.hpp> // For non-member functions of distributions

#include <vector>
#include <iostream>
using namespace std;


int main()
{
	// Don't forget to tell compiler which namespace
	using namespace boost::math;
    
    double scaleParameter = 0.5; // Set exponential distributon parametr
    double x = 5.25; // Declare a double for further calculation of statistical functions
    
    // Create an exponential_distribution named myExponential and the default type is 'double'
    exponential_distribution<> myExponential(scaleParameter);
    
    // Choose precision
    cout.precision(10); // Number of values behind the comma

    // Statistical properties of Exp(0.5)
    cout << "Statictical properties of exponential_distribution(0.5)" << endl;
    cout << "pdf: " << pdf(myExponential, x) << endl;
    cout << "cdf: " << cdf(myExponential, x) << endl;
    cout << "mean: " << mean(myExponential) << endl;
    cout << "variance: " << variance(myExponential) << endl;
    cout << "standard deviation: " << standard_deviation(myExponential) << endl;
    cout << "median: " << median(myExponential) << endl;
    cout << "mode: " << mode(myExponential) << endl;
    cout << "kurtosis excess: " << kurtosis_excess(myExponential) << endl;
    cout << "kurtosis: " << kurtosis(myExponential) << endl;
    cout << "skewness: " << skewness(myExponential) << endl;
    cout << "characteristic function: " << chf(myExponential, x) << endl;
    cout << "hazard: " << hazard(myExponential, x) << endl;
    
    cout << endl;
    cout << "-----------------------------------" << endl;
    cout << "Now let's test Poisson distribution" << endl;
    
    // Poission distribution
    double lamda = 3.0;
    double y = 13.0; // Declare a double for further calculation of statistical functions
    
    // Create a Poisson distribution named myPoisson with mean = 3.0
    poisson_distribution<double> myPoisson(lamda);

    
    cout << "Statictical properties of poisson_distribution(3.0)" << endl;
    cout << "pdf: " << pdf(myPoisson, y) << endl;
    cout << "cdf: " << cdf(myPoisson, y) << endl;
    cout << "mean: " << mean(myPoisson) << endl;
    cout << "variance: " << variance(myPoisson) << endl;
    cout << "standard deviation: " << standard_deviation(myPoisson) << endl;
    cout << "median: " << median(myPoisson) << endl;
    cout << "mode: " << mode(myPoisson) << endl;
    cout << "kurtosis excess: " << kurtosis_excess(myPoisson) << endl;
    cout << "kurtosis: " << kurtosis(myPoisson) << endl;
    cout << "skewness: " << skewness(myPoisson) << endl;
    cout << "characteristic function: " << chf(myPoisson, y) << endl;
    cout << "hazard: " << hazard(myPoisson, y) << endl;
    
    // Change precision
    cout.precision(5);
    // Create 2 vectors of doubles that stores resp. pdf and cdf value of myPoisson
    vector<double> pdfList;
    vector<double> cdfList;

    double start = 0.0;
    double end = 10.0;
    long N = 30;        // Number of subdivisions

    double val = 0.0;
    double h = (end - start) / double(N);

    for (long j = 1; j <= N; ++j)
    {
        // Vectors can only be pushed back
        pdfList.push_back(pdf(myPoisson, val));
        cdfList.push_back(cdf(myPoisson, val));
        val += h; // Increment val by h
        
    }
    
    cout << endl;
    cout << "-----------------------------------" << endl;
    cout << "Now Print pdf of Poisson(3.0)" << endl;

    for (long j = 0; j < pdfList.size(); ++j)
    {
        cout << pdfList[j] << ", ";

    }
    
    cout << endl;
    cout << "-----------------------------------" << endl;
    cout << "Now Print cdf of Poisson(3.0)" << endl;

    for (long j = 0; j < cdfList.size(); ++j)
    {
        cout << cdfList[j] << ", ";

    }


	return 0;
}
