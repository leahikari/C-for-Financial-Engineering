// EuropeanOption.cpp
// Lea LI
// Level 9 GroupA_ExactSolutions
// Implementation file for EuropeanOption class
// For matrix calculation purpose I set option type in an int variable optType: call = 0(default) adn put = 1

#include <vector>               // Include vector containers
#include <cmath>                // Include standard maths library
#include <iostream>             // Include standard input and output streams library
#include "Option.hpp"           // Include header for option base class
#include "EuropeanOption.hpp"   // Include header file of EuropeanOption
#include <boost/math/distributions/normal.hpp> // Include header file for normal distribution
#include <boost/math/distributions.hpp>        // For non-member functions of distributions

using namespace std;
using namespace boost::math; // Declare boost maths namespace

// Initialize default values
void EuropeanOption::Init()
{
    Option::Init(); // Default call option : optType=0
    K = 80.0;
    T = 0.5;
    r = 0.05;
    sig= 0.2;
    S = 100.0;
    b = r;  // b = r is the Black–Scholes stock option model (1973)
    
}

// Copy all values from source option
void EuropeanOption::Copy( const EuropeanOption& source)
{
    Option::Copy(source);
    K    = source.K;
    T    = source.T;
    r    = source.r;
    sig  = source.sig;
    b    = source.b;
    S    = source.S;
    
}

// Constructors and destructor
EuropeanOption::EuropeanOption()    // Default call option
{
    Init();
}

EuropeanOption::EuropeanOption(const EuropeanOption& source)
{ // Copy constructor
    Copy(source);
}

// Constructor with option type
EuropeanOption::EuropeanOption(const int& OptionType)
{
    Init();
    optType = OptionType;
    if (optType == 0)
        optType = 0;
}

// Constructor that sets the option
EuropeanOption::EuropeanOption(double expiry, double strike, double sigma, double intRate, double stock, double coc, int type):
T(expiry),K(strike),sig(sigma),r(intRate),S(stock),b(coc) { optType = type; }
    

// Destructor
EuropeanOption::~EuropeanOption() {}

// Assignment Operator
EuropeanOption& EuropeanOption::operator = (const EuropeanOption& source)
{
    if (this == &source)
        return *this; // Avoid assigning to itself
    
    Copy(source);
    return *this;   // Return assigned option
}

// Getter function that returns underlying stock value
double EuropeanOption::GetS() const
{
    return this->S;
}

/////////////////////////////////////////////////////////////////////
// Gaussian functions pdf and cdf from boost math library
double EuropeanOption::n(double x)   // PDF
{
    normal_distribution<> myNormal(0.0, 1.0); // Standard normal distribution
    return pdf(myNormal, x);
}

double EuropeanOption::N(double x)  // CDF
{
    normal_distribution<> myNormal(0.0, 1.0);
    return cdf(myNormal, x);
}

/////////////////////////////////////////////////////////////////////
// 'Kernel' functions to calculate option price and sensitivities
double EuropeanOption::CallPrice(double T, double K, double sig, double r, double S, double b)
{
    double tmp = sig * sqrt(T);
    double d1 = ( log(S/K) + (b+ (sig*sig)*0.5 ) * T )/ tmp;
    double d2 = d1 - tmp;
    return (S * exp((b-r)*T) * N(d1)) - (K * exp(-r * T)* N(d2));
}

double EuropeanOption::PutPrice(double T, double K, double sig, double r, double S, double b)
{
    double tmp = sig * sqrt(T);
    double d1 = ( log(S/K) + (b+ (sig*sig)*0.5 ) * T )/ tmp;
    double d2 = d1 - tmp;
    return (K * exp(-r * T)* N(-d2)) - (S * exp((b-r)*T) * N(-d1));
}


double EuropeanOption::CallDelta (double T, double K, double sig, double r, double S, double b)
{
    double tmp = sig * sqrt(T);
    double d1 = ( log(S/K) + (b+ (sig*sig)*0.5 ) * T )/ tmp;
    return exp((b-r)*T) * N(d1);
}


double EuropeanOption::PutDelta (double T, double K, double sig, double r, double S, double b)
{
    double tmp = sig * sqrt(T);
    double d1 = ( log(S/K) + (b+ (sig*sig)*0.5 ) * T )/ tmp;
    return exp((b-r)*T) * (N(d1) - 1.0);
}


double EuropeanOption::CallGamma (double T, double K, double sig, double r, double S, double b)
{
    double tmp = sig * sqrt(T);
    double d1 = ( log(S/K) + (b + (sig*sig)*0.5 ) * T )/ tmp;
    return ( n(d1) * exp((b-r)*T) ) / (S * tmp);
}



double EuropeanOption::PutGamma (double T, double K, double sig, double r, double S, double b)
{
    return CallGamma(T, K, sig, r, S, b);
}


// Functions to return option price and sensitivities
double EuropeanOption::Price()
{
    if (optType == 0)
        return CallPrice(T, K, sig, r, S, b);
    else
        return PutPrice(T, K, sig, r, S, b);
}

double EuropeanOption::Delta()
{
    if (optType == 0)
        return CallDelta(T, K, sig, r, S, b);
    else
        return PutDelta(T, K, sig, r, S, b);
}


double EuropeanOption::Gamma()
{
    if (optType == 0)
        return CallGamma(T, K, sig, r, S, b);
    else
        return PutGamma(T, K, sig, r, S, b);
}

// Overloaded Price() that calculates option price with given S
double EuropeanOption::Price(double newS)
{
    if (optType == 0)
        return CallPrice(T, K, sig, r, newS, b);
    else
        return PutPrice(T, K, sig, r, newS, b);
        
}

// Overloaded Delta() that calculates option price with given S
double EuropeanOption::Delta(double newS)
{
    if (optType == 0)
        return CallDelta(T, K, sig, r, newS, b);
    else
        return PutDelta(T, K, sig, r, newS, b);
        
}

// Overloaded Gamma() that calculates option price with given S
double EuropeanOption::Gamma(double newS)
{
    if (optType == 0)
        return CallGamma(T, K, sig, r, newS, b);
    else
        return PutGamma(T, K, sig, r, newS, b);
        
}

// Use expiry time as argument
double EuropeanOption::PriceWithT(double newT)
{
    if (optType == 0)
        return CallPrice(newT, K, sig, r, S, b);
    else
        return PutPrice(newT, K, sig, r, S, b);
        
}

// Use volatility as argument
double EuropeanOption::PriceWithSig(double newSig)
{
    if (optType == 0)
        return CallPrice(T, K, newSig, r, S, b);
    else
        return PutPrice(T, K, newSig, r, S, b);
        
}



/////////////////////////////////////////////////////////////////////
// Approximate option sensitivities using divided differences
double EuropeanOption::DeltaDiff(double h)
{
    return (Price(S + h) - Price(S - h)) / (2.0*h);
    
}

double EuropeanOption::GammaDiff(double h)
{
    return (Price(S + h) - 2 * Price(S) + Price(S - h)) / (h*h);
}

double EuropeanOption::DeltaDiff(double newS, double h)
{
    return (Price(newS + h) - Price(newS - h)) / (2.0*h);
    
}


// Put-Call Parity
// Calculate option price with put call parity
double EuropeanOption::ParityPrice()
{
    if (optType == 0)
        return  CallPrice(T, K, sig, r, S, b) + K*exp(-r*T) - S;
    else
        return  PutPrice(T, K, sig, r, S, b) + S - K*exp(-r*T);
}

// Check if it satisfies put call parity within tolerance
bool EuropeanOption::Check_Parity()
{
    double tol = 1e-10;
    return abs(PutPrice(T, K, sig, r, S, b) + S - CallPrice(T, K, sig, r, S, b) - K*exp(-r*T)) < tol;
}



/////////////////////////////////////////////////////////////////////
// Ouput option prices or sensitivities based on input vector or matrix
// Calculate the option price of a vector of stock value S
vector<double> EuropeanOption::Vec_Price(const vector<double>& arrayS)
{
    // Creat a vector to store the calculated price
    vector<double> Mesh_price;

    // Iterate arrayS to get a mesh array for prices
    for (int i = 0; i < arrayS.size(); i++)
    {
        Mesh_price.push_back(Price(arrayS[i]));
    }
    return Mesh_price;
}


// Calculate the option delta of a vector of stock value S
vector<double> EuropeanOption::Vec_Delta(const vector<double>& arrayS)
{
    
    // Creat a vector to store the calculated delta
    vector<double> Mesh_delta;

    // Iterate arrayS to get a mesh array for delta
    for (int i = 0; i < arrayS.size(); i++)
    {
        Mesh_delta.push_back(Delta(arrayS[i]));
    }
    return Mesh_delta;

}

// Calculate the option delta using divided difference methods of a vector h
vector<double> EuropeanOption::Vec_DeltaDiff(const vector<double>& arrayh)
{
    
    // Creat a vector to store the calculated delta
    vector<double> Mesh_deltaDiff;

    // Iterate arrayS to get a mesh array for delta
    for (int i = 0; i < arrayh.size(); i++)
    {
        Mesh_deltaDiff.push_back(DeltaDiff(arrayh[i]));
    }
    return Mesh_deltaDiff;

}

// Calculate option delta of a vector of stock value using divided difference
vector<double> EuropeanOption::Vec_DeltaDiff(const vector<double>& arrayS, const vector<double>& arrayh)
{
    // Creat a vector to store the calculated delta
    vector<double> Mesh_delta2;

    // Iterate arrayS to get a mesh array for delta
    for (int i = 0; i < arrayS.size(); i++)
    {
        Mesh_delta2.push_back(DeltaDiff(arrayS[i],arrayh[i]));
    }
    return Mesh_delta2;
    
}


// Calculate the option gamma of a vector of stock value S
vector<double> EuropeanOption::Vec_Gamma(const vector<double>& arrayS)
{
    
    // Creat a vector to store the calculated gamma
    vector<double> Mesh_gamma;

    // Iterate arrayS to get a mesh array for gamma
    for (int i = 0; i < arrayS.size(); i++)
    {
        Mesh_gamma.push_back(Gamma(arrayS[i]));
        
    }
    return Mesh_gamma;

}
// Calculate the option gamma using divided difference methods of a vector h
vector<double> EuropeanOption::Vec_GammaDiff(const vector<double>& arrayh)
{
    
    // Creat a vector to store the calculated gamma
    vector<double> Mesh_gammaDiff;

    // Iterate arrayS to get a mesh array for gamma
    for (int i = 0; i < arrayh.size(); i++)
    {
        Mesh_gammaDiff.push_back(GammaDiff(arrayh[i]));
    }
    return Mesh_gammaDiff;

}



