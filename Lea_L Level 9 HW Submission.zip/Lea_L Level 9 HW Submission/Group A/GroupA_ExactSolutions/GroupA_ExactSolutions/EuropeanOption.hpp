// EuropeanOption.hpp
// Lea LI
// Level 9 GroupA_ExactSolutions
// Header file for EuropeanOption class
// For matrix calculation purpose I set option type in an int variable optType: call = 0(default) adn put = 1

#ifndef EuropeanOption_HPP
#define EuropeanOption_HPP

#include <vector>
#include <iostream>
#include "Option.hpp"   // Include header for option base class
using namespace std;


class EuropeanOption : public Option

{

private:
    // Private data members
    double K;        // Strike price
    double T;        // Expire
    double r;        // Risk free interest rate
    double sig;      // Volatility
    double b;        // Cost of carry
    double S;        // Current stock price

    
    void Init(); // Initialise all default values of an option
    void Copy(const EuropeanOption& source); // Copy all values
    
    // Gaussian functions
    double n(double x); // PDF
    double N(double x); // CDF

    
    // 'Kernel' functions to calculate option price and sensitivities
    // I set these functions as private members since they do not need to be accessible to user interface
    double CallPrice(double T, double K, double sig, double r, double S, double b); // Call price
    double PutPrice(double T, double K, double sig, double r, double S, double b);  // Put price
    double CallDelta(double T, double K, double sig, double r, double S, double b); // Delta of call
    double PutDelta(double T, double K, double sig, double r, double S, double b);  // Delta of put
    double CallGamma(double T, double K, double sig, double r, double S, double b); // Gamma of call
    double PutGamma(double T, double K, double sig, double r, double S, double b);  // Gamma of put
    
    
    
public:
    
    // Constructors and destructor
    EuropeanOption();                             // Default constructor
    EuropeanOption(const EuropeanOption& source); // Copy constructor
    EuropeanOption(const  int& OptionType);       // Constructor with option type
    // Constructor that sets the option
    EuropeanOption(double expiry, double strike, double sigma, double intRate, double stock, double coc, int type);
    virtual ~EuropeanOption();                    // Destructor
    
    // Assignment operator
    EuropeanOption& operator = (const EuropeanOption& source);
    double GetS() const; // Get current underlying stock value
    
    // Functions that calculate option price and sensitivities based on option type
    double Price();
    double Delta();
    double Gamma();
    double Price(double newS);          // Use stock value as argument to compute option price
    double Delta(double newS);          // Use stock value as argument to compute option delta
    double Gamma(double newS);          // Use stock value as argument to compute option gamma
    double PriceWithT(double newT);     // Use expiry time as argument
    double PriceWithSig(double newSig); // Use volatility as argument
    
  
    // Approximate option sensitivities using divided differences
    double DeltaDiff(double h);
    double GammaDiff(double h);
    double DeltaDiff(double newS, double h);

    // Put-Call Parity
    double ParityPrice();    // Calculate option price with put call parity
    bool Check_Parity();     // Check if result satisfies put call parity and returns a boolean
    
    // Ouput option prices or sensitivities based on a input vector or matrix
    vector<double> Vec_Price(const vector<double>& arrayS);     // Calculate option price of a vector of stock value S
    vector<double> Vec_Delta(const vector<double>& arrayS);     // Calculate option delta of a vector of stock value S
    vector<double> Vec_DeltaDiff(const vector<double>& arrayh); // Calculate option delta of a vector of h using divided difference
    // Calculate option delta of a vector of stock value using divided difference
    vector<double> Vec_DeltaDiff(const vector<double>& arrayS, const vector<double>& arrayh);
    vector<double> Vec_Gamma(const vector<double>& arrayS);     // Calculate option gamma of a vector of stock value S
    vector<double> Vec_GammaDiff(const vector<double>& arrayh); // Calculate option gamma of a vector of h using divided difference
    
};


#endif // end of EuropeanOption.hpp


