// MeshFunctions.hpp
// Lea LI
// Level 9 GroupA_ExactSolutions
// Header file for MeshFunctions that takes an input matrix of options and returns a matrix result (price,delta,etc)

#ifndef MeshFunctions_HPP
#define MeshFunctions_HPP

#include <vector>               // Include vector containers
#include <iostream>             // Include standard input and output streams library
#include "Option.hpp"           // Include header file for Option class
#include "EuropeanOption.hpp"   // Include header file for EuropeanOption class
using namespace std;


// Declare some global template functions that calculate option price and sensitivities of an input matrix of option
// Calculate prices of an option matrix and output a price matrix
template<typename T>
vector<vector<double>> Mesh_Price(const vector<vector<T>>& mesh)
{
    // Create a matrix to store computed option prices
    // We can initialize it to same size as input matrix and filled with 0
    vector<vector<double>> matrixPrice(mesh.size(), vector<double>(mesh[1].size(), 0));
    for (int i = 0; i < mesh.size(); i++)
    {
        for (int j = 0; j < mesh[i].size(); j++)
        {
            matrixPrice[i][j] = EuropeanOption(mesh[i][j]).Price();
        }
    }
    
    return matrixPrice;
}

// Calculate delta of an option matrix and output a delta matrix
template<typename T>
vector<vector<double>> Mesh_Delta(const vector<vector<T>>& mesh)
{
    // Create a matrix to store computed option delta
    // We can initialize it to same size as input matrix and filled with 0
    vector<vector<double>> matrixDelta(mesh.size(), vector<double>(mesh[1].size(), 0));
    for (int i = 0; i < mesh.size(); i++)
    {
        for (int j = 0; j < mesh[i].size(); j++)
        {
            matrixDelta[i][j] = EuropeanOption(mesh[i][j]).Delta();
        }
    }
    
    return matrixDelta;
}


// Calculate gamma of an option matrix and output a gamma matrix
template<typename T>
vector<vector<double>> Mesh_Gamma(const vector<vector<T>>& mesh)
{
    // Create a matrix to store computed option gamma
    // We can initialize it to same size as input matrix and filled with 0
    vector<vector<double>> matrixGamma(mesh.size(), vector<double>(mesh[1].size(), 0));
    for (int i = 0; i < mesh.size(); i++)
    {
        for (int j = 0; j < mesh[i].size(); j++)
        {
            matrixGamma[i][j] = EuropeanOption(mesh[i][j]).Gamma();
        }
    }
    
    return matrixGamma;
}


#endif // end of MeshFunctions_HPP
