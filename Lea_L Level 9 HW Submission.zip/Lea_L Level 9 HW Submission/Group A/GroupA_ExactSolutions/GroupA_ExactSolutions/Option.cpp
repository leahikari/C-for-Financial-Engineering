// Option.cpp
// Lea LI
// Level 9 GroupA_ExactSolutions
// Source file for option base class
// For further calculation purpose I set option type in an int variable optType: call = 0(default) and put = 1

#include <vector>       // Include vector containers
#include "Option.hpp"   // Include header for option base class
using namespace std;    // Declare standard C++ library namespace


void Option::Init()
{
    optType = 0; // Default option type is call
}

// Copy all values
void Option::Copy(const Option& source)
{

    optType = source.optType;
}

// Default constructor
Option::Option()
{
    Init();
    
}

// Copy constructor
Option::Option(const Option& source)
{
    Copy(source); // Copy source option type
    
}

Option::~Option() {}  // Destructor

// Assignment Operator
Option& Option::operator = (const Option& source)
{
    if (this == &source)
        return *this; // Avoid assigning to itself
    
    optType = source.optType; // Assign option type
    return *this;
}

// Modifier functions to change option type
void Option::toggle()
{

    optType = ((optType == 0) ? 1 : 0); // Use ternary operator
}


// Global function that generates a mesh array of doubles between beg_val and end_val, seperated by mesh size
vector<double> GenerateMeshArray(double beg_val, double end_val, double mesh_size)
{
    int counter = (end_val - beg_val)/mesh_size + 1;
    vector<double> xarr(counter);
    xarr[0] = beg_val;
    xarr[xarr.size()-1] = end_val;
    
    for (int n = 1; n < xarr.size()-1; ++n)
    {
        xarr[n] = xarr[n-1] + mesh_size;
    }

    return xarr;
}
