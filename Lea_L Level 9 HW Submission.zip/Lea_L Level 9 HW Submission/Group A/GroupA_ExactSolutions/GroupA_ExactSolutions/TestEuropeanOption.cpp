// TestEuropeanOption.cpp
// Lea LI
// Level 9 GroupA_ExactSolutions
// Test program on exact solutions of European option pricing and sensitivity calculation
// We focus on plain (European) equity options (with zero dividends) and their sensitivities.

#include <vector>               // Include vector containers
#include <iostream>             // Include standard input and output streams library
#include "Option.hpp"           // Include header file for Option class
#include "EuropeanOption.hpp"   // Include header file for EuropeanOption class
#include "MeshFunctions.hpp"    // Template mesh functions that calculates option prices and greeks of a matrix input

using namespace std;

// Declare a global function that prints matrix
void printMatrix(const vector<vector<double>>& matrix)
{
    for (const auto& row : matrix) {
        for (double element : row) {
            cout << element << "\t";
        }
        cout << endl;
    }
}

// From HW just for checking results
// Batch 1: T = 0.25, K = 65, sig = 0.30, r = 0.08, S = 60 (then C = 2.13337, P = 5.84628).
// Batch 2: T = 1.0, K = 100, sig = 0.2, r = 0.0, S = 100 (then C = 7.96557, P = 7.96557).
// Batch 3: T = 1.0, K = 10, sig = 0.50, r = 0.12, S = 5 (C = 0.204058, P = 4.07326).
// Batch 4: T = 30.0, K = 100.0, sig = 0.30, r = 0.08, S = 100.0 (C = 92.17570, P = 1.24750).

int main()
{
    // a) b)
    cout << "Let's test 4 batches of option respectively and print results" << endl;
    
    // We have below constructor to set parameters of an European option
    // EuropeanOption(double expiry, double strike, double sigma, double intRate, double stock, double coc, int type);
    // Batch 1
    double T1 = 0.25;  double K1 = 65;  double sig1 = 0.30;  double r1 = 0.08;  double S1 = 60;  double b1 = r1;
    EuropeanOption Batch1(T1,K1,sig1,r1,S1,b1,0); // Create an European call option using predefined constructor
    double C1 = Batch1.Price();
    Batch1.toggle(); // Switch to put option to calculate price
    double P1 = Batch1.Price();
    cout << "Batch 1: Call option price C1 = " << C1 <<" and Put option price P1 = "<< P1 << endl;
    // Calculate option price with put call parity
    cout << "Option price by put call parity: " << Batch1.ParityPrice() << endl;
    // Check if result satisfies put call parity and returns a boolean
    cout << "If put call parity is satisfied return 1 otherwise 0 : " << Batch1.Check_Parity()<< endl << endl;

    // Batch 2
    double T2 = 1.0;  double K2 = 100;  double sig2 = 0.2;  double r2 = 0.0;  double S2 = 100;  double b2 = r2;
    EuropeanOption Batch2(T2,K2,sig2,r2,S2,b2,0); // 0 for call option
    double C2 = Batch2.Price();
    Batch2.toggle(); // Switch to put option to calculate price
    double P2 = Batch2.Price();
    cout << "Batch 1: Call option price C1 = " << C2 <<" and Put option price P1 = "<< P2 << endl;
    // Calculate option price with put call parity
    cout << "Option price by put call parity: " << Batch2.ParityPrice() << endl;
    // Check if result satisfies put call parity and returns a boolean
    cout << "If put call parity is satisfied return 1 otherwise 0 : " << Batch2.Check_Parity()<< endl << endl;

    // Batch 3
    double T3 = 1.0;  double K3 = 10;  double sig3 = 0.50;  double r3 = 0.12;  double S3 = 5;  double b3 = r3;
    EuropeanOption Batch3(T3,K3,sig3,r3,S3,b3,0); // 0 for call option
    double C3 = Batch3.Price();
    cout << "Batch 3: Call option price C3 = " << C3 << endl;
    // Calculate option price with put call parity
    cout << "Put option price by put call parity: " << Batch3.ParityPrice() << endl;
    Batch3.toggle(); // Switch to put option to calculate price
    double P3 = Batch3.Price();
    cout << "Batch 3: Put option price P3 = "<< P3 << endl;
    // Check if result satisfies put call parity and returns a boolean
    cout << "If put call parity is satisfied return 1 otherwise 0 : " << Batch3.Check_Parity()<< endl << endl;


    // Batch 4
    double T4 = 30.0;  double K4 = 100;  double sig4 = 0.30;  double r4 = 0.08;  double S4 = 100;  double b4 = r4;
    EuropeanOption Batch4(T4,K4,sig4,r4,S4,b4,1); // 1 for put option
    double P4 = Batch4.Price(S4);
    Batch4.toggle(); // Switch to call option to calculate price
    double C4 = Batch4.Price(S4);
    cout << "Batch 4: Call option price C4 = " << C4 <<" and Put option price P4 = "<< P4 << endl;
    // Calculate option price with put call parity
    cout << "Option price by put call parity: " << Batch4.ParityPrice() << endl;
    // Check if result satisfies put call parity and returns a boolean
    cout << "If put call parity is satisfied return 1 otherwise 0 : " << Batch4.Check_Parity()<< endl << endl;

    // c) Compute option prices for a monotonically increasing range of underlying values of S
    cout << "c) Now let's compute option prices for a monotonically increasing range of stock value S [50,60] " << endl;
    vector<double> arrayS = GenerateMeshArray(50.0, 60.0, 1); // Using GenerateMeshArray to creat ea monotonically increasing int vector
    for (int i = 0; i < arrayS.size(); i++)
    {
        cout << "Batch 1 put option price with underlying stock value "<< arrayS[i] << " is "<< Batch1.Vec_Price(arrayS)[i] << endl;
        // Batch 1 is already toggled to put option
        // Let's call function Vec_Price() to calculate the prices with different stock value input in arrayS
        // We can observe that the price is the same as above Batch 1 when underlying stock value reaches 60
    }
    cout << endl;
    
    // d) Compute option prices as a function of i) expiry time, ii) volatility and input a matrix of option parameters
    cout << "Batch2 Option: T2= 1.0; K2 = 100; Sig2 = 0.2; r2 = 0.0; S2 = 100; b2 = r2, put option" << endl;
    cout << "Let's calculate Batch2 option price based on different expirt time and volatilities" << endl;
    cout << "Batch2 put option price with expiry time T = 1.0 (original) is " << Batch2.PriceWithT(1.0) << endl;
    cout << "Batch2 put option price with expiry time T = 2.0 is " << Batch2.PriceWithT(2.0) << endl;
    cout << "Batch2 put option price with expiry time T = 3.0 is " << Batch2.PriceWithT(3.0) << endl;
    cout << "Batch2 put option price with volatility sig = 0.2 (original) is " << Batch2.PriceWithSig(0.2) << endl;
    cout << "Batch2 put option price with volatility sig = 0.3 is " << Batch2.PriceWithSig(0.3) << endl;
    cout << "Batch2 put option price with volatility sig = 0.25 is " << Batch2.PriceWithSig(0.25) << endl;
    cout << endl;
    
    cout << "d) Test Mesh_Price() that takes an input matrix of options and print priced matrix" << endl;
    // Create a matrix of EuropeanOption using above 4 batches' options
    // Batch 1,2,3 are put and Batch 4 is call
    vector<vector<EuropeanOption>> optionMatrix = { { Batch1, Batch2, Batch3, Batch4},
                                                     {Batch4, Batch3, Batch2, Batch1}};
    
    printMatrix(Mesh_Price(optionMatrix));
    
    
    cout << endl << "------------------------------------------" << endl;
    cout << "Option Sensitivities, aka the Greeks" << endl << endl;
    
    // a) b)
    double T5 = 0.5;  double K5 = 100;  double sig5 = 0.36;  double r5 = 0.1;  double S5 = 105;  double b5 = 0;
    EuropeanOption Batch5(T5,K5,sig5,r5,S5,b5,0); // Create an European call option using predefined constructor
    double d1 = Batch5.Delta(); // call option delta
    double g1 = Batch5.Gamma(); // call option gamma
    cout << "Batch 5: Call option delta is " << d1 <<" and gamma is "<< g1 << endl;
    Batch5.toggle(); // Switch to put option to calculate price
    double d2 = Batch5.Delta(); // put option delta
    double g2 = Batch5.Gamma(); // put option gamma
    cout << "Batch 5: Put option delta is " << d2 <<" and gamma is "<< g2 << endl << endl;

    cout << "b) Now let's compute option delta for a monotonically increasing range of stock value S [100,110] " << endl;
    vector<double> arrayS2 = GenerateMeshArray(100, 106, 1); // Create a monotonically increasing int vector
    Batch5.toggle(); // Switch to call option
    for (int i = 0; i < arrayS2.size(); i++)
    {
        cout << "Batch 5 call option delta with underlying stock value "<< arrayS2[i] << " is "<< Batch5.Vec_Delta(arrayS2)[i] << endl;
        // Batch 5 is already toggled to call option
        // Let's call function Vec_Delta() to calculate the delta with different stock value in arrayS
        // We can observe that the call delta is the same as above Batch 5 when underlying stock value reaches 105
    }
    cout <<"We can observe that the call delta is the same as above Batch 5 when underlying stock value reaches 105"<< endl;
    
    
    // c)
    cout << endl;
    cout << "c) Test Mesh_Delta() that takes an input matrix and print a delta matrix" << endl;
    // Create a matrix of EuropeanOption using above 5 batches
    // Batch 1,2,3 are put and Batch 4,5 are call
    vector<vector<EuropeanOption>> optionMatrix2 = { { Batch1, Batch2, Batch3, Batch4, Batch5},
                                                     {Batch5, Batch4, Batch3, Batch2, Batch1}};

    printMatrix(Mesh_Delta(optionMatrix2));
    cout << endl;
    cout << "Test Mesh_Gamma() that takes an input matrix and print a gamma matrix" << endl;
    printMatrix(Mesh_Gamma(optionMatrix2));
    // We can observe the same results as previous exercise
   
    // d) We now use divided differences to approximate option sensitivities
    cout << endl;
    cout << "d) Now use divided differences to approximate option sensitivities" << endl;
    cout << " Set a vector of h ranging from 0.001 to 1, incremented by 0.002" << endl;

    cout << endl;
    cout << "Display approximated delta for Batch5" << endl;
    cout << "----------------------------------------------------------------------" << endl;
    vector<double> vecH = GenerateMeshArray(0.001, 1, 0.002);
    for (int i = 0; i < vecH.size(); i++)
    {
        // Let's print batch 5 call and put delta for each h within range (0.1, 1, incremented by 0.001)
        cout << "With S = " << Batch5.GetS() << ", h = "<< vecH[i] << " , Batch 5 call delta is "<< Batch5.Vec_DeltaDiff(vecH)[i];
        Batch5.toggle();
        cout << " and put delta is " << Batch5.Vec_DeltaDiff(vecH)[i] << endl;
        Batch5.toggle();
        // We can observe that smaller values of h produce better approximations to exact solutions
    }
    
    cout << endl;
    cout << "Display approximated gamma for Batch5" << endl;
    cout << "---------------------------------------------------------------" << endl;
    for (int i = 0; i < vecH.size(); i++)
    {
        // Let's print batch 5 call and put gamma for each h within range (0.1, 1, incremented by 0.001)
        cout << "With S = " << Batch5.GetS() << ", h = "<< vecH[i] << " , Batch 5 put gamma is "<< Batch5.Vec_GammaDiff(vecH)[i];
        Batch5.toggle();
        cout << " and call gamma is " << Batch5.Vec_GammaDiff(vecH)[i] << endl;
        Batch5.toggle();
        // Gamma is the same for a European call and European put with the same inputs
        // We can observe that smaller values of h produce better approximations to exact solutions
        
    }
    
    cout << endl;
    cout << "Display approximated delta for Batch5 with different stock value S" << endl;
    cout << "----------------------------------------------------------------------" << endl;
    vector<double> vecS = GenerateMeshArray(80, 120, 1);
    for (int i = 0; i < vecS.size(); i++)
    {
        for (int j = 0; j < 5; j++)
        {
            // Let's print batch 5 call and put delta for each h within range (0.1, 1, incremented by 0.001)
            cout << "With S = " << vecS[i] << ", h = "<< vecH[i] << " , Batch 5 call delta is "<< Batch5.Vec_DeltaDiff(vecS,vecH)[i];
            Batch5.toggle();
            cout << " and put delta is " << Batch5.Vec_DeltaDiff(vecS,vecH)[i] << endl;
            Batch5.toggle();
        }
    }

    return 0;
        
}






 
 
