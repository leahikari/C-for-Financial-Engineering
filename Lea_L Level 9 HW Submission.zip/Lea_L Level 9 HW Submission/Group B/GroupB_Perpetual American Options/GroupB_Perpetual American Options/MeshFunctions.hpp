// MeshFunctions.hpp
// Lea LI
// Level 9 GroupB_Perpetual American Options
// Header file for MeshFunctions that takes an input matrix of options and returns a matrix of prices

#ifndef MeshFunctions_HPP
#define MeshFunctions_HPP

#include <vector>                        // Include vector containers
#include <iostream>                      // Include standard input and output streams library
#include "Option.hpp"                    // Include header file for Option class
#include "PerpetualAmericanOption.hpp"   // Include header file for PerpetualAmericanOptionc lass
using namespace std;


// Global template function that calculate prices of an input matrix of option, returns a matrix of prices
template<typename T>
vector<vector<double>> Mesh_Price(const vector<vector<T>>& mesh)
{
    // Create a matrix to store computed option prices
    // We can initialize it to same size as input matrix and filled with 0
    vector<vector<double>> matrixPrice(mesh.size(), vector<double>(mesh[1].size(), 0));
    for (int i = 0; i < mesh.size(); i++)
    {
        for (int j = 0; j < mesh[i].size(); j++)
        {
            matrixPrice[i][j] = PerpetualAmericanOption(mesh[i][j]).Price();
        }
    }
    
    return matrixPrice;
}

#endif // end of MeshFunctions_HPP
