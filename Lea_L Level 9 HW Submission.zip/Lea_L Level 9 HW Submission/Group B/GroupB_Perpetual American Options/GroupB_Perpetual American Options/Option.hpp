// Option.hpp
// Lea LI
// Level 9 GroupB_Perpetual American Options
// Header file for option base class
// Hide the sensitivities' part and some functions for Perpetual American Options


#ifndef Option_HPP
#define Option_HPP      // Prevent multiple inclusion

#include <vector>       // Include vector containers
#include <iostream>     // Include standard input and output streams library
using namespace std;    // Declare standard C++ library namespace


class Option
{
    
public:

    // Declare an int variable to store iption type, mainly for further calculation purpose
    int optType; // Call = 0(default) and Put = 1
    
public:
    
    // Overloaded initialisation and copy function
    virtual void Init();
    virtual void Copy(const Option& source);
    
    // Constructors and destructor
    Option();                        // Default constructor
    Option(const Option& source);    // Copy constructor
    virtual ~Option();               // Destructor

    // Assignment Operators
    Option& operator = (const Option& source);

    // Overloaded functions that calculates option price and sensitivities
    // They are PVMFs so do not need to be implemented in base class source file but must be overwritten in derived classes
    virtual double Price() = 0;
    //virtual double Delta() = 0;
    //virtual double Gamma() = 0;
    virtual double Price(double newS) = 0;  // Overloaded function that calculate option price based on given stock value S
    //virtual double PriceWithT(double newT) = 0;     // Overloaded function that calculate option delta based on expiry time
    virtual double PriceWithSig(double newSig) = 0; // Overloaded function that calculate option price based on given volatility as argument
    

    // Overloaded functions that calculate option prices and sensitivities based on a vector of different stock value S
    // Return a vector of doubles that stores computed results
    virtual vector<double> Vec_Price(const vector<double>& arrayS) = 0;
    //virtual vector<double> Vec_Delta(const vector<double>& arrayS) = 0;
    //virtual vector<double> Vec_Gamma(const vector<double>& arrayS) = 0;
    
    // Modifier functions
    void toggle();    // Change option type


};

// Declare a global function to generate a mesh array of doubles between beg_val and end_val, seperated by mesh size
vector<double> GenerateMeshArray(double beg_val, double end_val, double mesh_size);


#endif // end of Option_HPP
