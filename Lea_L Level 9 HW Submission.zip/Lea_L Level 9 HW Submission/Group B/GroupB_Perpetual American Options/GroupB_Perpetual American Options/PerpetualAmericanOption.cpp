// PerpetualAmericanOption.cpp
// Lea LI
// Level 9 GroupB_Perpetual American Options
// Implementation file for PerpetualAmericanOption class
// For matrix calculation purpose I set option type in an int variable optType: call = 0(default) adn put = 1

#include <vector>               // Include vector containers
#include <cmath>                // Include standard maths library
#include <iostream>             // Include standard input and output streams library
#include "Option.hpp"           // Include header for option base class
#include "PerpetualAmericanOption.hpp"         // Include header file of PerpetualAmericanOption
#include <boost/math/distributions/normal.hpp> // Include header file for normal distribution
#include <boost/math/distributions.hpp>        // For non-member functions of distributions

using namespace std;
using namespace boost::math; // Declare boost maths namespace

// Initialize default valuess
void PerpetualAmericanOption::Init()
{
    Option::Init(); // Default call option : optType=0
    K = 80.0;
    r = 0.05;
    sig= 0.2;
    S = 100.0;
    b = r;  // b = r is the Black–Scholes stock option model (1973)
    
}

// Copy all values from source option
void PerpetualAmericanOption::Copy( const PerpetualAmericanOption& source)
{
    Option::Copy(source);
    K    = source.K;
    r    = source.r;
    sig  = source.sig;
    b    = source.b;
    S    = source.S;
    
}

// Constructors and destructor
PerpetualAmericanOption::PerpetualAmericanOption()    // Default call option
{
    Init();
}

PerpetualAmericanOption::PerpetualAmericanOption(const PerpetualAmericanOption& source)
{ // Copy constructor
    Copy(source);
}

// Constructor with option type
PerpetualAmericanOption::PerpetualAmericanOption(const int& OptionType)
{
    Init();
    optType = OptionType;
    if (optType == 0)
        optType = 0;
}

// Constructor that sets the option
PerpetualAmericanOption::PerpetualAmericanOption(double strike, double sigma, double intRate, double stock, double coc, int type): K(strike),sig(sigma),r(intRate),S(stock),b(coc) { optType = type; }
    

// Destructor
PerpetualAmericanOption::~PerpetualAmericanOption() {}

// Assignment Operator
PerpetualAmericanOption& PerpetualAmericanOption::operator = (const PerpetualAmericanOption& source)
{
    if (this == &source)
        return *this; // Avoid assigning to itself
    
    Copy(source);
    return *this;   // Return assigned option
}

// Getter function that returns underlying stock value
double PerpetualAmericanOption::GetS() const
{
    return this->S;
}

/*
/////////////////////////////////////////////////////////////////////
// Gaussian functions pdf and cdf from boost math library
double PerpetualAmericanOption::n(double x)   // PDF
{
    normal_distribution<> myNormal(0.0, 1.0); // Standard normal distribution
    return pdf(myNormal, x);
}

double PerpetualAmericanOption::N(double x)  // CDF
{
    normal_distribution<> myNormal(0.0, 1.0);
    return cdf(myNormal, x);
}
*/

/////////////////////////////////////////////////////////////////////
// 'Kernel' functions to calculate option price
double PerpetualAmericanOption::PerpetualCall(double K, double sig, double r, double S, double b)
{
    // Dividend q = r - b
    double sig2 = sig*sig;
    double fac = b/sig2 - 0.5; fac *= fac;
    double y1 = 0.5 - b/sig2 + sqrt(fac + 2.0*r/sig2);
    
    if (1.0 == y1) // special case
        return S;
    
    double fac2 = ((y1 - 1.0)*S) / (y1 * K);
    double c = K * pow(fac2, y1) / (y1 - 1.0);
    return c;
    
}


double PerpetualAmericanOption::PerpetualPut(double K, double sig, double r, double S, double b)
{
    double sig2 = sig*sig;
    double fac = b/sig2 - 0.5; fac *= fac;
    double y2 = 0.5 - b/sig2 - sqrt(fac + 2.0*r/sig2);
    
    if (0.0 == y2)
        return S;

    double fac2 = ((y2 - 1.0)*S) / (y2 * K);
    double p = K * pow(fac2, y2) / (1.0 - y2);
    return p;
}



// Functions to return option price
double PerpetualAmericanOption::Price()
{
    if (optType == 0)
        return PerpetualCall(K, sig, r, S, b);
    else
        return PerpetualPut(K, sig, r, S, b);
}


// Overloaded Price() that calculates option price with given S
double PerpetualAmericanOption::Price(double newS)
{
    if (optType == 0)
        return PerpetualCall(K, sig, r, newS, b);
    else
        return PerpetualPut(K, sig, r, newS, b);
}



// Use volatility as argument
double PerpetualAmericanOption::PriceWithSig(double newSig)
{
    if (optType == 0)
        return PerpetualCall(K, newSig, r, S, b);
    else
        return PerpetualPut(K, newSig, r, S, b);
}


/////////////////////////////////////////////////////////////////////
// Calculate the option price of a vector of stock value S
vector<double> PerpetualAmericanOption::Vec_Price(const vector<double>& arrayS)
{
    // Creat a vector to store the calculated price
    vector<double> Mesh_price;

    // Iterate arrayS to get a mesh array for prices
    for (int i = 0; i < arrayS.size(); i++)
    {
        Mesh_price.push_back(Price(arrayS[i]));
    }
    return Mesh_price;
}

