// PerpetualAmericanOption.hpp
// Lea LI
// Level 9 GroupB_Perpetual American Options
// Header file for PerpetualAmericanOption class
// For matrix calculation purpose I set option type in an int variable optType: call = 0(default) adn put = 1

#ifndef PerpetualAmericanOption_HPP
#define PerpetualAmericanOption_HPP

#include <vector>
#include <iostream>
#include "Option.hpp"   // Include header for option base class
using namespace std;


class PerpetualAmericanOption : public Option

{

private:
    // Private data members
    double K;        // Strike price
    double r;        // Risk free interest rate
    double sig;      // Volatility
    double b;        // Cost of carry
    double S;        // Current stock price

    
    void Init(); // Initialise all default values of an option
    void Copy(const PerpetualAmericanOption& source); // Copy all values
    
    // Gaussian functions
    //double n(double x); // PDF
    //double N(double x); // CDF
 
    
    // 'Kernel' functions to calculate option price and sensitivities
    // I set these functions as private members since they do not need to be accessible to user interface
    double PerpetualCall(double K, double sig, double r, double S, double b); // Call price
    double PerpetualPut(double K, double sig, double r, double S, double b);  // Put price
    
    
public:
    
    // Constructors and destructor
    PerpetualAmericanOption();                             // Default constructor
    PerpetualAmericanOption(const PerpetualAmericanOption& source); // Copy constructor
    PerpetualAmericanOption(const  int& OptionType);       // Constructor with option type
    // Constructor that sets the option
    PerpetualAmericanOption(double strike, double sigma, double intRate, double stock, double coc, int type);
    virtual ~PerpetualAmericanOption();                    // Destructor
    
    // Assignment operator
    PerpetualAmericanOption& operator = (const PerpetualAmericanOption& source);
    double GetS() const; // Get current underlying stock value
    
    // Functions that calculate option price and sensitivities based on option type
    double Price();
    double Price(double newS);          // Use stock value as argument to compute option price
    double PriceWithSig(double newSig); // Use volatility as argument
    
    
    // Ouput option prices or sensitivities based on a input vector or matrix
    vector<double> Vec_Price(const vector<double>& arrayS);     // Calculate option price of a vector of stock value S
};


#endif // end of PerpetualAmericanOption.hpp


