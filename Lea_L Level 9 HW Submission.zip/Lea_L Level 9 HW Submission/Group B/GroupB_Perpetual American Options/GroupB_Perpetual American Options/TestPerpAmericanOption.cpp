// TestPerpAmericanOption.cpp
// Lea LI
// Level 9 GroupB_Perpetual American Options
// Test program on exact solutions of Perpetual American option pricing

#include <vector>               // Include vector containers
#include <iostream>             // Include standard input and output streams library
#include "Option.hpp"           // Include header file for Option class
#include "MeshFunctions.hpp"    // Template mesh functions that calculates option prices and greeks of a matrix input
#include "PerpetualAmericanOption.hpp" // Include header file for PerpetualAmericanOption class
using namespace std;


// Declare a global function that prints matrix
void printMatrix(const vector<vector<double>>& matrix)
{
    for (const auto& row : matrix) {
        for (double element : row) {
            cout << element << "\t";
        }
        cout << endl;
    }
}

// From HW just for checking results
// b) Test the data with K = 100, sig = 0.1, r = 0.1, b = 0.02, S = 110 (check C = 18.5035, P = 3.03106).

int main()
{
    //  b)
    cout << "b) Test a Perpetual American Option with K = 100, sig = 0.1, r = 0.1, b = 0.02, S = 110 and print results" << endl;
    // We have below constructor to set parameters of a Perpetual American Optionn
    // PerpetualAmericanOption(double strike, double sigma, double intRate, double stock, double coc, int type);
    
    double K1 = 100;  double sig1 = 0.1;  double r1 = 0.1;  double S1 = 110;  double b1 = 0.02;
    PerpetualAmericanOption AmerOption(K1,sig1,r1,S1,b1,0); // Create a Perpetual American Call Option at first
    double C1 = AmerOption.Price();
    AmerOption.toggle(); // Switch to put option to calculate price
    double P1 = AmerOption.Price();
    cout << "The Call option price C1 = " << C1 <<" and Put option price P1 = "<< P1 << endl;
    

    // c) Compute option price for a monotonically increasing range of underlying values of S
    cout << endl;
    cout << "c) Now let's compute option prices for a monotonically increasing range of stock value S [100,115] " << endl;
    vector<double> arrayS = GenerateMeshArray(100, 115, 1); // Create a monotonically increasing int vector
    for (int i = 0; i < arrayS.size(); i++)
    {
        // AmerOption is already toggled to put option
        // Call function Vec_Price() to calculate the prices with different stock value input in arrayS
        cout << "Put option price with underlying stock value "<< arrayS[i] << " is "<< AmerOption.Vec_Price(arrayS)[i] << endl;
        // Let's call function Vec_Price() to calculate the prices with different stock value input in arrayS
      
    }
    // We can observe that the price is the same as above b) when underlying stock value reaches 110
    cout << endl;
    
    // d) Compute option prices for a matrix of options
    cout << "d) Test Mesh_Price() that takes an input matrix of options and print priced matrix" << endl;
    // Create a matrix of PerpetualAmericanOption
    vector<vector<PerpetualAmericanOption>> matrixAmerOption (arrayS.size(),vector<PerpetualAmericanOption>(2,AmerOption));
    for (int i = 0; i < arrayS.size(); i++)
    {
        matrixAmerOption[i][0] = PerpetualAmericanOption(K1,sig1,r1,arrayS[i],b1,0);// CALL OPTION
        matrixAmerOption[i][1] = PerpetualAmericanOption(K1,sig1,r1,arrayS[i],b1,1);// PUT OPTION
    }
        

    printMatrix(Mesh_Price(matrixAmerOption));

    return 0;
        
}






 
 
