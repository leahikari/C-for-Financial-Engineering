// HardCoded.cpp
//
// C++ code to price an option, essential algorithms.
//
// We take CEV model with a choice of the elaticity parameter
// and the Euler method. We give option price and number of times
// S hits the origin.
// (C) Datasim Education BC 2008-2011

// Level 9 GroupD_Advanced Monte Carlo
// Lea LI
// Implementation of standard deviation (SD) and standard error (SE)
// Test the MC pricer for a range of call and put options


#include "OptionData.hpp" 
#include "NormalGenerator.hpp"
#include "Range.cpp"
#include <cmath>
#include <vector>
#include <iostream>
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>

template <typename T>
void print(const std::vector<T>& myList)
{  // A generic print function for vectors
	
	std::cout << std::endl << "Size of vector is " << myList.size() << "\n[";

	// We must use a const iterator here, otherwise we get a compiler error.
	for (typename T::const_iterator i = myList.begin(); i != myList.end(); ++i)
	{
			std::cout << *i << ",";

	}

	std::cout << "]\n";
}

// Create a generic function SDSE that calculates standard deviation and standard error for a range of simulated prices
// The inputs are a vector of size M (M = NSIM), the interest-free rate and expiry time T.
template <typename Type>
boost::tuple<Type, Type> SDSE(const std::vector<Type>& vecPrice, const Type& r, const Type& T)
{
    Type temp1(0), temp2(0);
    for (int i = 0; i < vecPrice.size(); i++)
    {
        temp1 += vecPrice[i] * vecPrice[i];
        temp2 += vecPrice[i];
    }

    int M = vecPrice.size();
    Type sd = sqrt(temp1 - 1 / M * temp2 * temp2) * exp(-2 * r * T) / (M - 1);
    Type se = sd / sqrt(M);

    return boost::make_tuple(sd, se);
}


namespace SDEDefinition
{ // Defines drift + diffusion + data

	OptionData* data;	// Option data pointer T

	double drift(double t, double X)
	{ // Drift term
	
		return (data->r)*X; // interest rate * underlying X, r-D if non-zero dividend
	}

	
	double diffusion(double t, double X)
	{ // Diffusion term
	
		double betaCEV = 1.0;
		return data->sig * pow(X, betaCEV);
		
	}

	double diffusionDerivative(double t, double X)
	{ // Diffusion term, needed for the Milstein method
	
		double betaCEV = 1.0;
		return 0.5 * (data->sig) * (betaCEV) * pow(X, 2.0 * betaCEV - 1.0);
	}
} // End of namespace



// Copy Bacthes here for convenience
// Batch 1: T = 0.25, K = 65, sig = 0.30, r = 0.08, S = 60 (then C = 2.13337, P = 5.84628).
// Batch 2: T = 1.0, K = 100, sig = 0.2, r = 0.0, S = 100 (then C = 7.96557, P = 7.96557).
int main()
{
    vector<double> Batch1 = {65.0, 0.25, 0.08, 0.30, 60 };
    vector<double> Batch2 = {100, 1.0, 0.0, 0.2, 100};
    // Vector to store the prices of put and call.
    vector<double> vecCall, vecPut;
    
	std::cout <<  "1 factor MC with explicit Euler\n";
	OptionData myOption;
    myOption.K   = Batch2[0];
    myOption.T   = Batch2[1];
    myOption.r   = Batch2[2];
    myOption.sig = Batch2[3];
	myOption.type = 1;	// Put -1, Call +1
    double S_0   = Batch2[4];;
	long N = 100;
	std::cout << "Number of subintervals in time: ";
	std::cin >> N;

	// Create the basic SDE (Context class)
	Range<double> range (0.0, myOption.T);
	double VOld = S_0;
	double VNew;
    
    // Mesh point here
	std::vector<double> x = range.mesh(N);
	

	// V2 mediator stuff
	long NSim = 50000;
	std::cout << "Number of simulations: ";
	std::cin >> NSim;

	double k = myOption.T / double (N);
	double sqrk = sqrt(k);

	// Normal random number
	double dW;
	double callPrice = 0.0;	// Call Option price
    double putPrice = 0.0;  // Put Option price

	// NormalGenerator is a base class
    // rand() is terrible
	NormalGenerator* myNormal = new BoostNormal();

	using namespace SDEDefinition;
	SDEDefinition::data = &myOption;
    // data points to an option instance

	std::vector<double> res;
	int coun = 0; // Number of times S hits origin

	// A.
	for (long i = 1; i <= NSim; ++i)
	{ // Calculate a path at each iteration
			
		if ((i/10000) * 10000 == i)
		{// Give status after each 1000th iteration

				std::cout << i << std::endl;
		}

		VOld = S_0;
		for (unsigned long index = 1; index < x.size(); ++index)
		{

			// Create a random number at every iteration
			dW = myNormal->getNormal();
				
			// The FDM (in this case explicit Euler)
            // x[index-1] is time
			VNew = VOld  + (k * drift(x[index-1], VOld))
						+ (sqrk * diffusion(x[index-1], VOld) * dW);

			VOld = VNew;

			// Spurious value to see how many wrong values are generated
			if (VNew <= 0.0) coun++;
		}
        // sum and then average
		double tmp1 = myOption.myPayOffFunction(VNew);
        callPrice += (tmp1) / double(NSim);
        vecCall.push_back(tmp1);
        myOption.type = -1;
        
        double tmp2 = myOption.myPayOffFunction(VNew);
        putPrice += (tmp2) / double(NSim);
        vecPut.push_back(tmp2);
        myOption.type = 1;
	}
	
	// D. Finally, discounting the average price
	callPrice *= exp(-myOption.r * myOption.T);
    putPrice *= exp(-myOption.r * myOption.T);

	// Cleanup; V2 use scoped pointer
	delete myNormal;

    std::cout << "NT = " << N << " and NSIM = " << NSim << endl;
	std::cout << "Call Price, after discounting: " << callPrice << std::endl;
    std::cout << "Put Price, after discounting: " << putPrice << std::endl;
	std::cout << "Number of times origin is hit: " << coun << endl;
    
    // Print SD and SE
    boost::tuple<double, double> tupleCall = SDSE<double>(vecCall, myOption.r, myOption.T);
    boost::tuple<double, double> tuplePut = SDSE<double>(vecPut, myOption.r, myOption.T);
    
    std::cout << "Call option pricing: Standard Deviation = " <<tupleCall.get<0>() << ", Standard Error = " << tupleCall.get<1>() << endl;
    std::cout << "Put option pricing: Standard Deviation = " <<tuplePut.get<0>() << ", Standard Error = " << tuplePut.get<1>() << endl;


	return 0;
}
